# Issue 1 Local Baseline Checklist

Run this checklist from the repository root on the target Windows development machine.

## Configuration and MySQL

- [ ] `Copy-Item .env.example .env`
- [ ] Replace `UNIDOC_DB_PASSWORD` with the password assigned to `unidoc_app@localhost`.
- [ ] Replace `UNIDOC_JWT_SECRET` with a Base64-encoded value containing at least 32 random bytes.
- [ ] Create the `unidoc` schema with `utf8mb4` and `utf8mb4_0900_ai_ci` using the SQL in the root README.
- [ ] Confirm `SHOW GRANTS FOR 'unidoc_app'@'localhost'` lists only SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, and REFERENCES on `unidoc.*`.
- [ ] Connect to the `unidoc` schema as `unidoc_app` without using the MySQL root account.
- [ ] Load `.env` into the current PowerShell process using the command in the root README.
- [ ] Create ignored `frontend/.env.local` containing only `VITE_API_BASE_URL`.

## Build verification

- [ ] `java -version` identifies Java 21.
- [ ] `.\backend\mvnw.cmd -f backend\pom.xml --version` runs without a global Maven installation.
- [ ] `.\backend\mvnw.cmd -f backend\pom.xml clean package` passes.
- [ ] `backend\target\unidoc-backend-0.0.1-SNAPSHOT.jar` exists.
- [ ] `npm --prefix frontend ci` passes from the committed lock file.
- [ ] `npm --prefix frontend run lint` passes.
- [ ] `npm --prefix frontend run build` passes with no TypeScript errors.

## Runtime smoke verification

- [ ] Start the API with `.\backend\mvnw.cmd -f backend\pom.xml spring-boot:run`.
- [ ] Confirm `data\uploads` and `data\uploads\.tmp` exist and are writable.
- [ ] `Invoke-RestMethod http://localhost:8080/api/health` returns only `status: ok`.
- [ ] A request to an unconfigured API route is denied.
- [ ] A test file placed below `data\uploads` cannot be fetched directly through the browser or Spring static resources.
- [ ] Start Vite with `npm --prefix frontend run dev`.
- [ ] Open `http://localhost:5173` and confirm the baseline page renders.
- [ ] Confirm the repository contains no `.env`, `frontend/.env.local`, uploaded bytes, build output, database dump, log file, or real secret intended for commit.
