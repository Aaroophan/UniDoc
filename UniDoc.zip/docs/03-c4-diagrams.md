# UniDoc C4 Architecture Diagrams

**Purpose:** Describe UniDoc from system context down to major components and runtime interactions.  
**Notation:** Mermaid is used so the diagrams remain version-controlled and editable.  
**Scope:** Current local-demonstration architecture, not a future enterprise deployment.

## 1. C4 reading guide

The C4 model presents software at progressively greater detail:

1. **System Context** - people and external systems around UniDoc.
2. **Container** - independently running applications and data stores.
3. **Component** - major responsibilities inside a container.
4. **Code** - classes and functions; ordinary source code is the code-level view.

UniDoc uses one frontend, one backend, one MySQL database, and one protected local upload directory. Gmail SMTP is the only external runtime integration.

## 2. Level 1 - System context

~~~mermaid
flowchart TB
    Student["Student<br/>requests and receives documents"]
    Staff["University staff<br/>reviews and processes requests"]
    Admin["Administrator<br/>manages and monitors"]
    UniDoc["UniDoc<br/>University Document Request Management System"]
    SMTP["Gmail SMTP<br/>sends notification email"]

    Student -->|"Registers, submits, tracks,<br/>downloads or collects"| UniDoc
    Staff -->|"Reviews, decides,<br/>processes and delivers"| UniDoc
    Admin -->|"Manages accounts/catalogue,<br/>views reports"| UniDoc
    UniDoc -.->|"Notification email"| SMTP
~~~

### 2.1 Context responsibilities

| Element | Responsibility | Trust level |
| --- | --- | --- |
| Student | Supplies account/profile/request data and accesses own records | Authenticated but untrusted input |
| Staff | Processes all requests and accesses documents needed for processing | Authenticated privileged user |
| Administrator | Maintains users and catalogue, monitors, exports reports | Authenticated privileged user |
| UniDoc | Enforces every application rule and stores authoritative state | Trusted application boundary |
| Gmail SMTP | Attempts delivery of status email | External service; failure tolerated |

### 2.2 Context boundary rules

- The browser is never trusted to enforce authorization.
- Gmail receives only the destination email, subject, notification text, and action URL.
- The system has no connection to a student information system, payment provider, SMS provider, cloud storage, or identity provider.
- Local operators have operating-system access but are not represented as an application role.

## 3. Level 2 - Container diagram

~~~mermaid
flowchart TB
    subgraph Client["User device"]
        Browser["React + TypeScript SPA<br/>Vite / Bootstrap"]
    end

    subgraph Local["Local demonstration computer"]
        API["Spring Boot REST API<br/>Java 21 / port 8080"]
        DB[("MySQL 26.7<br/>unidoc / port 3306")]
        Files[("Protected upload directory<br/>data/uploads")]
    end

    SMTP["Gmail SMTP<br/>STARTTLS / port 587"]

    Browser -->|"JSON, multipart, file responses<br/>Bearer JWT"| API
    API -->|"JPA / JDBC"| DB
    API -->|"Validated file I/O"| Files
    API -.->|"Best-effort email"| SMTP
~~~

### 3.1 Container catalogue

#### React single-page application

Responsibilities:

- renders public and authenticated routes;
- stores the current Bearer session in session storage;
- provides role-aware navigation;
- validates forms for usability;
- calls the REST API;
- displays paginated data;
- manages loading, empty, error, data, and success states;
- provides responsive layouts.

Technology:

- TypeScript;
- React;
- React Router;
- Axios;
- Bootstrap 5.3;
- @animateicons/react;
- Vite.

The SPA contains no direct database credentials and cannot read stored files directly.

#### Spring Boot REST API

Responsibilities:

- authenticates credentials;
- creates and validates JWTs;
- rechecks account state;
- enforces role and record-level authorization;
- validates DTOs and files;
- runs the request state machine;
- coordinates database and filesystem operations;
- creates notifications;
- sends email after successful commits;
- serves protected downloads;
- produces dashboard/report data;
- returns stable API errors.

Technology:

- Java 21;
- Spring Boot 4.1.1;
- Spring MVC;
- Spring Security;
- OAuth2 resource-server JWT support;
- Spring Data JPA;
- Bean Validation;
- Spring Mail.

#### MySQL database

Responsibilities:

- authoritative structured state;
- uniqueness and referential integrity;
- optimistic locking;
- paginated/filterable queries;
- transaction support.

Main tables:

- users;
- student_profiles;
- document_types;
- document_requests;
- request_attachments;
- issued_documents;
- request_status_history;
- notifications.

#### Local upload directory

Responsibilities:

- immutable student attachments;
- immutable issued PDF;
- temporary staging for safe writes.

The directory is not exposed by a web server. API authorization is required for every read.

#### Gmail SMTP

Responsibilities:

- sends plain-text notification email.

It is not authoritative. The request and in-app notification remain valid when SMTP fails.

## 4. Level 3 - Backend component diagram

~~~mermaid
flowchart TB
    Web["REST controllers<br/>DTO validation"]
    Auth["Authentication and security<br/>JWT, roles, active account"]
    Workflow["Request workflow service<br/>transitions and ownership"]
    Support["Supporting services<br/>catalogue, profile, user"]
    Delivery["File and notification services<br/>uploads, downloads, email"]
    Reporting["Reporting service<br/>dashboard and CSV"]
    Persistence["JPA repositories<br/>MySQL"]

    Web --> Auth
    Web --> Workflow
    Web --> Support
    Web --> Reporting
    Workflow --> Delivery
    Workflow --> Persistence
    Support --> Persistence
    Delivery --> Persistence
    Reporting --> Persistence
~~~

### 4.1 Backend components

| Component | Main classes | Responsibility |
| --- | --- | --- |
| Web/API boundary | Controllers, request/response DTOs | HTTP mapping, validation trigger, status codes |
| Authentication | AuthController, AuthenticationService, JwtService, ActiveUserFilter | registration, login, token creation, account/token checks |
| User/account | UserService, UserRepository | administrator account operations and user lookup |
| Profile | StudentProfileService, StudentProfileRepository | own-profile view/update and completeness |
| Document catalogue | DocumentTypeService, DocumentTypeRepository | active catalogue and admin management |
| Request workflow | DocumentRequestService, transition validator | submission, status changes, ownership, history |
| File storage | FileStorageService, FileAccessService | validation, safe names, staging, protected reads |
| Notifications | NotificationService, repositories | in-app notifications and unread state |
| Email | EmailNotificationListener, SmtpEmailSender, NoOpEmailSender | after-commit email without workflow rollback |
| Reporting | DashboardService, RequestReportService | aggregates, filtered results, safe CSV |
| Common | GlobalExceptionHandler, PageResponse, RequestIdFilter | stable cross-cutting HTTP behavior |
| Persistence | Spring Data repositories | database queries and pagination |
| Demo tooling | DemoDataSeeder, DemoDataResetRunner | deterministic local records and guarded reset |

### 4.2 Backend dependency rules

- Controller calls service, not repository.
- Service may call its repository and narrowly scoped supporting services.
- Request workflow owns state transitions.
- File service does not decide request status.
- Notification service does not decide request status.
- Reporting reads state but does not mutate it.
- Email listener runs after the transaction commit.
- Common utilities cannot depend on feature packages.
- Circular feature dependencies are not allowed.

## 5. Level 3 - Frontend component diagram

~~~mermaid
flowchart TB
    Routes["Route map<br/>public, protected, role routes"]
    Layout["Application layout<br/>navigation and shell"]
    Features["Feature pages<br/>profile, catalogue, requests, admin"]
    Shared["Shared components<br/>states, status, forms, pagination"]
    Auth["Auth context<br/>session and current user"]
    API["Typed API layer<br/>Axios client"]

    Routes --> Layout
    Routes --> Auth
    Layout --> Features
    Features --> Shared
    Features --> API
    Auth --> API
~~~

### 5.1 Frontend component responsibilities

| Component | Responsibility |
| --- | --- |
| Route map | Defines URL-to-page mapping and redirects |
| ProtectedRoute | Requires an authenticated session |
| RoleRoute | Restricts a page to allowed role values |
| AuthContext | Initializes and clears the current session |
| API client | Adds Bearer token and handles expired/inactive sessions |
| Feature API wrappers | Encode paths, parameters, multipart bodies, and response types |
| AppLayout | Consistent desktop/mobile navigation and content container |
| PageState | Loading, empty, and error presentation |
| FeedbackBanner | Operation-level success or failure feedback |
| RequestStatus | Consistent text-first status presentation |
| Pagination | Server-side list navigation |
| ConfirmDialog | Confirmation for terminal or important actions |
| Feature pages | Compose domain-specific forms, lists, details, and actions |

## 6. Runtime flow - Login

~~~mermaid
sequenceDiagram
    actor User
    participant UI as React UI
    participant Auth as Auth API
    participant UserRepo as User repository
    participant DB as MySQL

    User->>UI: Enter email and password
    UI->>Auth: POST /api/auth/login
    Auth->>UserRepo: Find normalized email
    UserRepo->>DB: SELECT user
    DB-->>UserRepo: User record
    Auth->>Auth: Check ACTIVE and BCrypt password
    Auth->>Auth: Create one-hour JWT
    Auth-->>UI: Token, expiry, public user
    UI->>UI: Store session in sessionStorage
    UI-->>User: Open role dashboard
~~~

Failure behavior:

- invalid credentials return 401 with a generic error;
- inactive account returns 403;
- password hashes never leave the backend;
- failed login does not create a session.

## 7. Runtime flow - New request

~~~mermaid
sequenceDiagram
    actor Student
    participant UI as Student UI
    participant API as Request API
    participant File as File storage
    participant DB as MySQL
    participant Mail as Email listener

    Student->>UI: Complete request and choose files
    UI->>API: Multipart request
    API->>API: Validate user, profile, type, date, method, files
    API->>File: Stage validated file bytes
    File-->>API: Relative staged/final metadata
    API->>DB: Transaction: request, attachments, history, notifications
    DB-->>API: Commit
    API-->>UI: 201 Created with request
    DB-->>Mail: After-commit notification event
    Mail-->>Student: Best-effort email
~~~

Consistency rules:

- no database metadata is committed when staging fails;
- a failed transaction triggers best-effort file cleanup;
- email occurs only after commit;
- email failure does not change the HTTP success response.

## 8. Runtime flow - Additional information

~~~mermaid
sequenceDiagram
    actor Staff
    actor Student
    participant API as Request API
    participant DB as MySQL
    participant Note as Notification service

    Staff->>API: Start review
    API->>DB: SUBMITTED to UNDER_REVIEW + history
    Staff->>API: Request information with message
    API->>DB: UNDER_REVIEW to ADDITIONAL_INFORMATION_REQUIRED
    API->>Note: Notify student
    Note-->>Student: In-app and email
    Student->>API: Written response and optional files
    API->>DB: ADDITIONAL_INFORMATION_REQUIRED to SUBMITTED
    API->>Note: Confirm to student and notify staff
~~~

The cycle may occur again after staff starts a new review. Each cycle remains visible in history.

## 9. Runtime flow - Electronic delivery

~~~mermaid
sequenceDiagram
    actor Staff
    actor Student
    participant API as UniDoc API
    participant Files as Local files
    participant DB as MySQL

    Staff->>API: Upload issued PDF
    API->>API: Require STAFF, ELECTRONIC, PROCESSING
    API->>Files: Validate and store PDF
    API->>DB: Create issued metadata and move to READY
    API-->>Staff: READY request
    Student->>API: Download issued document
    API->>DB: Verify owner and current state
    API->>Files: Read complete PDF
    Files-->>API: Bytes
    API->>DB: First download: READY to COMPLETED
    API-->>Student: PDF attachment response
~~~

Implementation note: the API reads the complete file successfully before committing first-download completion. A later client disconnect cannot be perfectly detected without a more complex streaming acknowledgment protocol, which is outside scope.

## 10. Runtime flow - Physical delivery

~~~mermaid
sequenceDiagram
    actor Staff
    actor Student
    participant API as UniDoc API
    participant DB as MySQL

    Staff->>API: Mark physical request ready
    API->>DB: PROCESSING to READY
    API-->>Student: In-app and email notification
    Student->>API: View request
    API-->>Student: Location and instructions
    Student-->>Staff: Collect physical document
    Staff->>API: Record collection date and note
    API->>DB: READY to COMPLETED
    API-->>Student: Completion notification
~~~

## 11. Runtime flow - Concurrent staff actions

~~~mermaid
sequenceDiagram
    participant A as Staff A
    participant B as Staff B
    participant API as Request service
    participant DB as MySQL

    A->>API: Approve version 4
    B->>API: Reject version 4
    API->>DB: UPDATE request version 4
    DB-->>A: Success, version becomes 5
    API->>DB: UPDATE request version 4
    DB-->>B: Zero rows / optimistic-lock failure
    API-->>B: 409 REQUEST_VERSION_CONFLICT
~~~

The losing staff user must reload before taking another action.

## 12. Deployment view

~~~mermaid
flowchart TB
    subgraph Laptop["Development / demonstration laptop"]
        Browser["Chrome or Edge"]
        Frontend["Vite dev server<br/>localhost:5173"]
        Backend["Spring Boot<br/>localhost:8080"]
        MySQL[("MySQL<br/>localhost:3306")]
        Uploads[("data/uploads")]
    end

    Gmail["smtp.gmail.com:587"]

    Browser --> Frontend
    Frontend --> Backend
    Backend --> MySQL
    Backend --> Uploads
    Backend -.-> Gmail
~~~

### 12.1 Deployment assumptions

- Windows is the primary demonstration operating system.
- Java 21, Node.js, npm, and MySQL 26.7.0 are installed.
- The repository includes Maven Wrapper.
- Secrets are in a root .env file ignored by Git.
- The browser and API run on the same laptop.
- Internet is required only when demonstrating actual Gmail delivery or initially downloading dependencies.
- Core in-app behavior continues if Gmail cannot be reached.

## 13. Security boundaries

~~~mermaid
flowchart LR
    Input["Untrusted browser input"]
    Security["JWT + role boundary"]
    Domain["Ownership + workflow rules"]
    Data["MySQL and protected files"]

    Input -->|"Validate syntax and size"| Security
    Security -->|"Authenticated identity"| Domain
    Domain -->|"Authorized operation only"| Data
~~~

The security boundary is layered:

1. authentication establishes identity;
2. route rules establish allowed roles;
3. service rules establish record ownership and valid state;
4. repository queries scope records;
5. storage rules prevent path manipulation;
6. response DTOs limit data exposure.

## 14. Data ownership view

| Data | Owner or authority | Read access | Write access |
| --- | --- | --- | --- |
| User account | UniDoc | Own user; admin listing | Registration; admin status/password |
| Student profile | Student | Own student; staff while processing; admin monitoring | Own student |
| Document type | Administrator | All authenticated users for active types | Administrator |
| Document request | Student relationship; UniDoc workflow authority | Owner, staff, admin | Student create/respond; staff transitions |
| Supporting file | Student request | Owner and staff | Student upload during allowed actions |
| Issued document | UniDoc request | Owner and staff | Staff upload |
| Status history | UniDoc | Same as request | Workflow service only |
| Notification | Recipient | Recipient only | Notification service only |
| Report | Computed | Administrator | Read/export only |

## 15. Scalability boundary

The architecture is deliberately sized for a course project and normal local demonstration:

- server-side pagination prevents unbounded list responses;
- database indexes support common filters;
- files remain outside MySQL;
- one application avoids distributed-system complexity.

The current scope does not promise:

- horizontal scaling;
- shared network storage;
- multiple API instances;
- high availability;
- background retry infrastructure;
- millions of records.

If future deployment requires multiple backend instances, the local filesystem and in-memory async execution would need replacement. That future decision is not part of the current implementation.

## 16. Architecture conformance checklist

Before considering implementation complete, confirm:

- only one backend deployable exists;
- no frontend code connects to MySQL or the upload path;
- controllers do not contain workflow rules;
- request transitions exist in one service/validator;
- every protected download checks identity and relationship;
- every growing list uses repository pagination;
- notifications and history are written with the workflow transaction;
- email is after-commit and failure-tolerant;
- report code is read-only;
- administrator monitoring exposes no staff mutation operation;
- invalid transitions return 409;
- UI route guards are present but are not treated as security;
- documentation diagrams match the actual package and deployment structure.
