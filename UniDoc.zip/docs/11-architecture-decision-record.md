# UniDoc Architecture Decision Record

**Purpose:** Record the important choices that constrain implementation.  
**Format:** One file containing a numbered set of lightweight ADRs.  
**Status values:** Accepted, Superseded, Deferred.

## How to use this document

Before changing an architectural choice:

1. identify the relevant ADR;
2. confirm whether the proposal requires the change;
3. write a new ADR that supersedes the old decision;
4. update affected requirements, API, data, security, storage, deployment, and test documents;
5. implement only after contradictions are removed.

Do not silently change an accepted decision in code.

---

## ADR-001 - Use a feature-based modular monolith

**Status:** Accepted  
**Date:** 9 October 2026

### Context

The project has three roles and several related features but only ten days for implementation. Microservices would require service discovery, multiple deployments, distributed authentication, cross-service calls, and more failure handling.

### Decision

Build one Spring Boot backend deployed as one process with feature-based packages:

- auth;
- user;
- profile;
- document;
- request;
- file;
- notification;
- email;
- report;
- admin;
- common;
- config;
- dev.

Use one MySQL schema.

### Consequences

Positive:

- simple startup/debugging;
- one transaction for workflow/history/notifications;
- fewer deployment parts;
- clear feature ownership;
- enough structure for maintainability.

Negative:

- features share one runtime/database;
- a failure can affect the whole API;
- independent scaling is unavailable.

### Rejected alternatives

- Microservices: excessive scope.
- One undifferentiated package: difficult to maintain.
- Generic global controller/service/repository folders: separates related feature code.

---

## ADR-002 - Use React, TypeScript, Vite, Bootstrap, and restrained AnimateIcons

**Status:** Accepted

### Context

The required frontend technology is React. The application needs responsive role-based pages and must be completed quickly.

### Decision

Use:

- React;
- TypeScript strict mode;
- Vite;
- React Router;
- Axios;
- Bootstrap 5.3;
- @animateicons/react only for meaningful action feedback.

Use custom CSS variables to set #970000 as primary colour.

### Consequences

Positive:

- fast setup;
- typed API integration;
- Bootstrap covers layout/forms/tables/dialogs;
- Vite provides simple local development;
- limited design effort.

Negative:

- Bootstrap defaults require visual refinement;
- icon motion can become noisy if overused;
- frontend remains a separate build/runtime.

### Rejected alternatives

- Next.js: server rendering/routing is unnecessary.
- Tailwind: not the chosen stack and adds design work.
- Large admin template: generic, visually noisy, harder to control.
- Continuous animation: distracting and unnecessary.

---

## ADR-003 - Use Java 21, Spring Boot 4.1.1, and Maven Wrapper

**Status:** Accepted

### Context

The project requires Spring Boot. Java 21 is installed and supported. Repeatable commands are needed.

### Decision

Use:

- Java 21;
- Spring Boot 4.1.1;
- Maven Wrapper;
- Spring MVC;
- Spring Data JPA;
- Spring Security;
- validation;
- mail;
- MySQL driver.

### Consequences

Positive:

- current supported platform;
- coherent Spring ecosystem;
- wrapper reduces Maven-install assumptions;
- Java records suit DTOs.

Negative:

- all development environments must use Java 21;
- newer Spring APIs may differ from older tutorials.

### Rejected alternatives

- Node/Nest backend: conflicts with chosen backend.
- Gradle: no advantage for this small project.
- Reactive WebFlux: unnecessary complexity.

---

## ADR-004 - Use MySQL with JPA and development ddl-auto update

**Status:** Accepted for local project

### Context

The proposal specifies MySQL. Reproducible structured relationships and filtering are important. Formal migration tooling adds setup work under the deadline.

### Decision

- MySQL 26.7.0 is the database.
- Spring Data JPA/Hibernate maps entities.
- InnoDB, utf8mb4, UTC.
- Local development uses spring.jpa.hibernate.ddl-auto=update.
- The schema is documented precisely.
- A clean-database test is required before final demonstration.

### Consequences

Positive:

- minimal schema setup;
- relational constraints;
- repository pagination/filtering;
- fast development.

Negative:

- ddl-auto is not a production migration strategy;
- schema changes can be less explicit;
- H2 tests do not perfectly match MySQL.

### Rejected alternatives

- MongoDB: conflicts with proposal.
- Flyway now: valuable but not needed for local deadline.
- Hand-maintained schema-only workflow: creates mapping drift risk during rapid changes.

### Future trigger

Adopt Flyway before shared staging/production deployment or multi-developer schema evolution beyond the assignment.

---

## ADR-005 - Use stateless HS256 JWT authentication

**Status:** Accepted

### Context

The React SPA needs authenticated API calls for three roles. The system is local and does not need SSO or refresh-token infrastructure.

### Decision

- Login returns one-hour HS256 JWT.
- Secret is Base64 and at least 32 bytes.
- Claims include subject, role, email, authVersion, issuer, issued/expiry times.
- Frontend stores the session in sessionStorage.
- API uses Bearer Authorization.
- No refresh token.
- No server-side session table.

### Consequences

Positive:

- simple SPA/API integration;
- stateless backend;
- role mapping through Spring Security;
- page refresh keeps session.

Negative:

- token is JavaScript-accessible;
- frontend sign-out cannot revoke a copied token;
- expired sessions require login again.

### Rejected alternatives

- Cookie session: adds CSRF/session infrastructure.
- OAuth/SSO: external integration is outside scope.
- localStorage: unnecessarily persistent.
- refresh tokens: unnecessary complexity.

---

## ADR-006 - Recheck account status, role, and authVersion on every request

**Status:** Accepted

### Context

JWT expiry alone would let deactivated users continue until expiry. Password reset also needs to revoke old tokens.

### Decision

After JWT validation, load the current user and require:

- account exists;
- ACTIVE;
- stored role equals token role;
- stored authVersion equals token authVersion.

Account status or password change increments authVersion.

### Consequences

Positive:

- immediate deactivation;
- simple token revocation for required cases;
- role changes cannot keep old authority.

Negative:

- one database lookup per authenticated request;
- database outage affects authentication.

### Rejected alternatives

- Token blacklist: more persistence/cleanup.
- Wait for one-hour expiry: weaker administrator control.

---

## ADR-007 - Keep controllers thin and business rules in services

**Status:** Accepted

### Context

Workflow rules must behave consistently across HTTP endpoints and tests.

### Decision

Controllers:

- map routes;
- accept validated DTOs;
- obtain principal;
- select HTTP response.

Services:

- enforce role/ownership/state;
- manage transactions;
- call repositories/storage/notifications;
- map to response DTOs.

Repositories:

- persistence queries only.

### Consequences

Positive:

- service rules are testable;
- fewer duplicated checks;
- controllers are readable.

Negative:

- services require careful dependency boundaries;
- mapping code remains explicit.

### Rejected alternatives

- Business logic in controllers: duplication and weak testing.
- Generic reflection CRUD service: cannot express workflow safely.

---

## ADR-008 - Model request processing as an explicit state machine

**Status:** Accepted

### Context

The proposal defines a sequence of statuses and role-specific actions. Arbitrary status editing would permit invalid histories.

### Decision

Allowed lifecycle:

~~~text
SUBMITTED
→ UNDER_REVIEW
→ ADDITIONAL_INFORMATION_REQUIRED → SUBMITTED
→ APPROVED or REJECTED
APPROVED → PROCESSING
PROCESSING → READY
READY → COMPLETED
~~~

Only named service actions perform transitions. No generic status update endpoint exists.

### Consequences

Positive:

- predictable UI actions;
- auditable history;
- invalid transitions return 409;
- tests can enumerate transitions.

Negative:

- adding a new state requires coordinated code/docs/tests;
- administrative manual correction is not available.

### Rejected alternatives

- Free status dropdown: unsafe.
- Workflow engine dependency: excessive.
- Student cancellation: explicitly excluded.

---

## ADR-009 - Let all active staff process all requests

**Status:** Accepted

### Context

Staff need to manage requests, but the proposal does not require assignment, queues, or departments.

### Decision

All active STAFF accounts:

- see all requests;
- can take any action valid for the current state;
- are protected from lost updates by optimistic locking.

There is no assignedStaffId.

### Consequences

Positive:

- minimal implementation;
- no assignment UI;
- easy demonstration.

Negative:

- no workload ownership;
- simultaneous action conflicts can occur.

### Rejected alternatives

- Claim/assign workflow: outside scope.
- Per-department routing: insufficient proposal data and extra effort.

---

## ADR-010 - Use optimistic locking for competing staff actions

**Status:** Accepted

### Context

Two staff members can open the same request. Last-write-wins could overwrite a decision.

### Decision

- Add @Version to DocumentRequest.
- Return version in detail.
- Staff action requests include expectedVersion.
- Conflict returns 409 REQUEST_VERSION_CONFLICT.
- UI reloads and does not retry automatically.

### Consequences

Positive:

- prevents silent lost updates;
- small implementation;
- no long-held locks.

Negative:

- user may need to repeat a decision after reload.

### Rejected alternatives

- Pessimistic locking: locks across user think time are unsuitable.
- No locking: unsafe.
- Staff assignment as lock: outside scope.

---

## ADR-011 - Store file bytes on protected local filesystem

**Status:** Accepted

### Context

The project needs uploads/downloads but is local-only. Storing large bytes in MySQL or using cloud storage is unnecessary.

### Decision

- Store bytes under data/uploads.
- Store metadata/relative path in MySQL.
- Use UUID storage names.
- Keep upload directory outside static resources.
- Serve through authorized controllers.
- Use temp staging plus compensating cleanup.

### Consequences

Positive:

- simple and fast;
- database remains compact;
- no cloud account/cost.

Negative:

- MySQL/filesystem are not transactionally atomic;
- backup requires both stores;
- multi-instance deployment is not supported.

### Rejected alternatives

- MySQL BLOB: increases database size and response complexity.
- Cloud storage: violates local/minimal scope.
- Public static directory: bypasses authorization.

---

## ADR-012 - Separate student attachments from the one issued document

**Status:** Accepted

### Context

Student requests may contain several files, while an electronic request has exactly one final document with download metadata.

### Decision

Use:

- request_attachments for initial/additional student files;
- issued_documents as one-to-one with document_requests.

### Consequences

Positive:

- one issued document enforced by unique constraint;
- download counters/timestamps remain focused;
- attachment categories remain simple.

Negative:

- two file metadata entities/services.

### Rejected alternatives

- One generic files table: one-final-document uniqueness would rely only on service logic.
- Issued file columns on request: mixes storage metadata with workflow aggregate and creates many nullable fields.

---

## ADR-013 - Snapshot catalogue display and collection values into requests

**Status:** Accepted

### Context

Administrators can rename/deactivate types or change collection instructions. Old requests must remain understandable.

### Decision

At submission copy:

- document type name;
- collection location;
- collection instructions.

Keep document_type_id for filtering/relationship.

### Consequences

Positive:

- historical request meaning remains stable;
- deactivation/edit does not rewrite old instructions.

Negative:

- controlled duplication;
- reports must choose snapshot name for display.

### Rejected alternatives

- Always join current type values: historical drift.
- Snapshot full catalogue: unnecessary duplication.

---

## ADR-014 - Use repository-level server pagination

**Status:** Accepted

### Context

Requests, users, notifications, and reports can grow. Loading all rows and slicing in memory is easy but creates hidden limits.

### Decision

- Use Page/Pageable for growing collections.
- Default size 20.
- Maximum 100.
- Apply filters/sorts in database.
- Keep bounded active catalogue unpaged.

### Consequences

Positive:

- complete metadata;
- no arbitrary first-100 loss;
- efficient enough for growth;
- CSV can deliberately retrieve all matching rows.

Negative:

- query specifications are more work than in-memory filters.

### Rejected alternatives

- In-memory pagination: inefficient and easy to misuse.
- Cursor pagination: unnecessary.

---

## ADR-015 - Persist in-app notification; send email after commit

**Status:** Accepted

### Context

Email is required, but SMTP can fail. A mail outage must not roll back an approved request.

### Decision

- Create in-app notification inside domain transaction.
- Publish a notification-created event.
- Handle with @TransactionalEventListener AFTER_COMMIT and @Async.
- Send through JavaMailSender when enabled.
- Log failure and do not retry.
- Use NoOp sender when disabled.

### Consequences

Positive:

- database state is authoritative;
- email latency does not block the transaction;
- mail failure does not corrupt workflow.

Negative:

- application stop after commit can lose an email;
- no delivery status/retry UI.

### Rejected alternatives

- SMTP inside transaction: slow and can roll back domain state.
- Durable outbox/queue: too much scope.
- Email only: loses authoritative in-app history.

---

## ADR-016 - Complete electronic request on first authorized student download

**Status:** Accepted

### Context

The agreed workflow treats first student download as completion while allowing later downloads.

### Decision

- Student download allowed in READY and COMPLETED.
- API reads file successfully.
- If READY, update request to COMPLETED, set first/last download times, count, history, notification.
- Later downloads update count/last time only.
- Staff verification download never completes.

### Consequences

Positive:

- no extra student confirmation action;
- request closes naturally;
- later access remains available.

Negative:

- server response preparation is used as success boundary; client disconnect cannot be proven.

### Rejected alternatives

- Manual student Complete button: unnecessary.
- Mark complete at staff upload: does not reflect student receipt.
- One-time download: conflicts with later-download requirement.

---

## ADR-017 - Use CSV, not PDF, for report export

**Status:** Accepted

### Context

The proposal requires report generation, not a particular format. PDF layout adds significant effort.

### Decision

Provide:

- filterable on-screen report;
- UTF-8 CSV export using same filters;
- formula-injection protection.

### Consequences

Positive:

- simple implementation;
- usable in Excel/Sheets;
- meets reporting requirement.

Negative:

- no polished printable report.

### Rejected alternatives

- PDF generation: unnecessary.
- Spreadsheet library/XLSX: extra dependency.
- Advanced BI dashboard: outside scope.

---

## ADR-018 - Deactivate users and document types instead of deleting

**Status:** Accepted

### Context

Requests need stable references. Deleting accounts/catalogue entries can destroy history or break foreign keys.

### Decision

- Users have ACTIVE/INACTIVE.
- Document types have active boolean.
- Normal API provides no DELETE.
- Guarded demo reset may clear tables.

### Consequences

Positive:

- historical integrity;
- simple recovery by reactivation;
- fewer cascade mistakes.

Negative:

- old rows remain;
- uniqueness prevents reusing email/code/name without reactivation/edit.

### Rejected alternatives

- Hard delete: unsafe for history.
- Generic deleted_at on every table: unnecessary.

---

## ADR-019 - Do not require temporary-password change

**Status:** Accepted

### Context

Administrators create staff/admin accounts and can reset passwords. A forced first-login flow was considered but explicitly declined.

### Decision

- Administrator supplies initial/new password.
- No passwordResetRequired field.
- No restricted first-login state.
- Password reset invalidates old tokens through authVersion.

### Consequences

Positive:

- fewer screens/states;
- minimal implementation.

Negative:

- initial password handling relies on administrator/user coordination.

### Rejected alternatives

- Forced change flow: explicitly unnecessary.
- Email password: insecure and not required.

---

## ADR-020 - Use plain-text notification email

**Status:** Accepted

### Context

Email is required, but branded HTML templates are not.

### Decision

Use SimpleMailMessage with:

- UniDoc subject prefix;
- title;
- concise message;
- authenticated frontend link;
- automatic-message footer.

Do not attach documents.

### Consequences

Positive:

- fast and robust;
- less XSS/template work;
- readable across clients.

Negative:

- limited branding.

### Rejected alternatives

- HTML email templates: extra testing/design.
- Document attachments: privacy/security risk.
- Public signed links: unnecessary.

---

## ADR-021 - Use one global error contract and request correlation ID

**Status:** Accepted

### Context

Frontend needs predictable handling; local diagnosis needs log correlation.

### Decision

- One ApiErrorResponse.
- Stable code.
- Optional fieldErrors.
- X-Request-ID generated/echoed and logged.
- One GlobalExceptionHandler plus security JSON handlers.

### Consequences

Positive:

- consistent frontend;
- easier debugging;
- safe error content.

Negative:

- all exceptions require correct mapping.

### Rejected alternatives

- Default Spring errors: inconsistent and potentially revealing.
- Controller-specific errors: duplication.

---

## ADR-022 - Use deterministic seed and guarded database reset

**Status:** Accepted

### Context

The project requires a reliable demonstration without manually creating many states.

### Decision

- Seed known accounts, catalogue, requests, history, notifications.
- Seeder is idempotent.
- Reset requires script confirmation plus backend flags/token.
- Reset clears database records and can reseed.
- Reset does not delete uploaded files.

### Consequences

Positive:

- repeatable demo;
- rapid testing;
- safe guard against accidental reset.

Negative:

- upload orphans can remain;
- reset code must be kept separate from normal startup.

### Rejected alternatives

- Manual seed: slow/unreliable.
- Unguarded endpoint: dangerous.
- Automatic upload deletion: explicitly excluded.

---

## ADR-023 - Use essential backend automation and manual frontend UAT

**Status:** Accepted

### Context

The deadline is short. Highest risks are backend state, authorization, and file handling. Building broad browser automation would delay required features.

### Decision

- Automated service, repository, security/controller, storage, and report tests.
- Frontend requires lint and production build.
- Core UI flows are manually tested at three responsive widths.
- Optional small component tests only after all required behavior.

### Consequences

Positive:

- automation targets highest-risk rules;
- delivery stays feasible;
- manual UAT validates real workflow.

Negative:

- frontend regressions rely more on manual checks;
- no repeatable browser suite.

### Rejected alternatives

- No automated tests: too risky.
- Full Playwright suite: too much effort for current deadline.

---

## ADR-024 - Keep administrator monitoring read-only for request workflow

**Status:** Accepted

### Context

The proposal assigns request processing to staff and monitoring/reporting to administrator.

### Decision

- ADMIN can list/view requests, dashboard, and reports.
- ADMIN cannot call STAFF workflow actions.
- ADMIN does not receive file download by default.

### Consequences

Positive:

- clear separation of duties;
- smaller permission model;
- matches role descriptions.

Negative:

- administrator cannot correct workflow directly.

### Rejected alternatives

- Admin-as-superuser for all actions: exceeds role scope.
- Separate auditor role: unnecessary.

---

## ADR-025 - Keep branding generic and accessibility-first

**Status:** Accepted

### Context

No official logo or institution branding is supplied. The UI must be responsive and simple.

### Decision

- UD letter mark.
- UniDoc name and system subtitle.
- Primary #970000.
- No institution/faculty/department branding.
- Neutral surfaces and restrained semantic colour.
- Status always uses text.
- Icons animate only through user interaction/meaningful change.
- Loading, empty, error, data states are distinct.

### Consequences

Positive:

- avoids unofficial branding;
- coherent design;
- less visual noise;
- improved accessibility.

Negative:

- not an official branded portal.

### Rejected alternatives

- Invented university logo: inappropriate.
- Generic bright badge-heavy dashboard: noisy.
- Large custom design system: unnecessary.

---

## ADR-026 - Exclude features that do not serve proposal completion

**Status:** Accepted

### Context

The project has a fixed deadline and broad temptation for extra features.

### Decision

Do not implement:

- payment;
- cloud deployment/storage;
- microservices;
- WebSockets;
- staff assignment;
- approval chains;
- student cancellation;
- file versions;
- password recovery email;
- PDF reports;
- live messaging;
- external integrations;
- offline synchronization.

### Consequences

Positive:

- protects delivery;
- keeps documentation and testing manageable;
- proposal remains scope authority.

Negative:

- future product use would require additional work.

### Rejected alternatives

Implementing any excluded feature before all required paths are complete.

---

## Decision summary

| ADR | Decision | Status |
| --- | --- | --- |
| 001 | Feature-based modular monolith | Accepted |
| 002 | React/TypeScript/Vite/Bootstrap/AnimateIcons | Accepted |
| 003 | Java 21/Spring Boot 4.1.1/Maven Wrapper | Accepted |
| 004 | MySQL/JPA/ddl-auto update locally | Accepted |
| 005 | Stateless HS256 JWT in sessionStorage | Accepted |
| 006 | Per-request account/authVersion check | Accepted |
| 007 | Thin controllers, service-owned rules | Accepted |
| 008 | Explicit request state machine | Accepted |
| 009 | All active staff process all requests | Accepted |
| 010 | Optimistic locking | Accepted |
| 011 | Protected local filesystem | Accepted |
| 012 | Separate attachments and issued document | Accepted |
| 013 | Catalogue snapshots | Accepted |
| 014 | Repository-level pagination | Accepted |
| 015 | In-app transaction + after-commit email | Accepted |
| 016 | First student download completes electronic request | Accepted |
| 017 | CSV report export | Accepted |
| 018 | Deactivation instead of deletion | Accepted |
| 019 | No forced first-login password change | Accepted |
| 020 | Plain-text email | Accepted |
| 021 | Standard errors and request IDs | Accepted |
| 022 | Seed/reset; preserve uploads | Accepted |
| 023 | Essential backend tests + manual UI UAT | Accepted |
| 024 | Admin request workflow is read-only | Accepted |
| 025 | Generic accessible branding | Accepted |
| 026 | Exclude non-proposal features | Accepted |

## Architecture guardrails

The following require a new ADR before implementation:

- adding a second backend service;
- replacing MySQL;
- moving authentication to cookies/SSO;
- exposing uploads publicly;
- adding a new request status;
- allowing generic status update;
- adding staff assignment;
- letting admin process requests;
- adding public deployment;
- replacing local file storage;
- adding payment;
- adding a message broker/outbox;
- changing electronic completion semantics;
- deleting uploads during reset.
