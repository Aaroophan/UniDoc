# Issue 2 Implementation Checklist

## Scope completed

- Added the eight approved JPA entities and no additional application table.
- Added the six documented string-backed enums without ordinal or fallback values.
- Enabled Spring Data JPA auditing with `Instant` UTC timestamps and `LocalDate` business dates.
- Added explicit table, column, unique-key, foreign-key, check-constraint, and index mappings.
- Added database `ON DELETE CASCADE` only for the profile, request-child, and notification relationships documented in `04-data-model.md`.
- Added `@Version` optimistic locking to document requests.
- Added normalized email, registration-number, and document-code helpers and repository entry points.
- Added feature-local repositories with no feature delete operation; normal services must not invoke hard deletion.
- Added owner-scoped reads, pageable growing collections, bounded active-catalogue reads, reusable JPA specifications, aggregate count projections, and documented sort allow-lists.
- Added persistence tests for schema scope, full entity-graph persistence, uniqueness, normalization, pagination, filtering, aggregate counts, ordering, delete actions, and optimistic-lock conflicts.

## Automated verification

Run from the repository root with Java 21:

```powershell
.\backend\mvnw.cmd clean test
.\backend\mvnw.cmd clean package
npm --prefix frontend run lint
npm --prefix frontend run build
```

Expected backend test total after Issue 2: **20 tests**.

## Clean MySQL schema verification

Perform this only against the expendable local `unidoc` development schema after backing up any data that must be kept.

1. Stop the backend.
2. Drop and recreate `unidoc` with `utf8mb4` and `utf8mb4_0900_ai_ci` using the Issue 1 setup SQL.
3. Confirm `.env` still points to the restricted `unidoc_app` account.
4. Start the backend with `spring.jpa.hibernate.ddl-auto=update`.
5. Confirm these and only these application tables exist:
   - `users`
   - `student_profiles`
   - `document_types`
   - `document_requests`
   - `request_attachments`
   - `issued_documents`
   - `request_status_history`
   - `notifications`
6. Run `SHOW CREATE TABLE <table_name>;` for every table and compare names, types, nullability, unique keys, foreign keys, delete actions, checks, and indexes with `docs/04-data-model.md`.
7. Confirm every table uses InnoDB and timestamp columns are `DATETIME(6)`.
8. Run the backend tests again after the clean-schema smoke test.

## MySQL-specific verification note

H2 runs in MySQL compatibility mode for automated repository tests, but it is not the final authority for MySQL collation, unsigned numeric display, InnoDB metadata, descending-index metadata, or exact `SHOW CREATE TABLE` output. The clean MySQL verification above remains the final Issue 2 schema check.
