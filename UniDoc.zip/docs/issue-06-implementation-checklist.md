# Issue 6 Implementation and Verification Checklist

**Scope:** Issue 6 — Implement Student Profile Management (`docs/12-implementation-plan.md` §§6.1–6.10)

## Implemented

- [x] Student profile request/response DTOs with profile/email/identity separation.
- [x] Server-side Jakarta Validation for field lengths, allowed registration characters, optional phone characters and length, and year 1–8.
- [x] Profile read returns account identity plus null academic fields and `complete=false` on first login.
- [x] Transactional student-owned create/update; canonical whitespace normalization and uppercase registration number.
- [x] Unique registration precheck and unchanged-number allowance; unique database constraint remains authoritative for races.
- [x] Atomic `users.full_name` update and profile write; response derived from saved state.
- [x] STUDENT-only GET/PUT `/api/student/profile`; other roles get 403, missing Bearer authentication gets 401.
- [x] Frontend typed API, responsive profile view/form, read-only email, validation, focus/error feedback, retry/success/loading states.
- [x] Incomplete-profile UX guard on `/requests/new` and first-login guidance on `/requests`, each backed by a fresh GET and a direct profile link.
- [x] `StudentProfileService.requireCompleteForSubmission(currentUserId)` prepared as the backend prerequisite for Issue 11.
- [x] Existing auth context refreshes account identity after a successful profile update.
- [x] New service and HTTP test suites for missing/complete/legacy profile, create/update, normalization, unique numbers, role isolation, invalid fields, year boundaries and account identity.

## Verification undertaken in the implementation environment

- Java 21 main-source compilation using the production dependency JARs included in the uploaded backend runnable JAR: **passed**.
- Strict frontend TypeScript project compilation using the supplied TypeScript package: **passed**.
- Standalone Java Bean Validation and service-behavior harness: **20 checks passed**.
- Standalone frontend validation harness: **23 checks passed**.
- Full Maven integration suite: **not executed here** (Maven Wrapper distribution and test dependencies were not locally available; network access is restricted).
- Frontend lint/production Vite build: **not executed here** (uploaded dependencies contain Windows-native bindings, unavailable to this Linux environment). Run both on the target Windows workstation with `npm ci`.
- Live MySQL/browser responsive checks: **not executed here**. Manual steps are in the root README.

## Windows regression commands

Run in `C:\ASV\Projects\UniDoc` with MySQL configured and Java 21:

```powershell
.\backend\mvnw.cmd -f backend\pom.xml clean test
.\backend\mvnw.cmd -f backend\pom.xml clean package
npm --prefix frontend ci
npm --prefix frontend run lint
npm --prefix frontend run build
```

Then start both applications as documented in README and perform the Issue 6 manual scenarios.

## Intentional issue boundary

Issue 6 implements the **profile prerequisite service** and frontend direct-navigation guard. `/api/student/requests` request submission does not exist until Issue 11 and must call `requireCompleteForSubmission`. Its absence is not worked around by a fabricated request endpoint. The fully operational new-request form belongs to Issue 12. All later-issue features remain unchanged.

No extra tables, migration tool, API role, authentication mechanism, storage facility, PowerShell script or client-side authority was added.
