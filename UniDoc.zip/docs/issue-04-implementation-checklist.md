# Issue 4 Implementation Checklist

## Scope completed

- Added public `POST /api/auth/register` for STUDENT-only self-registration with no automatic login.
- Added trimmed/lowercased email normalization, trimmed full-name length validation, an 8-72 character password policy, confirmation matching on `confirmPassword`, and BCrypt strength 12.
- Kept role, status, and authentication-version fields out of the public registration contract; unknown extra JSON fields are ignored and can never grant a privileged role.
- Added `POST /api/auth/login` with one generic invalid-credential response, explicit inactive-account rejection, and no server session/refresh token.
- Added one-hour HS256 JWT creation with issuer `unidoc`, numeric subject, normalized email, role, and `authVersion` claims.
- Added startup JWT validation: Base64 secret, minimum 32 decoded bytes, expiry range 300-86400 seconds, and HS256-only encoder/decoder.
- Added issuer, expiry, positive numeric subject, supported role, and non-negative authentication-version token validation.
- Replaced the Issue 1/3 baseline security chain with the final Issue 4 stateless `SecurityConfig` route families.
- Kept only `GET /api/health`, `POST /api/auth/register`, and `POST /api/auth/login` anonymous.
- Added STUDENT/STAFF/ADMIN route-family enforcement plus authenticated shared catalogue, notification, and `/api/auth/me` routes.
- Added an `ActiveUserFilter` after Bearer authentication that reloads the stored account on every authenticated request and rejects missing users, inactive users, role mismatches, and stale `authVersion` values.
- Added a safe `CurrentUserPrincipal` and `CurrentUserProvider`; later services can obtain the current numeric user ID without accepting it from request input or parsing JWTs independently.
- Added `GET /api/auth/me` as the frontend session-authority endpoint.
- Added exact local CORS behavior: configured origin allow-list, GET/POST/PUT/PATCH/OPTIONS, approved headers, exposed `Content-Disposition`/`X-Request-ID`, no wildcard origin, and no credentials mode.
- Added authentication, JWT, active-user, route-role, CORS, validation, revocation, and sensitive-output regression tests.
- Added no refresh token, cookie session, blacklist, SSO, forgot-password flow, forced first-login state, or new database table.

## Automated verification to run on the target Windows machine

From the repository root with the normal `.env` loaded:

```powershell
.\backend\mvnw.cmd clean test
.\backend\mvnw.cmd clean package
npm --prefix frontend ci
npm --prefix frontend run lint
npm --prefix frontend run build
```

Expected backend test total after Issue 4: **64 tests**.

All tests must report zero failures and zero errors. The package command must create:

```text
backend\target\unidoc-backend-0.0.1-SNAPSHOT.jar
```

## Manual authentication checks

Start the backend, then register a student:

```powershell
$register = @{
  fullName = "Issue Four Student"
  email = "issue4.student@example.test"
  password = "Demo@123"
  confirmPassword = "Demo@123"
} | ConvertTo-Json

Invoke-RestMethod -Method Post `
  -Uri http://localhost:8080/api/auth/register `
  -ContentType "application/json" `
  -Body $register
```

Expected: HTTP 201 data with `role=STUDENT`, `status=ACTIVE`, and no password/token fields.

Login:

```powershell
$login = @{
  email = "issue4.student@example.test"
  password = "Demo@123"
} | ConvertTo-Json

$session = Invoke-RestMethod -Method Post `
  -Uri http://localhost:8080/api/auth/login `
  -ContentType "application/json" `
  -Body $login

$session.tokenType
$session.user.role
$session.expiresAt
```

Expected:

```text
Bearer
STUDENT
<UTC expiry approximately one hour after login>
```

Current account:

```powershell
Invoke-RestMethod `
  -Uri http://localhost:8080/api/auth/me `
  -Headers @{ Authorization = "Bearer $($session.token)" }
```

Expected: the same public user summary and no password/hash/authVersion field.

## Failure checks

Wrong password and unknown email must both return:

```text
HTTP 401
AUTH_INVALID_CREDENTIALS
Email or password is incorrect.
```

A protected route with no token must return the shared `401 AUTHENTICATION_REQUIRED` response. A valid token used against the wrong role family must return `403 ACCESS_DENIED`.

The automated tests additionally verify:

- inactive account login -> `403 ACCOUNT_INACTIVE`;
- stored inactive account with an existing token -> `403 ACCOUNT_INACTIVE`;
- stale `authVersion` -> `401 SESSION_REVOKED`;
- stored role/token role mismatch -> `401 SESSION_REVOKED`;
- missing stored user -> `401 SESSION_REVOKED`;
- invalid signature, expiry, issuer, subject, or role is rejected before controller access.

## CORS checks

From the configured frontend origin, an OPTIONS preflight to `/api/auth/login` must include the matching `Access-Control-Allow-Origin` and POST in allowed methods. Requests from an unrelated origin must not receive an allow-origin header and the preflight is rejected.

The configured CORS surface is intentionally limited to:

```text
Methods: GET, POST, PUT, PATCH, OPTIONS
Request headers: Authorization, Content-Type, Accept, X-Request-ID
Exposed headers: Content-Disposition, X-Request-ID
Credentials: false
```

## Database regression

Issue 4 does not require a schema change. MySQL must still contain only the approved eight application tables:

```text
users
student_profiles
document_types
document_requests
request_attachments
issued_documents
request_status_history
notifications
```

## Completion gate

Issue 4 is complete when:

- all 64 backend tests pass;
- backend packaging succeeds;
- frontend lint/build remain green;
- registration always creates ACTIVE STUDENT accounts;
- BCrypt hashes are stored instead of passwords;
- login returns one-hour HS256 Bearer JWTs;
- only health/register/login are anonymous;
- `/api/auth/me` works for all authenticated roles;
- wrong role returns 403;
- inactive/stale/mismatched sessions are rejected immediately;
- configured CORS behavior passes;
- no token/password/hash appears in API responses or normal logs;
- no new application table has been introduced.

## Upgrade note from Issue 3

Issue 4 replaces the temporary Issue 3 security baseline with `SecurityConfig.java`. A deliberately inert `BaselineSecurityConfig.java` compatibility tombstone is retained so extracting this Issue 4 tree over an older Issue 3 working tree overwrites the legacy security bean instead of leaving a duplicate `securityFilterChain` behind.
