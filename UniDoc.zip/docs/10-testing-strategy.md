# UniDoc Testing Strategy

**Objective:** Prove the proposal-required workflows work correctly with the smallest useful automated suite plus disciplined manual end-to-end verification.  
**Priority:** Workflow correctness, authorization, file safety, and demonstrability before broad coverage.

## 1. Testing principles

1. Test business rules where they live: services.
2. Test security at HTTP boundaries.
3. Test persistence behavior that affects uniqueness, pagination, and locking.
4. Test file storage with temporary directories.
5. Do not require real Gmail for automated tests.
6. Use real MySQL for final smoke testing.
7. Prefer a small high-value suite over many shallow tests.
8. Every proposal requirement receives either automated or explicit manual verification.
9. Defects in required workflows block completion.
10. The final demo is rehearsed from a reset/seeded state.

## 2. Test layers

~~~mermaid
flowchart TB
    Manual["Manual end-to-end and responsive UAT<br/>few, broad scenarios"]
    HTTP["Controller/security tests<br/>routes, roles, errors"]
    Service["Service tests<br/>workflow and ownership"]
    Data["Repository/storage tests<br/>constraints and files"]
    Static["Build, lint, compilation<br/>wide and fast"]

    Static --> Data
    Data --> Service
    Service --> HTTP
    HTTP --> Manual
~~~

### 2.1 Static verification

Backend:

- Java compilation;
- Maven tests;
- package build.

Frontend:

- TypeScript compilation through Vite build;
- ESLint;
- production build.

### 2.2 Unit/service tests

Use JUnit 5, Mockito, and AssertJ through Spring Boot test dependencies.

Targets:

- authentication decisions;
- profile completeness;
- catalogue validation;
- request transition matrix;
- ownership and delivery checks;
- notification creation;
- CSV escaping;
- filename/type validation.

### 2.3 Repository tests

Use @DataJpaTest with an isolated test database.

Practical choice:

- H2 in MySQL compatibility mode for fast automated repository tests;
- mandatory final smoke test against installed MySQL 26.7.0.

H2 is not considered proof of full MySQL compatibility. It verifies repository mappings and constraints quickly.

### 2.4 Web/security tests

Use MockMvc with security test support to verify:

- public/protected routes;
- role restrictions;
- request validation;
- consistent error envelope;
- owner-scoped behavior through mocked/service-backed scenarios;
- multipart endpoints.

### 2.5 Storage tests

Use @TempDir:

- no real data/uploads modification;
- validate signatures and limits;
- stage/move/read;
- traversal-safe resolution;
- cleanup after failure.

### 2.6 Manual end-to-end tests

Run frontend, backend, MySQL, local files, and optional Gmail together. These tests validate user journeys, UI state, and integration.

### 2.7 Excluded test infrastructure

Not required:

- Selenium/Playwright browser automation;
- performance test platform;
- security scanner pipeline;
- containerized CI services;
- mutation testing;
- contract-testing server;
- visual-regression service.

## 3. Test environments

| Environment | Database | Files | Email | Purpose |
| --- | --- | --- | --- | --- |
| Unit | Mocked | Mocked/temp | Mocked | Fast rules |
| Repository | H2 MySQL mode | None | None | JPA/constraints |
| Web slice | Mocked services | Mocked | Mocked | HTTP/security |
| Full local | MySQL 26.7.0 | data/uploads-test or demo root | No-op or Gmail | Final smoke/UAT |

Tests must never point at the normal developer upload root unless explicitly running a manual demo.

## 4. Test data

### 4.1 Core users

| Key | Role | Status |
| --- | --- | --- |
| studentA | STUDENT | ACTIVE |
| studentB | STUDENT | ACTIVE |
| staffA | STAFF | ACTIVE |
| staffB | STAFF | ACTIVE |
| adminA | ADMIN | ACTIVE |
| inactiveStudent | STUDENT | INACTIVE |

### 4.2 Core document types

- both delivery methods, attachments optional;
- both methods, attachments required;
- electronic-only test type;
- physical-only test type;
- inactive type.

The production seed still uses the five proposal document types. Additional test fixtures need not appear in demo data.

### 4.3 File fixtures

- valid small PDF;
- valid JPEG;
- valid PNG;
- empty file;
- PDF larger than 5 MiB for supporting limit;
- PDF larger than 10 MiB for issued limit;
- text file named .pdf;
- PDF bytes named .jpg;
- traversal-style original filename;
- filename with spaces, Unicode, quotes, and comma.

Fixtures contain no real personal information.

## 5. Automated backend suite

## 5.1 AuthenticationServiceTests

Minimum cases:

1. register valid student;
2. normalize email;
3. public registration always creates STUDENT;
4. duplicate email rejected;
5. password mismatch rejected;
6. password stored as BCrypt, not plain text;
7. login valid active account;
8. login wrong password returns generic failure;
9. login unknown email returns same generic failure;
10. login inactive account rejected;
11. token contains subject, role, authVersion, issuer, expiry;
12. invalid JWT configuration rejected at startup/service creation.

## 5.2 ActiveUserFilterTests

1. active matching account continues;
2. missing stored user rejected;
3. inactive account rejected;
4. stale authVersion rejected;
5. stored role mismatch rejected;
6. token/Authorization not logged.

## 5.3 UserServiceTests

1. admin creates STAFF;
2. admin creates ADMIN;
3. service rejects STUDENT via admin-create endpoint if contract excludes it;
4. duplicate email;
5. deactivate increments authVersion;
6. activating again increments only when state changes;
7. setting same status is idempotent;
8. self-deactivation rejected;
9. password reset hashes new password;
10. password reset increments authVersion;
11. user list filters/allowed sorts.

## 5.4 StudentProfileServiceTests

1. missing profile response complete false;
2. create profile;
3. update profile and account full name atomically;
4. unique registration number;
5. student can update only own profile through service identity;
6. academic year boundaries 1 and 8 accepted;
7. 0 and 9 rejected;
8. complete flag correct.

## 5.5 DocumentTypeServiceTests

1. create valid both-method type;
2. at least one method required;
3. physical method requires location;
4. duplicate code rejected case-insensitively;
5. duplicate name rejected;
6. update fields;
7. deactivate;
8. active catalogue excludes inactive;
9. admin list includes inactive;
10. code normalization.

## 5.6 DocumentRequestServiceTests - creation

1. complete profile can submit;
2. incomplete profile rejected;
3. inactive/missing document type rejected;
4. past required date rejected;
5. today accepted;
6. future accepted;
7. unavailable delivery method rejected;
8. required attachment enforced;
9. optional attachment may be omitted;
10. request starts SUBMITTED;
11. request number generated;
12. catalogue snapshots copied;
13. physical collection snapshots copied;
14. initial history created;
15. student notification created;
16. active staff notified;
17. no inactive staff notification;
18. transaction rolls back when storage metadata step fails.

## 5.7 DocumentRequestServiceTests - transitions

Valid:

1. SUBMITTED → UNDER_REVIEW;
2. UNDER_REVIEW → ADDITIONAL_INFORMATION_REQUIRED with message;
3. ADDITIONAL_INFORMATION_REQUIRED → SUBMITTED with student response;
4. UNDER_REVIEW → APPROVED;
5. UNDER_REVIEW → REJECTED with reason;
6. APPROVED → PROCESSING;
7. electronic PROCESSING → READY with issued document;
8. physical PROCESSING → READY;
9. electronic READY → COMPLETED on first student download;
10. physical READY → COMPLETED with collection date.

For every valid transition assert:

- status;
- version;
- status-specific field;
- history previous/new/actor/note;
- expected notification recipients/types.

Invalid:

- every action from every unsupported status;
- rejected cannot transition;
- completed cannot transition;
- student cannot perform staff action;
- admin cannot perform staff action;
- staff cannot submit student response;
- non-owner cannot submit response;
- electronic ready-for-collection rejected;
- physical PDF upload rejected;
- second issued PDF rejected;
- physical collection future date rejected;
- missing information message rejected;
- missing rejection reason rejected;
- stale expectedVersion conflict.

A parameterized transition test should enumerate allowed transitions so missing cases are obvious.

## 5.8 Request query tests

1. student list contains only own requests;
2. status filter;
3. delivery filter;
4. default sort newest first;
5. page boundaries;
6. max size validation;
7. staff text search by request number;
8. staff search by name/email/registration;
9. document type filter;
10. created date inclusive range;
11. unsupported sort rejected;
12. admin read does not call mutation service.

## 5.9 FileStorageServiceTests

1. valid PDF accepted;
2. valid JPEG accepted;
3. valid PNG accepted;
4. empty rejected;
5. supporting >5 MiB rejected;
6. issued >10 MiB rejected;
7. fourth file rejected;
8. text disguised as PDF rejected;
9. MIME/signature mismatch rejected;
10. generated filename is UUID-based;
11. original name does not influence path;
12. traversal name cannot escape root;
13. root normalization enforced;
14. staged file moved;
15. failed operation cleans staged file;
16. read missing file safe error;
17. returned metadata has relative path only.

## 5.10 NotificationServiceTests

1. create unread notification;
2. list only recipient;
3. unread count;
4. mark read sets readAt;
5. mark read idempotent;
6. mark all affects only recipient;
7. pagination newest first;
8. email event published after notification creation contract.

## 5.11 Email listener tests

1. enabled sender builds expected subject/body;
2. action URL normalized;
3. missing from address safely skips/warns;
4. missing recipient safely skips/warns;
5. send exception swallowed/logged;
6. email failure does not change domain result;
7. listener not invoked for rolled-back transaction, where an integration test is practical.

## 5.12 ReportServiceTests

1. total count;
2. pending definition;
3. exact status counts;
4. electronic/physical counts;
5. grouping by type;
6. recent ten order;
7. screen filters;
8. CSV uses same filters;
9. CSV header/order;
10. comma/quote/newline escaping;
11. Unicode;
12. formula-injection protection;
13. empty result produces header only.

## 6. Repository tests

### UserRepository

- normalized email lookup;
- unique email;
- role/status filtering and pageable results.

### StudentProfileRepository

- one profile per user;
- unique registration number.

### DocumentTypeRepository

- unique code/name;
- active sorted catalogue.

### DocumentRequestRepository

- student-scoped lookup;
- staff/admin specification filters;
- repository pagination;
- status counts;
- optimistic locking conflict;
- created-date range.

### IssuedDocumentRepository

- unique request ID.

### NotificationRepository

- recipient/read filtering;
- unread count;
- pageable newest-first.

## 7. Web and security tests

## 7.1 Public routes

- health permitted;
- register permitted;
- login permitted;
- protected route without token returns 401 JSON.

## 7.2 Role routes

For each role, verify access and denial:

| Route | Student | Staff | Admin |
| --- | :---: | :---: | :---: |
| /api/student/profile | 2xx | 403 | 403 |
| /api/student/requests | 2xx | 403 | 403 |
| /api/staff/requests | 403 | 2xx | 403 |
| /api/admin/users | 403 | 403 | 2xx |
| /api/notifications | 2xx | 2xx | 2xx |
| /api/document-types | 2xx | 2xx | 2xx |

## 7.3 Validation/error shape

- malformed JSON;
- invalid enum;
- missing required field;
- invalid page/size;
- invalid sort;
- multipart without request part;
- file too large application error;
- error contains requestId;
- error does not contain stackTrace/exception.

## 7.4 Ownership tests

- student A detail for student B returns 404;
- student A attachment for B returns 404;
- student A issued file for B returns 404;
- user A notification ID belonging to B returns 404.

## 7.5 Multipart tests

- request JSON + valid files;
- no files optional;
- files required;
- additional response;
- issued PDF upload;
- incorrect part content type.

## 8. Frontend verification

The initial project does not require a frontend unit-test framework. Required automated frontend gates are:

- npm run lint;
- npm run build.

Manual component/page checks cover the proposal scope.

If time remains after all required behavior, add only a small Vitest/React Testing Library set for:

- ProtectedRoute;
- RoleRoute;
- RequestStatus label mapping;
- PageState loading/empty/error behavior.

Do not delay required workflows to build a large frontend test suite.

## 9. Manual end-to-end scenarios

### E2E-01 Student registration and profile

1. Open registration.
2. Submit invalid fields; confirm local/server errors.
3. Register valid unrestricted email.
4. Login.
5. Attempt new request with incomplete profile; confirm blocked.
6. Complete profile.
7. Refresh and confirm profile persists.

Expected: only STUDENT account; request allowed after profile complete.

### E2E-02 Electronic request happy path

1. Student opens active catalogue.
2. Selects document type.
3. Chooses ELECTRONIC.
4. enters purpose/future date.
5. uploads valid file where required.
6. submits.
7. staff starts review.
8. staff approves.
9. staff starts processing.
10. staff uploads issued PDF.
11. student sees READY notification.
12. student downloads.
13. detail refresh shows COMPLETED.
14. student downloads again.

Expected:

- first download completes;
- second remains allowed;
- one completion history record.

### E2E-03 Additional-information cycle

1. Staff starts review.
2. asks for information with required message.
3. student sees message and email.
4. student submits written response and optional files.
5. status returns SUBMITTED.
6. staff receives notification.
7. history shows both messages.
8. staff starts review again.

### E2E-04 Rejection

1. Request reaches UNDER_REVIEW.
2. attempt rejection without reason; blocked.
3. reject with reason.
4. student sees REJECTED, reason, notification.
5. verify no further actions.

### E2E-05 Physical request

1. Student submits PHYSICAL.
2. staff reviews, approves, processes.
3. staff marks ready.
4. student sees location/instructions.
5. staff attempts future collection date; rejected.
6. staff records valid date/note.
7. student sees COMPLETED.

### E2E-06 Authorization

1. Obtain student A request ID.
2. sign in as student B.
3. attempt direct URL/API access.
4. verify 404 and no leaked details.
5. try student token on staff/admin APIs.
6. try staff token on admin and admin token on staff transition.

### E2E-07 Admin

1. Create staff account.
2. deactivate and confirm login/session rejection.
3. reactivate.
4. reset password and confirm old token/password invalid.
5. create/edit/deactivate catalogue type.
6. confirm inactive type absent from student catalogue.
7. confirm old request still displays snapshot.

### E2E-08 Dashboard/report

1. Compare dashboard counts with known seed.
2. apply each report filter.
3. combine filters.
4. export CSV.
5. open CSV and verify rows match filters.
6. verify special text safely quoted.

### E2E-09 Email failure

1. Configure invalid SMTP or temporarily disable network.
2. perform status action.
3. confirm action succeeds.
4. confirm in-app notification.
5. confirm warning log.

### E2E-10 Reset/reseed

1. stop backend.
2. run reset.
3. cancel once to prove safe exit.
4. run with RESET.
5. reseed/start.
6. confirm deterministic accounts and counts.
7. confirm upload directory was not deleted.

## 10. Responsive and accessibility test

Test at:

- 360 × 800;
- 768 × 1024;
- 1366 × 768.

Checklist:

- navigation usable;
- no horizontal page overflow;
- tables/cards readable;
- filter controls wrap;
- dialogs remain in viewport;
- forms have visible labels;
- errors are associated with inputs;
- focus visible;
- keyboard can operate navigation, forms, dialogs;
- status meaning is textual;
- colour contrast adequate;
- icon-only button has accessible label;
- reduced motion prevents unnecessary animation;
- file names wrap.

## 11. Browser compatibility

Required:

- current Chrome;
- current Edge.

Firefox is SHOULD if time permits. Safari and mobile native browsers are not required, though responsive emulation is required.

## 12. Performance smoke tests

With demo or generated test data:

- 500 users;
- 2,000 requests;
- 5,000 notifications/history rows as practical.

Check:

- first request page under 2 seconds locally;
- staff filter under 2 seconds locally;
- dashboard/report under 3 seconds locally;
- no endpoint returns all records accidentally;
- database queries use pagination;
- browser remains responsive.

No load-testing tool is required. Use browser network timing and backend logs.

## 13. Requirement traceability

| Requirement group | Automated | Manual |
| --- | --- | --- |
| Registration/login | Service + security | E2E-01 |
| Profile | Service/web | E2E-01 |
| Catalogue | Service/repository | E2E-02, E2E-07 |
| Submission/files | Service/storage/web | E2E-02 |
| Tracking/history | Service/query | E2E-02/03 |
| Additional information | Transition tests | E2E-03 |
| Approval/rejection | Transition tests | E2E-02/04 |
| Electronic delivery | Storage/transition/security | E2E-02 |
| Physical delivery | Transition tests | E2E-05 |
| Notifications/email | Service/listener | E2E-03/09 |
| Account management | Service/security | E2E-07 |
| Dashboard/report | Service/repository | E2E-08 |
| Responsive usability | Lint/build only | Accessibility checklist |
| Local deployment/reset | Startup checks where practical | E2E-10 |

## 14. Quality gates

### Gate 1 - Compile

- backend compiles;
- frontend TypeScript builds.

### Gate 2 - Automated tests

- Maven test suite passes;
- no ignored failing core tests.

### Gate 3 - Static frontend

- ESLint passes with zero errors;
- build passes.

### Gate 4 - Core smoke

- health;
- three role logins;
- active catalogue;
- create request;
- staff transition;
- file upload/download;
- dashboard.

### Gate 5 - Full UAT

- E2E-01 through E2E-10;
- responsive/accessibility checklist;
- Gmail success once when configured.

### Gate 6 - Demo rehearsal

- reset/reseed;
- run complete presentation path;
- no manual database repair;
- no secret exposure;
- complete within demonstration time.

## 15. Defect severity

| Severity | Definition | Examples | Release effect |
| --- | --- | --- | --- |
| Critical | Security/data loss or app cannot start | Cross-student document access; DB reset unguarded | Must fix |
| High | Proposal workflow blocked | Cannot approve; download fails; login broken | Must fix |
| Medium | Workaround exists or secondary requirement damaged | Filter incorrect; one notification missing | Fix before final if possible |
| Low | Cosmetic/minor wording | Spacing, nonblocking alignment | Fix after functional work |

## 16. Regression checklist after workflow changes

Whenever request workflow code changes:

- run parameterized transition tests;
- run ownership tests;
- run optimistic-lock test;
- run notification tests;
- test both delivery methods;
- test additional-information cycle;
- test report count effect;
- build frontend;
- manually open student and staff detail.

## 17. Test execution commands

Backend:

~~~powershell
cd backend
.\mvnw.cmd test
~~~

One class:

~~~powershell
.\mvnw.cmd -Dtest=DocumentRequestServiceTests test
~~~

Frontend:

~~~powershell
cd frontend
npm ci
npm run lint
npm run build
~~~

Full local:

~~~powershell
.\start-dev.cmd
~~~

## 18. Test-result record

Before submission, record:

| Item | Result | Date/time | Notes |
| --- | --- | --- | --- |
| Backend tests | Pass/fail |  | Count |
| Backend package | Pass/fail |  |  |
| Frontend lint | Pass/fail |  |  |
| Frontend build | Pass/fail |  |  |
| Electronic E2E | Pass/fail |  |  |
| Physical E2E | Pass/fail |  |  |
| Additional info | Pass/fail |  |  |
| Authorization | Pass/fail |  |  |
| Gmail email | Pass/fail |  | Account masked |
| CSV export | Pass/fail |  |  |
| Reset/reseed | Pass/fail |  |  |
| Mobile/tablet/desktop | Pass/fail |  |  |

## 19. Exit criteria

UniDoc is test-complete when:

- all Critical/High defects are closed;
- required automated tests pass;
- frontend lint/build pass;
- MySQL smoke test passes;
- both delivery paths pass;
- additional-information and rejection paths pass;
- cross-user/cross-role access is blocked;
- reset and seed are repeatable;
- Gmail is verified once or explicitly documented as disabled for the run;
- report/CSV match;
- responsive views are usable;
- final rehearsal succeeds without source/database edits.

## 20. Deferred testing improvements

- Playwright browser suite;
- Testcontainers MySQL in CI;
- code-coverage threshold;
- load testing;
- SAST/dependency scanning gate;
- accessibility automation;
- visual regression;
- SMTP test server;
- chaos/failure injection.

They are valuable for a larger project but not required to fulfill the proposal within the deadline.
