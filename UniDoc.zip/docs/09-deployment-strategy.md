# UniDoc Deployment Strategy

**Deployment target:** One local Windows development/demonstration laptop  
**Not in scope:** Cloud hosting, containers, public DNS, TLS termination, production monitoring, or high availability  
**Default ports:** Frontend 5173, backend 8080, MySQL 3306

## 1. Deployment objective

The deployment must let a developer or demonstrator:

1. clone or extract the repository;
2. create local configuration from a safe example;
3. prepare the MySQL database;
4. start backend and frontend with one Windows command;
5. open a working seeded application;
6. demonstrate email when configured;
7. reset database demo records safely; and
8. diagnose common startup failures without editing source code.

The strategy optimizes for reliable local demonstration and minimal setup effort.

## 2. Runtime topology

~~~mermaid
flowchart TB
    Browser["Chrome / Edge"]
    Vite["React/Vite<br/>localhost:5173"]
    Spring["Spring Boot<br/>localhost:8080"]
    MySQL[("MySQL 26.7.0<br/>localhost:3306")]
    Files[("Repository data/uploads")]
    Gmail["smtp.gmail.com:587"]

    Browser --> Vite
    Vite --> Spring
    Spring --> MySQL
    Spring --> Files
    Spring -.-> Gmail
~~~

## 3. Prerequisites

Required:

- Windows 10 or 11;
- Java Development Kit 21;
- Node.js version supported by the selected Vite release;
- npm;
- MySQL Server 26.7.0;
- MySQL Workbench or MySQL command-line client;
- Git;
- internet during initial dependency installation;
- Gmail account with 2-Step Verification and an App Password for email demonstration.

Recommended:

- Visual Studio Code;
- current Chrome or Edge;
- Postman for API demonstration.

### 3.1 Verification commands

~~~powershell
java -version
node --version
npm --version
mysql --version
git --version
~~~

Java output must identify version 21.

## 4. Repository layout

~~~text
UniDoc/
├── backend/
│   ├── mvnw
│   ├── mvnw.cmd
│   ├── pom.xml
│   └── src/
├── frontend/
│   ├── package.json
│   ├── package-lock.json
│   └── src/
├── data/
│   └── uploads/
├── docs/
├── scripts/
│   ├── start-dev.ps1
│   └── reset-demo-data.ps1
├── .env.example
├── .gitignore
├── start-dev.cmd
├── reset-demo-data.cmd
└── README.md
~~~

Generated/secret paths ignored by Git:

~~~text
.env
frontend/.env.local
frontend/node_modules/
frontend/dist/
backend/target/
data/uploads/*
!data/uploads/.gitkeep
*.log
~~~

## 5. MySQL preparation

### 5.1 Create schema and application user

Run as a MySQL administrator:

~~~sql
CREATE DATABASE IF NOT EXISTS unidoc
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

CREATE USER IF NOT EXISTS 'unidoc_app'@'localhost'
  IDENTIFIED BY 'replace-with-a-strong-local-password';

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES
ON unidoc.* TO 'unidoc_app'@'localhost';

FLUSH PRIVILEGES;
~~~

Do not use the MySQL root account in the application.

### 5.2 Development schema behavior

Use:

~~~properties
spring.jpa.hibernate.ddl-auto=update
~~~

for this local project.

Reason:

- quickest setup within the deadline;
- JPA mappings create/update the local schema;
- no production migration requirement exists.

Before the final demo:

1. export any data worth keeping;
2. create a clean unidoc database once;
3. start the backend;
4. verify the complete schema appears;
5. seed and run the demonstration.

### 5.3 Connection URL

Suggested:

~~~text
jdbc:mysql://localhost:3306/unidoc?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
~~~

Local useSSL=false is acceptable for a same-machine demonstration. It is not a public-deployment recommendation.

## 6. Environment configuration

Root .env.example:

~~~dotenv
# Database
UNIDOC_DB_URL=jdbc:mysql://localhost:3306/unidoc?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
UNIDOC_DB_USERNAME=unidoc_app
UNIDOC_DB_PASSWORD=replace_me

# JWT
UNIDOC_JWT_SECRET=replace_with_base64_32_byte_secret
UNIDOC_JWT_EXPIRATION_SECONDS=3600

# Browser/API
UNIDOC_ALLOWED_ORIGINS=http://localhost:5173
VITE_API_BASE_URL=http://localhost:8080
UNIDOC_FRONTEND_URL=http://localhost:5173

# Storage
UNIDOC_STORAGE_ROOT=./data/uploads
UNIDOC_SUPPORTING_MAX_BYTES=5242880
UNIDOC_ISSUED_MAX_BYTES=10485760

# Email
UNIDOC_EMAIL_ENABLED=false
UNIDOC_EMAIL_FROM=
UNIDOC_SMTP_HOST=smtp.gmail.com
UNIDOC_SMTP_PORT=587
UNIDOC_SMTP_USERNAME=
UNIDOC_SMTP_APP_PASSWORD=
UNIDOC_SMTP_AUTH=true
UNIDOC_SMTP_STARTTLS=true

# Demo
UNIDOC_SEED_DEMO=true
UNIDOC_RESET_DEMO=false
UNIDOC_RESET_CONFIRMATION=
~~~

Rules:

- Copy .env.example to .env.
- Never commit .env.
- No spaces around variable names.
- Gmail App Password is stored without exposing it in screenshots.
- VITE_API_BASE_URL is public configuration, not a secret.
- Backend secrets never use VITE_ prefix.

## 7. JWT secret generation

The startup script may generate a missing local secret using .NET cryptography.

Equivalent PowerShell:

~~~powershell
$bytes = New-Object byte[] 32
[System.Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
[Convert]::ToBase64String($bytes)
~~~

Store the output as UNIDOC_JWT_SECRET.

The backend:

- Base64-decodes it;
- requires at least 32 bytes;
- fails startup if invalid.

## 8. Gmail SMTP setup

1. Enable 2-Step Verification on the selected Google account.
2. Create an App Password for UniDoc.
3. Set:

~~~dotenv
UNIDOC_EMAIL_ENABLED=true
UNIDOC_EMAIL_FROM=your-address@gmail.com
UNIDOC_SMTP_USERNAME=your-address@gmail.com
UNIDOC_SMTP_APP_PASSWORD=the_app_password
~~~

4. Keep host smtp.gmail.com, port 587, authentication true, STARTTLS true.
5. Start the application.
6. Trigger a request event and verify both in-app and email notification.

Recommended timeouts:

~~~properties
spring.mail.properties.mail.smtp.connectiontimeout=5000
spring.mail.properties.mail.smtp.timeout=5000
spring.mail.properties.mail.smtp.writetimeout=5000
~~~

If email is disabled, a NoOpEmailSender allows all core workflows to run.

## 9. Backend configuration mapping

application.properties:

~~~properties
spring.application.name=UniDoc

spring.datasource.url=${UNIDOC_DB_URL}
spring.datasource.username=${UNIDOC_DB_USERNAME}
spring.datasource.password=${UNIDOC_DB_PASSWORD}
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.open-in-view=false
spring.jpa.properties.hibernate.jdbc.time_zone=UTC

app.jwt.secret=${UNIDOC_JWT_SECRET}
app.jwt.expiration-seconds=${UNIDOC_JWT_EXPIRATION_SECONDS:3600}
app.cors.allowed-origins=${UNIDOC_ALLOWED_ORIGINS:http://localhost:5173}
app.frontend-url=${UNIDOC_FRONTEND_URL:http://localhost:5173}

app.storage.root=${UNIDOC_STORAGE_ROOT:./data/uploads}
app.storage.supporting-max-bytes=${UNIDOC_SUPPORTING_MAX_BYTES:5242880}
app.storage.issued-max-bytes=${UNIDOC_ISSUED_MAX_BYTES:10485760}

app.email.enabled=${UNIDOC_EMAIL_ENABLED:false}
app.email.from=${UNIDOC_EMAIL_FROM:}

spring.mail.host=${UNIDOC_SMTP_HOST:smtp.gmail.com}
spring.mail.port=${UNIDOC_SMTP_PORT:587}
spring.mail.username=${UNIDOC_SMTP_USERNAME:}
spring.mail.password=${UNIDOC_SMTP_APP_PASSWORD:}
spring.mail.properties.mail.smtp.auth=${UNIDOC_SMTP_AUTH:true}
spring.mail.properties.mail.smtp.starttls.enable=${UNIDOC_SMTP_STARTTLS:true}
spring.mail.properties.mail.smtp.connectiontimeout=5000
spring.mail.properties.mail.smtp.timeout=5000
spring.mail.properties.mail.smtp.writetimeout=5000

app.demo.seed-enabled=${UNIDOC_SEED_DEMO:false}
app.demo.reset-enabled=${UNIDOC_RESET_DEMO:false}
app.demo.reset-confirmation=${UNIDOC_RESET_CONFIRMATION:}

spring.servlet.multipart.max-file-size=10MB
spring.servlet.multipart.max-request-size=20MB

server.error.include-message=never
server.error.include-binding-errors=never
server.error.include-stacktrace=never
server.error.include-exception=false
~~~

Application-level validation still enforces 5 MiB student files and 10 MiB issued PDF. Multipart server limits are a coarse outer boundary.

## 10. One-click startup

### 10.1 start-dev.cmd

Simple wrapper:

~~~batch
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start-dev.ps1"
~~~

### 10.2 start-dev.ps1 responsibilities

The script shall:

1. locate repository, backend, and frontend directories;
2. verify java, node, and npm;
3. confirm Java 21;
4. create .env from .env.example when missing;
5. import key-value configuration;
6. validate required database values;
7. generate JWT secret if missing;
8. create/update frontend/.env.local with VITE_API_BASE_URL;
9. run npm ci when node_modules is missing or lock file changed;
10. ensure data/uploads and data/uploads/.tmp exist;
11. start backend in a new PowerShell window;
12. poll http://localhost:8080/api/health for up to 180 seconds;
13. stop with accurate error if health never succeeds;
14. start frontend in another PowerShell window;
15. show URLs and configuration location;
16. open http://localhost:5173.

The displayed timeout text must match the actual timeout.

### 10.3 Manual startup fallback

Backend:

~~~powershell
cd backend
.\mvnw.cmd spring-boot:run
~~~

Frontend:

~~~powershell
cd frontend
npm ci
npm run dev
~~~

## 11. Build verification

Backend:

~~~powershell
cd backend
.\mvnw.cmd clean test
.\mvnw.cmd clean package
~~~

Expected artifact:

~~~text
backend/target/unidoc-backend-0.0.1-SNAPSHOT.jar
~~~

Frontend:

~~~powershell
cd frontend
npm ci
npm run lint
npm run build
~~~

Expected:

~~~text
frontend/dist/
~~~

The local demonstration normally runs the Vite dev server and Spring Boot separately. Packaging the frontend into the backend is unnecessary.

## 12. Demo seed

When UNIDOC_SEED_DEMO=true:

- seed after application context/database availability;
- create deterministic accounts;
- create profiles;
- create five document types;
- create representative requests/status history;
- create notifications;
- create safe sample file metadata only when matching sample files are also created.

Suggested accounts:

~~~text
admin.demo@unidoc.test
staff.demo@unidoc.test
student.demo@unidoc.test
~~~

Use one local-only documented password. The seeder hashes it.

Seed requirements:

- idempotent normal startup;
- clear INFO summary without printing password;
- no dependency on real Gmail addresses;
- no email sending during seed unless explicitly intended.

## 13. Guarded demo reset

### 13.1 reset-demo-data.cmd

~~~batch
@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\reset-demo-data.ps1"
~~~

### 13.2 Reset safety

The script:

1. shows the target database URL/schema without password;
2. warns that database data will be deleted;
3. states uploads will not be deleted;
4. requires typing RESET exactly;
5. requires normal backend to be stopped;
6. sets:
   - UNIDOC_RESET_DEMO=true;
   - UNIDOC_RESET_CONFIRMATION=RESET-UNIDOC-DEMO;
   - SERVER_PORT=0;
7. starts the backend reset runner;
8. clears records in dependency order;
9. exits rather than starting the normal web server;
10. optionally instructs how to reseed.

The backend reset runner independently validates both flags. Script confirmation alone is insufficient.

### 13.3 Upload preservation

Reset deliberately does not delete data/uploads.

Consequences:

- database demo state resets;
- upload directory may contain old orphan files;
- user may manually archive/remove the directory after confirming it is safe;
- automatic cleanup is excluded.

## 14. Demonstration runbook

### 14.1 Before demonstration

- pull/finalize correct branch;
- confirm .env exists;
- start MySQL service;
- reset and reseed database;
- configure or intentionally disable email;
- start application;
- verify health;
- run frontend login for all three roles;
- verify demo issued PDF exists;
- clear browser console errors;
- confirm screen widths;
- ensure system clock/date correct;
- keep MySQL Workbench and source code closed unless needed.

### 14.2 Suggested demonstration order

1. Show landing/login.
2. Sign in as student.
3. Show profile and catalogue.
4. Submit request with attachment.
5. Show submitted status/history/notifications.
6. Sign in as staff.
7. Start review and request information.
8. Sign in as student and respond.
9. Sign in as staff, approve, process, upload issued PDF.
10. Sign in as student and download; show automatic completion.
11. Show a seeded physical request and complete collection.
12. Sign in as admin.
13. Show user and catalogue management.
14. Show dashboard.
15. Filter report and export CSV.

Use seeded requests for time-consuming middle states when necessary, but demonstrate at least one genuine end-to-end flow.

## 15. Port conflict handling

Check ports:

~~~powershell
Get-NetTCPConnection -LocalPort 5173,8080,3306 -ErrorAction SilentlyContinue |
  Select-Object LocalPort, State, OwningProcess
~~~

Identify process:

~~~powershell
Get-Process -Id <PID>
~~~

Only stop a process after confirming it belongs to an old UniDoc development instance.

Do not automatically kill unknown processes from startup.

## 16. Troubleshooting

### 16.1 Backend cannot connect to MySQL

Check:

- MySQL Windows service running;
- correct port;
- database exists;
- username/password;
- user host localhost;
- URL options;
- MySQL logs.

Expected API does not become healthy until database connection/schema succeeds.

### 16.2 Access denied for database user

Re-run grants and confirm:

~~~sql
SHOW GRANTS FOR 'unidoc_app'@'localhost';
~~~

### 16.3 JWT secret invalid

Generate a new 32-byte Base64 secret. Existing browser tokens then become invalid; sign in again.

### 16.4 CORS error

Ensure the exact frontend origin is in UNIDOC_ALLOWED_ORIGINS:

~~~text
http://localhost:5173
~~~

Origin includes scheme and port and has no trailing path.

### 16.5 File upload fails

Check:

- data/uploads exists;
- backend process can write;
- size;
- file type/signature;
- disk space;
- server multipart limit;
- storage error log with request ID.

### 16.6 Gmail authentication fails

Check:

- 2-Step Verification enabled;
- App Password, not account password;
- username/from address;
- STARTTLS true;
- port 587;
- no spaces accidentally added;
- internet access.

Core workflow should still succeed with in-app notifications.

### 16.7 Frontend shows network error

Check:

- backend health URL;
- VITE_API_BASE_URL;
- frontend restarted after .env.local change;
- port 8080;
- browser network tab.

### 16.8 Seed duplicates

Seeder must find natural identifiers before insert. If duplicates appear, fix idempotency and reset; do not add random delays or ignore unique errors.

## 17. Local operational security

- Use unidoc_app, not MySQL root.
- Keep .env and Gmail App Password private.
- Do not screen-share .env.
- Do not commit data/uploads.
- Use only synthetic demo personal information.
- Disable email or use addresses controlled by the developer.
- Do not expose ports through router/firewall.
- Stop backend/frontend after demonstration.

## 18. Rollback

Because this is local:

- source rollback uses Git;
- database rollback uses a matching mysqldump if one was created;
- upload rollback uses a matching folder copy;
- there is no zero-downtime deployment.

Before risky final-day changes:

1. commit working source;
2. export database;
3. copy uploads if important;
4. apply change;
5. run smoke test.

## 19. Final deployment checklist

- [ ] Java 21 detected.
- [ ] Node/npm detected.
- [ ] MySQL 26.7.0 running.
- [ ] unidoc schema exists.
- [ ] unidoc_app has correct grants.
- [ ] .env ignored and complete.
- [ ] JWT secret valid.
- [ ] upload root writable.
- [ ] backend tests pass.
- [ ] backend package succeeds.
- [ ] frontend lint passes.
- [ ] frontend build succeeds.
- [ ] health endpoint returns ok.
- [ ] seed is deterministic.
- [ ] reset requires confirmation and preserves uploads.
- [ ] Gmail success tested or email intentionally disabled.
- [ ] student/staff/admin logins work.
- [ ] both delivery flows work.
- [ ] report CSV opens correctly.
- [ ] responsive views checked.
- [ ] no secrets visible in Git status or screenshots.

## 20. Future deployment changes not included

Before any public deployment, the architecture would need decisions for:

- HTTPS and reverse proxy;
- managed database;
- persistent shared object storage;
- backups and retention;
- environment secret manager;
- production CORS origins;
- rate limiting;
- malware scanning;
- durable email retry/outbox;
- monitoring and alerting;
- privacy policy and institutional authorization.

These are explicitly deferred and must not consume current implementation time.
