# UniDoc Security Design

**Security objective:** Protect accounts, student information, request records, and uploaded documents using controls appropriate for a local academic system.  
**Primary model:** Stateless Bearer JWT plus server-side account, role, ownership, workflow, and file checks.

## 1. Security scope

UniDoc handles:

- student identity and contact information;
- academic profile information;
- reasons for requesting official documents;
- uploaded supporting documents;
- final issued electronic documents;
- account credentials;
- workflow decisions; and
- administrative reports.

The main risks are unauthorized record access, unauthorized workflow changes, account misuse, unsafe file handling, secret exposure, and accidental information leakage.

This design addresses the local project. It does not claim internet-facing production certification, high-assurance document signing, malware scanning, or institutional compliance approval.

## 2. Security principles

1. **Deny by default.** Only explicitly public endpoints are anonymous.
2. **Backend authority.** Frontend visibility is never an authorization control.
3. **Least privilege.** Each role receives only required capabilities.
4. **Record checks after role checks.** Being a student does not grant access to another student's request.
5. **State checks before mutation.** Staff role alone does not permit an invalid transition.
6. **Safe file indirection.** Clients use database IDs, never file paths.
7. **No secrets in source.** Credentials and signing material come from ignored environment configuration.
8. **Minimal exposure.** DTOs return only fields needed by the caller.
9. **Fail closed.** Invalid/expired/revoked tokens and missing ownership fail before business actions.
10. **Useful but safe errors.** Client errors are specific enough to correct input without returning stack traces or sensitive details.

## 3. Trust boundaries

~~~mermaid
flowchart LR
    Browser["Untrusted browser<br/>input and session"]
    Filter["Security filters<br/>JWT and account"]
    Service["Domain services<br/>role, ownership, state"]
    Store["Trusted data boundary<br/>MySQL and local files"]
    SMTP["External Gmail SMTP"]

    Browser -->|"Validate everything"| Filter
    Filter -->|"Authenticated principal"| Service
    Service -->|"Authorized query/write"| Store
    Service -.->|"Limited notification data"| SMTP
~~~

Trust decisions:

- Browser form validation is untrusted.
- JWT is accepted only after cryptographic and claim validation.
- The stored user record is the authority for current role/status/auth version.
- Database IDs do not imply permission.
- Local filesystem content is served only after database relationship checks.
- SMTP is allowed to fail and never controls application state.

## 4. Authentication design

### 4.1 Registration

Public registration:

- accepts only student accounts;
- ignores/rejects any supplied privileged role;
- normalizes email;
- validates password rules;
- hashes password before persistence;
- returns no token unless implementation explicitly changes this contract;
- returns no password or hash.

### 4.2 Password hashing

- Algorithm: BCrypt.
- Cost: 12.
- Maximum accepted password length: 72 characters because BCrypt considers only the first 72 bytes.
- Minimum: 8 characters.
- Complexity: upper, lower, number, special.
- Password is handled as briefly as practical.
- Password is never logged.

The system does not encrypt recoverable passwords and does not email passwords.

### 4.3 Login

Login sequence:

1. normalize email with trim and lowercase;
2. find account by normalized email;
3. use one generic failure for unknown email or incorrect password;
4. reject inactive account;
5. verify BCrypt password;
6. issue JWT;
7. return public user summary.

Suggested generic failure:

~~~text
Email or password is incorrect.
~~~

### 4.4 JWT format

Algorithm:

- HS256.

Configuration:

- secret is Base64 encoded;
- decoded secret is at least 32 random bytes;
- issuer is unidoc;
- default lifetime is 3600 seconds;
- permitted configured lifetime is 300 to 86400 seconds;
- application fails startup for an invalid secret or unreasonable lifetime.

Claims:

| Claim | Meaning |
| --- | --- |
| sub | User ID as string |
| iss | unidoc |
| iat | Issued time |
| exp | Expiry time |
| email | Normalized email, informational |
| role | STUDENT, STAFF, or ADMIN |
| authVersion | Current user auth generation |

No sensitive profile, password, or file data is placed in the token.

### 4.5 Token validation

The resource server checks:

- signature;
- issuer;
- expiry;
- required subject;
- supported role claim.

An authenticated-request filter then loads the stored user and checks:

- user still exists;
- status is ACTIVE;
- JWT authVersion equals stored auth_version;
- JWT role equals stored role.

This database check intentionally occurs for each authenticated request. It provides immediate account deactivation and password-reset revocation without a token blacklist.

### 4.6 Session storage

The React frontend stores the login response in sessionStorage.

Benefits:

- survives a normal refresh;
- is removed when the browser tab/session ends;
- is less persistent than localStorage.

Known limitation:

- JavaScript can access it, so XSS prevention remains important.

The frontend:

- adds Authorization through one Axios interceptor;
- never writes the token to logs;
- clears the session on expired/revoked/invalid authentication;
- clears the session on ACCOUNT_INACTIVE;
- does not place the token in URLs.

### 4.7 Sign-out

Sign-out clears:

- sessionStorage entry;
- in-memory AuthContext state;
- role-specific cached UI state where applicable.

An unexpired token copied before sign-out remains cryptographically valid until expiry. This is acceptable for the local stateless MVP. Password reset, status change, or authVersion change invalidates it earlier.

## 5. Authorization design

Authorization has four layers.

### 5.1 Route role

Spring Security route families:

| Route family | Role |
| --- | --- |
| /api/student/** | STUDENT |
| /api/staff/** | STAFF |
| /api/admin/** | ADMIN |
| /api/notifications/** | Any authenticated role |
| /api/document-types/** | Any authenticated role |
| /api/auth/me | Any authenticated role |

Only health, registration, and login are public.

### 5.2 Record relationship

Services enforce:

- student request owner;
- student attachment owner through request;
- student issued-document owner through request;
- notification recipient;
- staff access to processing records;
- attachment belongs to request in the URL;
- issued document belongs to request in the URL.

Student repository methods should include the owner in the query:

~~~text
findByIdAndStudentUserId(requestId, currentUserId)
~~~

This is safer than loading by ID and forgetting a later comparison.

### 5.3 Workflow state

Request mutations verify:

- current status;
- actor role;
- delivery method;
- required action input;
- entity version;
- related resource presence or absence.

Example: a STAFF token is insufficient to upload a PDF. The request must also be ELECTRONIC, PROCESSING, not already have an issued document, and match expectedVersion.

### 5.4 Data minimization

Role-specific responses:

- student detail contains own data;
- staff detail contains student information needed to process;
- admin monitoring contains summary/profile information but does not automatically grant file download;
- public catalogue never returns internal audit IDs;
- no response contains stored filename or relative path.

## 6. Capability matrix

| Resource/action | Student | Staff | Admin |
| --- | --- | --- | --- |
| Own profile | Read/write | Read when processing | Read for monitoring |
| Other student profile | No | Read through request detail | Read through monitoring |
| Active catalogue | Read | Read | Read |
| All catalogue entries | No | No | Read/write |
| Own requests | Create/read/respond | N/A | N/A |
| All requests | No | Read/process | Read-only |
| Supporting files | Own request | Read | No default access |
| Issued PDF | Own request | Upload/read | No default access |
| Notifications | Own | Own | Own |
| Account management | No | No | Yes |
| Dashboard/report | No | No | Yes |

## 7. Spring Security configuration

Recommended configuration:

- stateless SessionCreationPolicy;
- CSRF disabled;
- CORS enabled with explicit origins;
- OAuth2 resource server JWT support;
- custom JWT authority mapping from role;
- active-user filter after Bearer token authentication;
- JSON authentication/authorization failure handlers;
- no form login;
- no HTTP Basic for application endpoints.

### 7.1 CSRF rationale

CSRF is disabled because:

- authentication is sent explicitly as a Bearer token in Authorization;
- browser cookies are not used for authentication;
- cross-site forms cannot automatically add the Authorization header.

If authentication later moves to cookies, this decision must be revisited.

### 7.2 CORS

Default allowed origin:

~~~text
http://localhost:5173
~~~

Configuration may accept a comma-separated allow-list.

Allowed:

- methods: GET, POST, PUT, PATCH, OPTIONS;
- headers: Authorization, Content-Type, Accept, X-Request-ID;
- exposed headers: Content-Disposition, X-Request-ID.

Not allowed:

- wildcard origin with authenticated calls;
- unnecessary headers;
- credentials mode, because authentication is not cookie based.

## 8. Input validation

### 8.1 DTO validation

Request DTOs use Jakarta Bean Validation:

- @NotBlank;
- @Email;
- @Size;
- @Pattern;
- @NotNull;
- @Min and @Max;
- custom password-match validation where useful.

Service methods validate business conditions that annotations cannot express:

- email uniqueness;
- profile completeness;
- catalogue active state;
- delivery availability;
- status transition;
- file count;
- request ownership;
- date relative to current date.

### 8.2 Query validation

- page >= 0;
- size between 1 and 100;
- sort field allow-listed;
- direction asc/desc only;
- enum parsing failures mapped to INVALID_PARAMETER;
- date-from cannot be after date-to;
- q is length-limited and used through bound parameters.

JPA parameter binding prevents SQL injection. Dynamic sort properties are allow-listed instead of passed directly.

### 8.3 Text output

React escapes rendered strings by default. UniDoc:

- stores plain text;
- does not use dangerouslySetInnerHTML for user content;
- does not convert messages to HTML;
- does not accept HTML email templates in this MVP.

## 9. File-upload security

### 9.1 Threats

- oversized file denial of service;
- executable file disguised as PDF/image;
- path traversal through filename;
- overwriting another file;
- public access to stored bytes;
- content sniffing in browser;
- header injection through download filename;
- attachment/request ID mismatch;
- orphaned files after partial failure.

### 9.2 Allowed student files

- application/pdf with PDF signature;
- image/jpeg with JPEG signature;
- image/png with PNG signature;
- maximum 5 MiB each;
- maximum three per submission action.

### 9.3 Allowed issued file

- application/pdf;
- PDF signature required;
- maximum 10 MiB;
- one per electronic request.

### 9.4 Validation sequence

1. reject missing/empty file;
2. enforce request-level file count;
3. enforce configured size;
4. normalize original display filename;
5. inspect extension;
6. inspect declared content type;
7. inspect magic bytes/signature;
8. require supported combination;
9. generate random UUID storage name;
10. resolve target below configured root;
11. stage and move the file;
12. persist metadata.

The validation is intentionally lightweight and does not claim malware detection.

### 9.5 Path safety

- storage root is configured server-side;
- stored filename is UUID plus server-selected extension;
- relative path is constructed by server;
- normalized final path must start with normalized storage root;
- client never supplies a directory;
- original filename is never used as storage filename;
- symbolic-link behavior is not relied on;
- upload root is outside frontend/public and backend/static.

### 9.6 Download safety

Before reading:

- authenticate;
- authorize role;
- confirm ownership or staff permission;
- confirm file metadata belongs to request;
- normalize path;
- confirm path remains under root;
- confirm regular file exists.

Response:

- Content-Disposition built safely;
- X-Content-Type-Options: nosniff;
- Cache-Control: private, no-store;
- exact validated content type;
- no physical path in errors.

## 10. Database security

- Use a dedicated MySQL account for UniDoc.
- Grant only required permissions on the unidoc schema.
- Do not run the application as MySQL root.
- Database password comes from environment configuration.
- Use prepared statements through JPA.
- Use InnoDB transactions and foreign keys.
- Use uniqueness constraints as a second line of defense.
- Use @Version to prevent lost staff updates.
- Do not expose database error text to clients.

Suggested local grants:

~~~sql
CREATE USER 'unidoc_app'@'localhost' IDENTIFIED BY 'strong-local-password';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES
ON unidoc.* TO 'unidoc_app'@'localhost';
~~~

CREATE and ALTER are needed only if Hibernate manages the local schema. A later fixed schema can reduce privileges, but that is outside the deadline-critical path.

## 11. Email security

- Gmail App Password stays in .env.
- A normal Google account password is never used.
- STARTTLS is enabled.
- SMTP authentication is enabled.
- Connection/read/write timeouts are finite.
- Email body contains limited request status information.
- Supporting or issued documents are not attached to email.
- Email links point to the frontend authenticated page.
- No JWT or one-time document link is included.
- Recipient address comes from the stored account, not action input.
- Exceptions are logged without the SMTP password.

## 12. Secrets and configuration

Required secrets:

- UNIDOC_DB_PASSWORD;
- UNIDOC_JWT_SECRET;
- UNIDOC_SMTP_APP_PASSWORD.

Controls:

- .env is ignored by Git;
- .env.example contains placeholders only;
- secrets are not placed in README screenshots;
- tests use test values, not developer secrets;
- startup validates presence and format;
- frontend VITE variables contain only non-secret API base URL;
- no backend secret is prefixed with VITE_.

## 13. Error-information security

Client responses do not include:

- stack trace;
- exception class;
- SQL;
- table/column error details;
- physical file path;
- JWT contents;
- SMTP details;
- password-policy internal hash details.

Ownership failures return 404 for student-owned resources to avoid confirming another student's record.

Authorization route failures return 403 ACCESS_DENIED.

## 14. Logging security

Never log:

- passwords or confirmation;
- password hashes;
- full JWTs or Authorization header;
- Gmail App Password;
- database password;
- file content;
- multipart body;
- complete student request payload;
- physical storage path at INFO;
- raw SQL parameters containing personal information.

Permitted structured context:

- requestId;
- endpoint;
- authenticated user ID;
- role;
- request record ID;
- transition name;
- status;
- result;
- file size/content type, without bytes;
- exception category.

Email warnings should mask address where practical, for example s***@example.com.

## 15. Account administration safeguards

- Only ADMIN creates STAFF or ADMIN.
- Public registration cannot specify role.
- Admin cannot deactivate the currently authenticated own account.
- Status and password changes increment authVersion.
- Password reset returns no password.
- No account hard deletion.
- No force-change workflow, as explicitly excluded.
- Demo credentials are marked local-demo-only.

## 16. Frontend security

- Route guards prevent accidental wrong-role navigation.
- The frontend handles 401 by clearing session and returning to login.
- It handles 403 as insufficient permission unless the error is ACCOUNT_INACTIVE.
- It never assumes hidden buttons make an operation safe.
- It does not embed user text as HTML.
- External links, if any, use safe rel attributes.
- Dependency count is kept small.
- Production source maps may remain local; no public deployment is in scope.
- File previews are optional; download is safer and sufficient.
- Confirmation is required for rejection, account deactivation, password reset, and terminal collection action.

## 17. Threat model

| Threat | Example | Control | Residual risk |
| --- | --- | --- | --- |
| Credential guessing | Repeated login attempts | BCrypt, generic failure, strong passwords | No rate limiter in local MVP |
| Privilege escalation | Student submits ADMIN role | Server always assigns STUDENT | Admin credential compromise |
| Broken object authorization | Student requests another ID | Owner-scoped repository/service query | Implementation regression; covered by tests |
| Invalid workflow | Directly call complete | State-machine validation | Bugs; covered by transition tests |
| Lost update | Two staff act at once | @Version and 409 conflict | User must reload |
| SQL injection | Crafted q filter | JPA bound parameters and sort allow-list | Native-query errors if introduced |
| Stored XSS | Script in purpose | React text escaping; no raw HTML | Future unsafe rendering |
| Path traversal | Filename ../../secret | UUID storage names; root normalization | OS-level compromise |
| File disguise | EXE named PDF | extension, MIME, signature, size checks | No malware scanner |
| Public file exposure | Guess upload URL | No static mapping; authorized controller | Local OS user access |
| Secret leakage | Commit .env | Git ignore, example placeholders, review | Human error |
| SMTP failure | Network/Gmail failure | After-commit, warning, in-app record | Email may be missed |
| CSV formula injection | Purpose begins = | Prefix dangerous cells | Spreadsheet-specific behavior |
| Sensitive logging | Token/payload in logs | Logging policy and interceptor care | Developer-added logs |
| CSRF | Cross-site form | Bearer header, no auth cookie | Changes if cookie auth adopted |
| XSS token theft | Malicious script | Escaping, limited dependencies, no raw HTML | sessionStorage remains JS accessible |

## 18. Security limitations accepted for local MVP

- No application rate limiting.
- No CAPTCHA.
- No multi-factor authentication.
- No refresh tokens.
- No server-side token blacklist.
- No HTTPS termination in local Vite/Spring development.
- No malware scanner.
- No data-at-rest encryption beyond operating-system controls.
- No backup encryption workflow.
- No institutional SSO.
- No formal privacy retention policy.
- No penetration test.

These limitations are acceptable only because delivery is a local course demonstration. They must be reconsidered before public deployment.

## 19. Security test requirements

Authentication:

- student role cannot be chosen during registration;
- invalid password rejected;
- inactive login rejected;
- invalid signature rejected;
- expired token rejected;
- stale authVersion rejected;
- token role mismatch rejected.

Authorization:

- student cannot open another student's request;
- student cannot download another student's attachment/document;
- staff cannot access admin endpoints;
- admin cannot call staff workflow endpoints;
- unauthenticated file request rejected;
- notification access restricted to recipient.

Workflow:

- every invalid transition rejected;
- wrong delivery action rejected;
- stale expectedVersion returns conflict;
- second issued-document upload rejected.

Files:

- over-size file rejected;
- unsupported extension rejected;
- extension/MIME/signature mismatch rejected;
- traversal filename stored safely;
- attachment/request mismatch rejected;
- missing physical file returns safe error.

Configuration:

- short/invalid JWT secret fails startup;
- secrets absent from repository search;
- error response has no stack trace/path;
- CORS allows configured origin and rejects an unrelated origin.

## 20. Security completion checklist

- [ ] Only three public endpoints.
- [ ] BCrypt cost 12.
- [ ] JWT secret validation.
- [ ] One-hour default expiry.
- [ ] ACTIVE, authVersion, and role rechecked.
- [ ] Route role rules complete.
- [ ] Student owner queries used.
- [ ] Staff/admin separation enforced.
- [ ] @Version conflict handled.
- [ ] File type, signature, size, count checked.
- [ ] Upload directory is not public.
- [ ] Safe Content-Disposition used.
- [ ] CORS allow-list configured.
- [ ] DTOs hide internal fields.
- [ ] Errors hide stack traces and physical paths.
- [ ] Logs hide secrets and content.
- [ ] SMTP runs after commit and tolerates failure.
- [ ] .env ignored and .env.example safe.
- [ ] Cross-user and cross-role automated tests pass.
