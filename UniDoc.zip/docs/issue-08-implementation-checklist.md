# Issue 8 — Document Catalogue: Implementation and Verification Checklist

**Approved scope:** `docs/12-implementation-plan.md` sections 8.1–8.10, read alongside the 11 architecture, requirements, data, API, security, storage, error, deployment, testing, and ADR documents.

## Implemented

- [x] Shared active-catalogue read models return code, name, description, requirements, required-support flag, ordered `availableDeliveryMethods`, and only relevant physical collection information; no actor/audit IDs.
- [x] Admin read models expose every editable catalogue field plus creation/update timestamps; no entities or actor IDs are serialized.
- [x] Validated complete PUT/POST payload for 2–50 ASCII code, 2–150 name, 10–2000 description, 3–4000 requirements, optional collection text limits, required Boolean flags, at least one delivery method, and mandatory location for physical. Input code is uppercased; text whitespace is normalized. Validation measures the normalized value.
- [x] Authenticated active catalogue `GET /api/document-types` and `GET /api/document-types/{id}`; inactive and missing types both return 404 `DOCUMENT_TYPE_NOT_FOUND` through the shared error contract.
- [x] ADMIN-only paginated and database-filtered `GET /api/admin/document-types` with code/name `q` search, optional active status, allowed `name/code/createdAt/active` sorts, direction, page and size. Query escaping and limits are shared with Issue 3.
- [x] ADMIN-only `POST /api/admin/document-types` (201), `GET /api/admin/document-types/{id}` (200), `PUT /api/admin/document-types/{id}` (200), `PATCH /api/admin/document-types/{id}/status` (200).
- [x] Duplicate code/name checks before saving and existing named database-constraint handling for concurrent insertion. Names are compared case-insensitively; codes are normalized uppercase. Same-row values are accepted during update.
- [x] Creator and updater are the authenticated ADMIN, not client-provided values; creation metadata is immutable. Idempotent status updates do not rewrite the update actor/timestamp.
- [x] No catalogue DELETE endpoint, no seed data, no mutation of existing requests, no new table or dependency, and no extra privileges for STAFF/STUDENT.
- [x] Typed frontend catalogue API module, shared active `/catalogue` page with loading/empty/error/retry states and responsive descriptions/requirements/collection guidance, and a STUDENT-only selection link to `/requests/new?documentTypeId=...` (form itself remains Issue 12).
- [x] ADMIN `/admin/document-types` management: filters, server pagination, desktop table/mobile cards, create/edit dialog, conditional collection fields, in-form field validation, explicit activate/deactivate confirmation, network-uncertainty recheck, and server-fresh edit loading.
- [x] Added 16 dedicated HTTP/service JUnit regression methods spanning visibility, all roles, CRUD, pagination/sort/search, optional methods, invalid input, uniqueness, status idempotence, no delete, actor auditing, and persisted-request snapshot stability.

## Verification executed in the implementation environment

- Java 21 `javac` compilation of **all backend main source files** using the uploaded application's production Spring Boot dependency JARs: **PASS**.
- Strict frontend `tsc -b` compilation with the uploaded dependency versions: **PASS**.
- Offline Jakarta Bean Validation and domain smoke: valid/invalid method/location combinations, bad code, missing flags, catalogue status idempotence and existing request snapshot isolation: **PASS**.
- Offline frontend form-validation smoke: **15 assertions PASS**, covering uppercase/trim normalization, optional collection instructions, exclusive delivery methods, both-disabled rejection, location requirement, invalid code/text bounds and optional text bounds.
- Full backend Maven JUnit suite (`clean test` and `clean package`): **NOT RUN here**. No compatible Maven distribution/test dependency cache is available and the Maven Wrapper cannot fetch its distribution. The 16 new test methods are included for execution on the target Windows machine.
- Frontend `npm run lint` and production Vite bundling: **NOT RUN here**. Uploaded `node_modules` contains Windows-only native Oxlint/Rolldown bindings; Linux bindings are unavailable in this offline environment. TypeScript compilation passes.
- Real MySQL constraint checks, role/browser flows and physical responsiveness at 360/768/1366 px: **REQUIRE WINDOWS MANUAL VERIFICATION**.

## Windows commands (repository root)

Load `.env` and start MySQL as described in `README.md`. Then run:

```powershell
.\backend\mvnw.cmd -f backend\pom.xml clean test
.\backend\mvnw.cmd -f backend\pom.xml clean package
npm --prefix frontend ci
npm --prefix frontend run lint
npm --prefix frontend run build
```

For a focused regression run from `backend/`:

```powershell
.\mvnw.cmd -f pom.xml -Dtest=DocumentCatalogueServiceTests,DocumentCatalogueHttpTests test
```

Start backend and frontend in separate terminals using the README commands; use the Issue 8 acceptance test in `README.md`.

## Issue boundary and future regression

Initial five deterministic document types belong to **Issue 19**, not this feature. Until manually added, an empty active catalogue is expected. The student new-request submission endpoint belongs to Issue 11, and its complete form belongs to Issue 12. The `/catalogue` STUDENT link carries the selected type ID without assuming a request can already be submitted. The eventual Issue 11 service must select only an active type and snapshot name, location and instructions at submission; the new persistence regression test demonstrates that later catalogue edits do not rewrite already saved snapshot fields.

The eleven approved source documents and the supplied implementation plan were not modified.
