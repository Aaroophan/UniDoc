# Issue 3 Implementation Checklist

## Scope completed

- Added one generic `PageResponse<T>` contract with zero-based pages, default size 20, maximum size 100, and a single Spring `Page<T>` mapper.
- Added the stable `ApiErrorCode` catalogue and one `ApiErrorResponse` shape containing UTC timestamp, HTTP status, safe code/message, request path, request ID, and ordered optional field errors.
- Added focused feature exceptions for authentication, account, profile, catalogue, request workflow, version conflict, file validation/storage, attachments, and issued-document states.
- Added `FileValidationException` with only the documented file-validation codes.
- Added one `@RestControllerAdvice` for validation, malformed requests, query errors, known/unknown unique constraints, optimistic locking, file failures, recognized database availability failures, and safe generic 500 responses.
- Added JSON security writers so pre-controller authentication and access-denied failures use the same API error contract.
- Made the baseline Spring Security configuration stateless, preventing `JSESSIONID` creation for API authorization failures.
- Added request correlation through `X-Request-ID`, request attributes, and SLF4J MDC with strict client-ID validation and cleanup in `finally`.
- Added reusable query validation for page, size, direction, allow-listed sort mapping, date ranges, free-text limits, and enum filters.
- Added feature sort mappings while retaining the Issue 2 allow-list constants.
- Added shared data-minimizing DTOs and explicit mappers for user summaries, request summaries, actor summaries, attachment metadata, and history entries.
- Added a local console log pattern containing UTC timestamp, level, thread, request ID, logger, and message.
- Kept Spring fallback error details disabled through the existing `server.error.*=never/false` settings.
- Added focused Issue 3 tests for pagination, query validation, DTO data minimization, field-error ordering, malformed JSON, invalid enums, integrity conflicts, optimistic locking, storage errors, generic 500 redaction, security errors, stateless behavior, and request IDs.

## Automated verification to run on the target machine

From the repository root:

```powershell
.\backend\mvnw.cmd clean test
.\backend\mvnw.cmd clean package
npm --prefix frontend run lint
npm --prefix frontend run build
```

Expected backend test total after Issue 3: **39 tests**.

The build must report zero failures and zero errors. Production Java compilation should also remain warning-free under strict linting.

## HTTP behavior checks

Start the backend with the normal local `.env` loaded, then run:

```powershell
Invoke-RestMethod http://localhost:8080/api/health | ConvertTo-Json -Compress
```

Expected:

```json
{"status":"ok"}
```

Confirm a request ID is returned:

```powershell
curl.exe -i http://localhost:8080/api/health
```

Expected response headers include:

```text
X-Request-ID: <generated-id>
```

Confirm a safe client request ID is echoed:

```powershell
curl.exe -i -H "X-Request-ID: manual-check-1234" http://localhost:8080/api/health
```

Expected:

```text
X-Request-ID: manual-check-1234
```

Confirm an invalid client value is replaced rather than echoed:

```powershell
curl.exe -i -H "X-Request-ID: bad id with spaces" http://localhost:8080/api/health
```

The response must contain a newly generated request ID.

## Baseline security behavior

Because Issue 3 establishes the final shared authentication-error language, an anonymous request to an unavailable/protected API route now returns the standard authentication response rather than the earlier baseline-only `403` behavior:

```powershell
curl.exe -i http://localhost:8080/api/not-configured
```

Expected status:

```text
HTTP/1.1 401
```

Expected JSON fields include:

```json
{
  "status": 401,
  "code": "AUTHENTICATION_REQUIRED",
  "message": "Authentication is required to access this resource.",
  "requestId": "..."
}
```

The response must not create a `JSESSIONID` cookie.

## Error-safety verification

The automated Issue 3 HTTP tests verify that responses never expose:

- Java stack traces;
- exception class names;
- raw SQL or unknown database-constraint text;
- absolute storage paths;
- marker secrets placed inside unexpected exceptions.

Known unique constraints must map to the documented stable codes:

- `uq_users_email` -> `EMAIL_ALREADY_EXISTS`
- `uq_student_profiles_registration` -> `REGISTRATION_NUMBER_ALREADY_EXISTS`
- `uq_document_types_code` -> `DOCUMENT_TYPE_CODE_EXISTS`
- `uq_document_types_name` -> `DOCUMENT_TYPE_NAME_EXISTS`
- `uq_issued_documents_request` -> `ISSUED_DOCUMENT_ALREADY_EXISTS`

Unknown integrity failures must return a generic `CONFLICT` response without returning the database message.

## Logging verification

During local startup and requests, console lines should contain a request-ID field similar to:

```text
[requestId=manual-check-1234]
```

For an expected client error, the server may log a concise status/code/path event. Unexpected failures may log server-side stack frames, but normal INFO/WARN messages must never include passwords, hashes, JWTs, Authorization headers, database/SMTP secrets, multipart bodies, file bytes, full request messages, or absolute paths.

## Regression checks

Issue 3 must not change the Issue 2 schema. Confirm the eight application tables remain:

```text
users
student_profiles
document_types
document_requests
request_attachments
issued_documents
request_status_history
notifications
```

No new application table is required for Issue 3.

## Completion gate

Issue 3 is complete when:

- all backend tests pass;
- the backend package succeeds;
- frontend lint/build still pass unchanged;
- `/api/health` remains public and returns only `status: ok`;
- `X-Request-ID` is generated/echoed safely;
- anonymous protected access returns the shared 401 JSON shape;
- no `JSESSIONID` is created;
- validation and unexpected errors use `ApiErrorResponse`;
- sensitive marker text is absent from error responses;
- the MySQL schema still contains only the eight approved application tables.
