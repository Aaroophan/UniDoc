# UniDoc Data Model

**Database:** MySQL 26.7.0  
**Persistence:** Spring Data JPA / Hibernate  
**Schema name:** unidoc  
**Character set:** utf8mb4  
**Time convention:** UTC for timestamps; LocalDate for business dates

## 1. Data-model goals

The model must:

- preserve the complete document-request lifecycle;
- enforce important uniqueness and relationship rules;
- support role and ownership checks;
- support electronic and physical delivery;
- keep uploaded bytes outside MySQL;
- provide efficient paginated lists and reports;
- preserve historical meaning when catalogue data changes;
- handle competing staff changes safely; and
- remain small enough to implement within the project deadline.

The model intentionally avoids generic workflow engines, polymorphic entity frameworks, audit platforms, and file version tables.

## 2. Entity relationship diagram

~~~mermaid
erDiagram
    USERS ||--o| STUDENT_PROFILES : has
    USERS ||--o{ DOCUMENT_TYPES : creates_or_updates
    USERS ||--o{ DOCUMENT_REQUESTS : submits
    DOCUMENT_TYPES ||--o{ DOCUMENT_REQUESTS : classifies
    DOCUMENT_REQUESTS ||--o{ REQUEST_ATTACHMENTS : contains
    DOCUMENT_REQUESTS ||--o| ISSUED_DOCUMENTS : receives
    DOCUMENT_REQUESTS ||--o{ REQUEST_STATUS_HISTORY : records
    USERS ||--o{ REQUEST_ATTACHMENTS : uploads
    USERS ||--o{ ISSUED_DOCUMENTS : uploads
    USERS ||--o{ REQUEST_STATUS_HISTORY : acts
    USERS ||--o{ NOTIFICATIONS : receives

    USERS {
        bigint id PK
        varchar email UK
        varchar password_hash
        varchar full_name
        varchar role
        varchar status
        int auth_version
        datetime created_at
        datetime updated_at
    }

    STUDENT_PROFILES {
        bigint id PK
        bigint user_id FK,UK
        varchar registration_number UK
        varchar phone
        varchar faculty
        varchar department
        varchar degree_programme
        tinyint academic_year
        datetime created_at
        datetime updated_at
    }

    DOCUMENT_TYPES {
        bigint id PK
        varchar code UK
        varchar name UK
        text description
        text requirements
        boolean supporting_documents_required
        boolean electronic_available
        boolean physical_available
        varchar collection_location
        text collection_instructions
        boolean active
        bigint created_by_user_id FK
        bigint updated_by_user_id FK
        datetime created_at
        datetime updated_at
    }

    DOCUMENT_REQUESTS {
        bigint id PK
        varchar request_number UK
        bigint student_user_id FK
        bigint document_type_id FK
        varchar document_type_name_snapshot
        varchar delivery_method
        varchar status
        text purpose
        date required_date
        text additional_information_message
        text rejection_reason
        varchar collection_location_snapshot
        text collection_instructions_snapshot
        datetime ready_at
        datetime completed_at
        date collection_date
        text collection_note
        bigint version
        datetime created_at
        datetime updated_at
    }

    REQUEST_ATTACHMENTS {
        bigint id PK
        bigint request_id FK
        bigint uploaded_by_user_id FK
        varchar attachment_kind
        varchar original_filename
        varchar stored_filename UK
        varchar relative_path UK
        varchar content_type
        bigint size_bytes
        datetime created_at
    }

    ISSUED_DOCUMENTS {
        bigint id PK
        bigint request_id FK,UK
        bigint uploaded_by_user_id FK
        varchar original_filename
        varchar stored_filename UK
        varchar relative_path UK
        varchar content_type
        bigint size_bytes
        int download_count
        datetime first_downloaded_at
        datetime last_downloaded_at
        datetime created_at
    }

    REQUEST_STATUS_HISTORY {
        bigint id PK
        bigint request_id FK
        varchar previous_status
        varchar new_status
        bigint changed_by_user_id FK
        text note
        datetime created_at
    }

    NOTIFICATIONS {
        bigint id PK
        bigint recipient_user_id FK
        varchar type
        varchar title
        text message
        varchar action_path
        boolean is_read
        datetime read_at
        datetime created_at
    }
~~~

## 3. Common mapping conventions

### 3.1 Identifiers

- Internal primary keys use BIGINT AUTO_INCREMENT.
- IDs are exposed in authenticated APIs as numbers.
- Security never depends on an ID being difficult to guess.
- Every record access still checks role and ownership.
- A request also has a human-readable request number such as UDR-000123.

### 3.2 Enumerations

Application enums are stored as VARCHAR rather than ordinal numbers.

Reason:

- database rows remain readable;
- adding enum members does not renumber stored values;
- reports can use clear status values.

Unknown values must fail fast rather than silently map to a default.

### 3.3 Timestamps

- created_at and updated_at use DATETIME(6).
- The application writes UTC.
- API responses use ISO 8601 UTC timestamps.
- Business dates such as required_date and collection_date use DATE because they have no time-of-day meaning.

### 3.4 Text

- Database and connection use utf8mb4.
- User-entered text is stored as plain text.
- The frontend renders text, never untrusted HTML.
- Leading/trailing whitespace is normalized before persistence.

### 3.5 Deletion

Normal UI flows use no hard deletion for users, document types, requests, history, files, or notifications.

- Users and document types are deactivated.
- Requests become terminal.
- Files are immutable.
- The guarded local reset is the only operation allowed to clear application tables.

### 3.6 Auditing

Spring Data auditing supplies created and updated timestamps. Domain-specific actors are recorded explicitly where the actor matters:

- document type created/updated by;
- request status changed by;
- file uploaded by.

## 4. Table specifications

## 4.1 users

Purpose: authentication identity and common account information for all roles.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | Internal user ID |
| email | VARCHAR(254) | No | Unique | Normalized login email |
| password_hash | VARCHAR(100) | No |  | BCrypt hash |
| full_name | VARCHAR(150) | No |  | Display and reporting name |
| role | VARCHAR(20) | No | STUDENT/STAFF/ADMIN | Authorization role |
| status | VARCHAR(20) | No | ACTIVE | Account availability |
| auth_version | INT | No | 0 | JWT revocation generation |
| created_at | DATETIME(6) | No |  | UTC creation time |
| updated_at | DATETIME(6) | No |  | UTC modification time |

Allowed role values:

- STUDENT
- STAFF
- ADMIN

Allowed status values:

- ACTIVE
- INACTIVE

Rules:

- email is lowercased with Locale.ROOT before query/save;
- password_hash is write-only at API boundaries;
- public registration always sets STUDENT;
- deactivation and password reset increment auth_version;
- accounts are not hard-deleted;
- full_name is required for every role.

Indexes:

- UNIQUE uq_users_email(email)
- INDEX ix_users_role_status(role, status)
- INDEX ix_users_created_at(created_at)

JPA notes:

- role and status use EnumType.STRING;
- password_hash has no public getter in response mapping;
- authVersion appears as a private token claim but not as editable API input.

## 4.2 student_profiles

Purpose: student-only academic and contact details.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | Profile ID |
| user_id | BIGINT | No | FK users, unique | Owning student |
| registration_number | VARCHAR(50) | No | Unique | University/index number |
| phone | VARCHAR(30) | Yes |  | Contact number |
| faculty | VARCHAR(100) | No |  | Faculty name |
| department | VARCHAR(100) | No |  | Department name |
| degree_programme | VARCHAR(150) | No |  | Degree/program name |
| academic_year | TINYINT UNSIGNED | No | 1 to 8 | Current academic year |
| created_at | DATETIME(6) | No |  | UTC creation time |
| updated_at | DATETIME(6) | No |  | UTC update time |

Rules:

- one profile per student user;
- user role must be STUDENT, enforced by service;
- registration number is trimmed and normalized to uppercase for uniqueness;
- changing email is not part of profile update;
- deleting a user is not a normal flow.

Indexes:

- UNIQUE uq_student_profiles_user(user_id)
- UNIQUE uq_student_profiles_registration(registration_number)
- INDEX ix_student_profiles_department(department)

## 4.3 document_types

Purpose: administrator-managed catalogue.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | Catalogue ID |
| code | VARCHAR(50) | No | Unique | Stable readable code |
| name | VARCHAR(150) | No | Unique | Display name |
| description | TEXT | No |  | Student-facing description |
| requirements | TEXT | No |  | Instructions and required evidence |
| supporting_documents_required | BOOLEAN | No | False | Whether initial attachment is required |
| electronic_available | BOOLEAN | No | True | Electronic method allowed |
| physical_available | BOOLEAN | No | True | Physical method allowed |
| collection_location | VARCHAR(255) | Yes |  | Required when physical is allowed |
| collection_instructions | TEXT | Yes |  | Physical collection guidance |
| active | BOOLEAN | No | True | Selectable for new requests |
| created_by_user_id | BIGINT | No | FK users | Creating administrator |
| updated_by_user_id | BIGINT | No | FK users | Last updating administrator |
| created_at | DATETIME(6) | No |  | UTC creation time |
| updated_at | DATETIME(6) | No |  | UTC update time |

Rules:

- code normalized to uppercase;
- at least one delivery method true;
- physical delivery requires collection_location;
- deactivation prevents new submissions;
- historical requests retain snapshot values;
- hard deletion is unavailable.

Indexes:

- UNIQUE uq_document_types_code(code)
- UNIQUE uq_document_types_name(name)
- INDEX ix_document_types_active_name(active, name)

## 4.4 document_requests

Purpose: central workflow aggregate.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | Internal request ID |
| request_number | VARCHAR(30) | Yes during initial insert | Unique; set before commit returns | Human-readable number |
| student_user_id | BIGINT | No | FK users | Owning student |
| document_type_id | BIGINT | No | FK document_types | Catalogue source |
| document_type_name_snapshot | VARCHAR(150) | No |  | Historical display name |
| delivery_method | VARCHAR(20) | No |  | ELECTRONIC or PHYSICAL |
| status | VARCHAR(50) | No | SUBMITTED | Current workflow state |
| purpose | TEXT | No |  | Student purpose |
| required_date | DATE | No |  | Requested date |
| additional_information_message | TEXT | Yes |  | Current staff question |
| rejection_reason | TEXT | Yes |  | Required in REJECTED |
| collection_location_snapshot | VARCHAR(255) | Yes |  | Physical location at submission |
| collection_instructions_snapshot | TEXT | Yes |  | Physical instructions at submission |
| ready_at | DATETIME(6) | Yes |  | Time READY was entered |
| completed_at | DATETIME(6) | Yes |  | Time COMPLETED was entered |
| collection_date | DATE | Yes |  | Actual physical collection date |
| collection_note | TEXT | Yes |  | Optional staff note |
| version | BIGINT | No | 0 | Optimistic-lock version |
| created_at | DATETIME(6) | No |  | Submission time |
| updated_at | DATETIME(6) | No |  | Last workflow update |

Allowed delivery methods:

- ELECTRONIC
- PHYSICAL

Allowed statuses:

- SUBMITTED
- UNDER_REVIEW
- ADDITIONAL_INFORMATION_REQUIRED
- APPROVED
- REJECTED
- PROCESSING
- READY
- COMPLETED

Rules:

- student_user_id must refer to a STUDENT;
- required date cannot be before submission date;
- delivery method must be enabled by the document type at submission;
- status changes only through DocumentRequestService;
- @Version maps to version;
- additional_information_message is set when requesting information and cleared after the student responds;
- rejection_reason exists only for REJECTED;
- ready_at is set when entering READY;
- completed_at is set when entering COMPLETED;
- collection fields are allowed only for PHYSICAL requests;
- request fields are immutable after creation except workflow/delivery fields;
- request_number is assigned after the first insert using the numeric ID, then saved as UDR- plus a zero-padded number.

Request-number example:

~~~text
Database ID: 123
Request number: UDR-000123
~~~

This avoids a separate sequence service. The numeric ID remains the database identity.

Indexes:

- UNIQUE uq_document_requests_number(request_number)
- INDEX ix_requests_student_created(student_user_id, created_at DESC)
- INDEX ix_requests_status_created(status, created_at DESC)
- INDEX ix_requests_type_created(document_type_id, created_at DESC)
- INDEX ix_requests_delivery_status(delivery_method, status)
- INDEX ix_requests_required_date(required_date)
- INDEX ix_requests_created_at(created_at)

Report queries should use repository specifications or explicit JPQL, not load-and-filter in memory.

## 4.5 request_attachments

Purpose: metadata for student-uploaded files.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | Attachment ID |
| request_id | BIGINT | No | FK document_requests | Parent request |
| uploaded_by_user_id | BIGINT | No | FK users | Student uploader |
| attachment_kind | VARCHAR(40) | No |  | INITIAL_SUPPORT or ADDITIONAL_INFORMATION |
| original_filename | VARCHAR(255) | No |  | Safe display/download name |
| stored_filename | VARCHAR(100) | No | Unique | Generated physical name |
| relative_path | VARCHAR(500) | No | Unique | Path below storage root |
| content_type | VARCHAR(100) | No |  | Validated MIME type |
| size_bytes | BIGINT | No |  | Validated size |
| created_at | DATETIME(6) | No |  | Upload time |

Allowed attachment kinds:

- INITIAL_SUPPORT
- ADDITIONAL_INFORMATION

Rules:

- uploaded_by must be the owning student;
- file count is enforced per submission action;
- file metadata is immutable;
- original_filename is sanitized for response headers;
- relative_path never begins with a drive letter or slash;
- no endpoint accepts relative_path as input;
- physical deletion is not a normal application action.

Indexes:

- UNIQUE uq_attachments_stored_filename(stored_filename)
- UNIQUE uq_attachments_relative_path(relative_path)
- INDEX ix_attachments_request_created(request_id, created_at)
- INDEX ix_attachments_request_kind(request_id, attachment_kind)

## 4.6 issued_documents

Purpose: one-to-one final electronic document metadata.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | Issued document ID |
| request_id | BIGINT | No | FK document_requests, unique | Electronic request |
| uploaded_by_user_id | BIGINT | No | FK users | Staff uploader |
| original_filename | VARCHAR(255) | No |  | Download display name |
| stored_filename | VARCHAR(100) | No | Unique | Generated physical name |
| relative_path | VARCHAR(500) | No | Unique | Path below storage root |
| content_type | VARCHAR(100) | No | application/pdf | MIME type |
| size_bytes | BIGINT | No |  | Size, max 10 MiB |
| download_count | INT UNSIGNED | No | 0 | Authorized student downloads |
| first_downloaded_at | DATETIME(6) | Yes |  | First successful response |
| last_downloaded_at | DATETIME(6) | Yes |  | Most recent response |
| created_at | DATETIME(6) | No |  | Staff upload time |

Rules:

- one issued document per request;
- parent request must be ELECTRONIC and PROCESSING at upload;
- content type must be PDF;
- no replacement/versioning;
- first authorized student download completes the request;
- staff verification download does not complete the request and does not increment student download count;
- relative path is internal only.

Indexes:

- UNIQUE uq_issued_documents_request(request_id)
- UNIQUE uq_issued_documents_stored_filename(stored_filename)
- UNIQUE uq_issued_documents_relative_path(relative_path)

## 4.7 request_status_history

Purpose: append-only lifecycle and explanation record.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | History ID |
| request_id | BIGINT | No | FK document_requests | Parent request |
| previous_status | VARCHAR(50) | Yes |  | Null for initial submission |
| new_status | VARCHAR(50) | No |  | Status entered |
| changed_by_user_id | BIGINT | No | FK users | Student or staff actor |
| note | TEXT | Yes |  | Information message, response, rejection, collection note |
| created_at | DATETIME(6) | No |  | Change time |

Rules:

- created only by workflow service;
- no update or delete API;
- note is copied from the significant action;
- note is plain text;
- the initial record has previous_status null and new_status SUBMITTED;
- information cycles can be reconstructed from ordered history.

Indexes:

- INDEX ix_history_request_created(request_id, created_at, id)
- INDEX ix_history_actor_created(changed_by_user_id, created_at)

Ordering includes id after created_at so events with the same timestamp remain deterministic.

## 4.8 notifications

Purpose: recipient-owned in-app notification record.

| Column | Type | Null | Constraint/default | Meaning |
| --- | --- | :---: | --- | --- |
| id | BIGINT | No | PK, auto increment | Notification ID |
| recipient_user_id | BIGINT | No | FK users | Recipient |
| type | VARCHAR(50) | No |  | Event category |
| title | VARCHAR(150) | No |  | Short heading |
| message | TEXT | No |  | Plain-text message |
| action_path | VARCHAR(255) | Yes |  | Internal frontend path |
| is_read | BOOLEAN | No | False | Read state |
| read_at | DATETIME(6) | Yes |  | First read time |
| created_at | DATETIME(6) | No |  | Creation time |

Suggested types:

- REQUEST_SUBMITTED
- ADDITIONAL_INFORMATION_REQUIRED
- ADDITIONAL_INFORMATION_SUBMITTED
- REQUEST_APPROVED
- REQUEST_REJECTED
- PROCESSING_STARTED
- ELECTRONIC_DOCUMENT_READY
- PHYSICAL_DOCUMENT_READY
- REQUEST_COMPLETED

Rules:

- recipient can read/update only own notification;
- marking an already-read notification is idempotent;
- action_path must be an internal path beginning with slash;
- email delivery status is not stored in this table;
- notification persists if email fails.

Indexes:

- INDEX ix_notifications_recipient_created(recipient_user_id, created_at DESC)
- INDEX ix_notifications_recipient_read_created(recipient_user_id, is_read, created_at DESC)

## 5. Referential actions

| Relationship | Foreign-key action | Reason |
| --- | --- | --- |
| student_profiles.user_id → users.id | ON DELETE CASCADE | A profile cannot exist without its user; normal UI does not delete users |
| document_types creator/updater → users.id | ON DELETE RESTRICT | Preserve admin audit |
| requests.student_user_id → users.id | ON DELETE RESTRICT | Preserve request owner |
| requests.document_type_id → document_types.id | ON DELETE RESTRICT | Preserve classification |
| attachments.request_id → requests.id | ON DELETE CASCADE | Reset can clear request subtree |
| attachments.uploaded_by → users.id | ON DELETE RESTRICT | Preserve actor |
| issued.request_id → requests.id | ON DELETE CASCADE | Reset can clear request subtree |
| issued.uploaded_by → users.id | ON DELETE RESTRICT | Preserve actor |
| history.request_id → requests.id | ON DELETE CASCADE | Reset can clear request subtree |
| history.changed_by → users.id | ON DELETE RESTRICT | Preserve actor |
| notifications.recipient → users.id | ON DELETE CASCADE | Notifications have no meaning without recipient |

Normal features never invoke these deletion cascades. They primarily support a clean guarded demo reset.

## 6. Logical constraints not fully expressed by MySQL

Some rules cross multiple tables or depend on role/current state. They are enforced in services:

- profile user must have STUDENT role;
- request owner must have STUDENT role;
- catalogue creator/updater must have ADMIN role;
- workflow actor must have an allowed role;
- issued uploader must have STAFF role;
- attachment uploader must own the request;
- selected delivery method must have been available at submission;
- exactly one issued document is allowed only for an electronic request;
- status-dependent fields must match the current status;
- student response is accepted only while additional information is required;
- collection is accepted only for physical READY requests.

Service validation remains necessary even if check constraints are added.

## 7. Proposed SQL schema

The application primarily uses JPA mapping. The following DDL is a precise reference for intended types, keys, and indexes. Small syntax adjustments may be required by the exact Hibernate-generated schema.

~~~sql
CREATE DATABASE IF NOT EXISTS unidoc
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

USE unidoc;

CREATE TABLE users (
    id BIGINT NOT NULL AUTO_INCREMENT,
    email VARCHAR(254) NOT NULL,
    password_hash VARCHAR(100) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    role VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    auth_version INT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_users_email UNIQUE (email),
    CONSTRAINT ck_users_role CHECK (role IN ('STUDENT', 'STAFF', 'ADMIN')),
    CONSTRAINT ck_users_status CHECK (status IN ('ACTIVE', 'INACTIVE')),
    INDEX ix_users_role_status (role, status),
    INDEX ix_users_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE student_profiles (
    id BIGINT NOT NULL AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    registration_number VARCHAR(50) NOT NULL,
    phone VARCHAR(30) NULL,
    faculty VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    degree_programme VARCHAR(150) NOT NULL,
    academic_year TINYINT UNSIGNED NOT NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_student_profiles_user UNIQUE (user_id),
    CONSTRAINT uq_student_profiles_registration UNIQUE (registration_number),
    CONSTRAINT fk_student_profiles_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT ck_student_profiles_academic_year
        CHECK (academic_year BETWEEN 1 AND 8),
    INDEX ix_student_profiles_department (department)
) ENGINE=InnoDB;

CREATE TABLE document_types (
    id BIGINT NOT NULL AUTO_INCREMENT,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    requirements TEXT NOT NULL,
    supporting_documents_required BOOLEAN NOT NULL DEFAULT FALSE,
    electronic_available BOOLEAN NOT NULL DEFAULT TRUE,
    physical_available BOOLEAN NOT NULL DEFAULT TRUE,
    collection_location VARCHAR(255) NULL,
    collection_instructions TEXT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_by_user_id BIGINT NOT NULL,
    updated_by_user_id BIGINT NOT NULL,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_document_types_code UNIQUE (code),
    CONSTRAINT uq_document_types_name UNIQUE (name),
    CONSTRAINT fk_document_types_created_by
        FOREIGN KEY (created_by_user_id) REFERENCES users(id),
    CONSTRAINT fk_document_types_updated_by
        FOREIGN KEY (updated_by_user_id) REFERENCES users(id),
    CONSTRAINT ck_document_types_delivery
        CHECK (electronic_available = TRUE OR physical_available = TRUE),
    INDEX ix_document_types_active_name (active, name)
) ENGINE=InnoDB;

CREATE TABLE document_requests (
    id BIGINT NOT NULL AUTO_INCREMENT,
    request_number VARCHAR(30) NULL,
    student_user_id BIGINT NOT NULL,
    document_type_id BIGINT NOT NULL,
    document_type_name_snapshot VARCHAR(150) NOT NULL,
    delivery_method VARCHAR(20) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'SUBMITTED',
    purpose TEXT NOT NULL,
    required_date DATE NOT NULL,
    additional_information_message TEXT NULL,
    rejection_reason TEXT NULL,
    collection_location_snapshot VARCHAR(255) NULL,
    collection_instructions_snapshot TEXT NULL,
    ready_at DATETIME(6) NULL,
    completed_at DATETIME(6) NULL,
    collection_date DATE NULL,
    collection_note TEXT NULL,
    version BIGINT NOT NULL DEFAULT 0,
    created_at DATETIME(6) NOT NULL,
    updated_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_document_requests_number UNIQUE (request_number),
    CONSTRAINT fk_requests_student
        FOREIGN KEY (student_user_id) REFERENCES users(id),
    CONSTRAINT fk_requests_document_type
        FOREIGN KEY (document_type_id) REFERENCES document_types(id),
    CONSTRAINT ck_requests_delivery
        CHECK (delivery_method IN ('ELECTRONIC', 'PHYSICAL')),
    CONSTRAINT ck_requests_status CHECK (
        status IN (
            'SUBMITTED',
            'UNDER_REVIEW',
            'ADDITIONAL_INFORMATION_REQUIRED',
            'APPROVED',
            'REJECTED',
            'PROCESSING',
            'READY',
            'COMPLETED'
        )
    ),
    INDEX ix_requests_student_created (student_user_id, created_at DESC),
    INDEX ix_requests_status_created (status, created_at DESC),
    INDEX ix_requests_type_created (document_type_id, created_at DESC),
    INDEX ix_requests_delivery_status (delivery_method, status),
    INDEX ix_requests_required_date (required_date),
    INDEX ix_requests_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE request_attachments (
    id BIGINT NOT NULL AUTO_INCREMENT,
    request_id BIGINT NOT NULL,
    uploaded_by_user_id BIGINT NOT NULL,
    attachment_kind VARCHAR(40) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    stored_filename VARCHAR(100) NOT NULL,
    relative_path VARCHAR(500) NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT NOT NULL,
    created_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_attachments_stored_filename UNIQUE (stored_filename),
    CONSTRAINT uq_attachments_relative_path UNIQUE (relative_path),
    CONSTRAINT fk_attachments_request
        FOREIGN KEY (request_id) REFERENCES document_requests(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_attachments_uploader
        FOREIGN KEY (uploaded_by_user_id) REFERENCES users(id),
    CONSTRAINT ck_attachments_kind
        CHECK (attachment_kind IN (
            'INITIAL_SUPPORT',
            'ADDITIONAL_INFORMATION'
        )),
    CONSTRAINT ck_attachments_size CHECK (size_bytes > 0),
    INDEX ix_attachments_request_created (request_id, created_at),
    INDEX ix_attachments_request_kind (request_id, attachment_kind)
) ENGINE=InnoDB;

CREATE TABLE issued_documents (
    id BIGINT NOT NULL AUTO_INCREMENT,
    request_id BIGINT NOT NULL,
    uploaded_by_user_id BIGINT NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    stored_filename VARCHAR(100) NOT NULL,
    relative_path VARCHAR(500) NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT NOT NULL,
    download_count INT UNSIGNED NOT NULL DEFAULT 0,
    first_downloaded_at DATETIME(6) NULL,
    last_downloaded_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_issued_documents_request UNIQUE (request_id),
    CONSTRAINT uq_issued_documents_stored_filename UNIQUE (stored_filename),
    CONSTRAINT uq_issued_documents_relative_path UNIQUE (relative_path),
    CONSTRAINT fk_issued_documents_request
        FOREIGN KEY (request_id) REFERENCES document_requests(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_issued_documents_uploader
        FOREIGN KEY (uploaded_by_user_id) REFERENCES users(id),
    CONSTRAINT ck_issued_documents_content_type
        CHECK (content_type = 'application/pdf'),
    CONSTRAINT ck_issued_documents_size CHECK (size_bytes > 0)
) ENGINE=InnoDB;

CREATE TABLE request_status_history (
    id BIGINT NOT NULL AUTO_INCREMENT,
    request_id BIGINT NOT NULL,
    previous_status VARCHAR(50) NULL,
    new_status VARCHAR(50) NOT NULL,
    changed_by_user_id BIGINT NOT NULL,
    note TEXT NULL,
    created_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_history_request
        FOREIGN KEY (request_id) REFERENCES document_requests(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_history_actor
        FOREIGN KEY (changed_by_user_id) REFERENCES users(id),
    INDEX ix_history_request_created (request_id, created_at, id),
    INDEX ix_history_actor_created (changed_by_user_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE notifications (
    id BIGINT NOT NULL AUTO_INCREMENT,
    recipient_user_id BIGINT NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    action_path VARCHAR(255) NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    read_at DATETIME(6) NULL,
    created_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_notifications_recipient
        FOREIGN KEY (recipient_user_id) REFERENCES users(id)
        ON DELETE CASCADE,
    INDEX ix_notifications_recipient_created
        (recipient_user_id, created_at DESC),
    INDEX ix_notifications_recipient_read_created
        (recipient_user_id, is_read, created_at DESC)
) ENGINE=InnoDB;
~~~

request_number is temporarily null for the first insert, then set immediately within the same service transaction after the generated ID is available. No request is returned before the number is set.

## 8. JPA aggregate and transaction boundaries

The document request is the central aggregate for workflow decisions, but JPA entities remain separate tables.

One workflow transaction may change:

- document_requests;
- request_status_history;
- notifications;
- and, for a delivery action, file metadata.

Services should not expose mutable entity collections to controllers. A detail response is assembled through explicit queries and DTO mapping.

Recommended locking:

- @Version on DocumentRequest;
- no pessimistic lock by default;
- translate OptimisticLockingFailureException to 409 REQUEST_VERSION_CONFLICT;
- return the current request version in staff detail/action responses;
- optionally accept expectedVersion in action requests for clear client intent.

## 9. Query model

### 9.1 Student list

Required predicates:

- student_user_id = current user;
- optional status;
- optional delivery method.

Sort:

- created_at descending by default.

### 9.2 Staff/admin list

Required joins:

- document_requests to users;
- optional student_profiles;
- document_types for filtering, while displaying snapshot name.

Filters:

- request number;
- student full name;
- student email;
- registration number;
- status;
- document type ID;
- delivery method;
- created-at range.

Use a JPA Specification or one explicit query builder. Do not build multiple in-memory filter stages.

### 9.3 Dashboard

Use aggregate queries:

- count all;
- count by status;
- count by delivery method;
- group by document type;
- recent ten by created_at.

The first version may execute several small count queries for clarity. A single complex dashboard query is unnecessary.

### 9.4 Report

The screen uses Page<DocumentRequestReportRow>.

CSV uses the same filter specification without pagination. For the academic/demo dataset this is sufficient. A streaming export is unnecessary.

## 10. Snapshot strategy

The request stores:

- document_type_name_snapshot;
- collection_location_snapshot;
- collection_instructions_snapshot.

Why:

- an administrator may rename or deactivate a document type;
- collection instructions may change;
- old requests must continue to show what was applicable when submitted.

The foreign key remains for filtering and catalogue relationship. The snapshot remains the display authority for historical request detail.

No snapshot is made for student name/email/profile in the MVP. Reports use current account/profile values. This is acceptable because the proposal requires current centralized information, not legal historical archiving.

## 11. Seed-data design

Seed data uses stable natural identifiers:

- account email;
- document type code;
- request number.

The seeder:

1. runs only when UNIDOC_SEED_DEMO=true;
2. checks for existing seed accounts by email;
3. upserts catalogue entries by code;
4. creates requests only when their known request numbers are absent;
5. is deterministic and idempotent;
6. never logs plain demo passwords after startup guidance.

Suggested request coverage:

- SUBMITTED electronic;
- UNDER_REVIEW physical;
- ADDITIONAL_INFORMATION_REQUIRED electronic;
- APPROVED physical;
- PROCESSING electronic;
- READY electronic with issued PDF;
- READY physical;
- REJECTED with reason;
- COMPLETED electronic;
- COMPLETED physical.

## 12. Reset order

The guarded reset clears database tables in dependency order:

1. notifications;
2. request_status_history;
3. issued_documents;
4. request_attachments;
5. document_requests;
6. student_profiles;
7. document_types;
8. nonessential users;
9. users, including demo users, if performing a full reset.

In practice, repository deleteAllInBatch calls can be ordered, or foreign-key checks can be disabled only inside the explicitly guarded local reset runner. The safer default is ordered deletion.

The reset:

- requires a confirmation token;
- refuses to run as a normal server;
- targets only the configured unidoc schema;
- reseeds when requested;
- does not delete data/uploads.

Because files remain, reset can leave orphan files. This is an explicit scope decision for the local project.

## 13. Data integrity checklist

- email unique;
- registration number unique;
- document code and name unique;
- request number unique and never null after the creation transaction returns;
- one profile per student;
- one issued document per request;
- at least one delivery method per document type;
- physical types have a location;
- required date is valid;
- terminal states cannot transition;
- optimistic version increments;
- history entry accompanies every status change;
- notification belongs to a real user;
- file metadata points below configured storage root;
- no normal hard-delete endpoint exists.

## 14. Data-model test checklist

- save and retrieve every enum as text;
- duplicate email rejected;
- duplicate registration rejected;
- duplicate document code/name rejected;
- duplicate issued document rejected;
- student/profile one-to-one enforced;
- request/document type and request/student foreign keys enforced;
- request optimistic-lock conflict detected;
- list indexes used for primary query shapes;
- reset succeeds only with guard configuration;
- seed can run twice without duplicate business data;
- historical request still displays snapshot after catalogue edit.
