# UniDoc System Overview

**Document status:** Implementation baseline  
**System name:** UniDoc  
**System subtitle:** University Document Request Management System  
**Scope authority:** Approved project proposal  
**Delivery model:** Local development and local demonstration  
**Target completion:** 18 October 2026 at 00:00 Asia/Colombo; practical completion deadline is 17 October 2026  
**Primary audience:** Student developer, project group, lecturer, demonstrators, maintainers, and testers

## 1. Purpose of this document

This document explains what UniDoc is, why it exists, who uses it, how the major parts fit together, and what implementation boundaries must be maintained. It is the starting point for the remaining technical documents.

This document does not replace the project proposal. The proposal remains the authority for deciding whether a feature belongs in the project. When a technical choice is not explicitly stated in the proposal, the smallest choice that satisfies the proposal is selected.

The implementation is intentionally a focused academic project. It must demonstrate a complete document-request process without adding enterprise-scale infrastructure or unrelated features.

## 2. Product summary

UniDoc is a responsive web application that lets university students request official documents without first visiting a university office. It provides one centralized workflow for:

1. discovering available document types;
2. submitting a document request;
3. uploading supporting documents when required;
4. allowing university staff to review, approve, reject, and process the request;
5. asking the student for additional information when the original submission is incomplete;
6. delivering an issued document electronically, or giving collection information for a physical document;
7. notifying users about important changes; and
8. allowing administrators to manage accounts, catalogue entries, monitoring, statistics, and reports.

The system supports three roles:

- **Student** - requests and receives university documents.
- **Staff** - reviews and processes student requests.
- **Administrator** - manages accounts and the document catalogue, monitors the system, and generates reports.

## 3. Problem being solved

The traditional process can require several physical visits:

- one visit to submit the request;
- another visit to ask whether it is ready; and
- a final visit to collect a physical document.

Manual records also make it harder for staff to locate requests, provide consistent status information, and prepare statistics.

UniDoc reduces those problems by moving submission, tracking, notification, and electronic delivery into a web application. A physical visit is needed only when a physical document is ready for collection.

## 4. Product goals

### 4.1 Primary goals

UniDoc shall:

1. allow students to register and sign in;
2. provide a catalogue of available university documents and their requirements;
3. allow a student to submit a request online;
4. allow supporting documents to be attached safely;
5. show the current request status and complete request history;
6. allow staff to review, approve, reject, request more information, process, and complete requests;
7. allow an electronic document to be securely uploaded and downloaded;
8. allow a physical document to be marked ready for collection and later completed;
9. provide in-app and email notifications;
10. maintain centralized MySQL records;
11. provide administrative statistics and a filterable CSV report; and
12. work responsively on desktop, tablet, and mobile screens.

### 4.2 Success outcomes

The project is successful when a demonstrator can complete both of these end-to-end paths:

**Electronic path**

~~~text
Student registers
→ completes profile
→ selects a document
→ submits an electronic request
→ staff reviews and approves
→ staff starts processing
→ staff uploads the issued PDF
→ student receives a notification
→ student downloads the PDF
→ request becomes completed
~~~

**Physical path**

~~~text
Student submits a physical request
→ staff reviews and approves
→ staff starts processing
→ staff marks it ready for collection
→ student sees the collection details
→ staff records collection
→ request becomes completed
~~~

The additional-information and rejection paths must also be demonstrable.

## 5. Scope principles

Every implementation decision follows these principles:

1. **Proposal first.** A feature that is not required by the proposal is excluded unless it is a small supporting mechanism needed to make a required feature work.
2. **One complete workflow before optional polish.** A reliable request lifecycle is more valuable than many unfinished features.
3. **One application, one API, one database.** UniDoc is a modular monolith, not a distributed system.
4. **Local operation.** Cloud deployment, cloud file storage, and production operations are not required.
5. **Simple user journeys.** Each role sees only actions relevant to that role and the current request state.
6. **Server authority.** The backend enforces roles, ownership, file access, and valid workflow transitions even if the frontend is bypassed.
7. **Recoverable UI.** Every data screen distinguishes loading, empty, error, and populated states.
8. **No speculative infrastructure.** Message brokers, WebSockets, microservices, workflow engines, and analytics platforms are excluded.

## 6. Technology baseline

| Layer | Selected technology | Purpose |
| --- | --- | --- |
| Frontend language | TypeScript | Type-safe UI and API contracts |
| Frontend library | React | Component-based single-page interface |
| Frontend build tool | Vite | Development server and production build |
| Routing | React Router | Public, protected, and role-aware routes |
| HTTP client | Axios | Shared API client and authentication interceptor |
| UI framework | Bootstrap 5.3 | Responsive grid, forms, tables, navigation, and utilities |
| Motion icons | @animateicons/react | Restrained action feedback and icon motion |
| Backend language | Java 21 | Supported long-term Java baseline for the project |
| Backend framework | Spring Boot 4.1.1 | REST API, validation, security, persistence, and email |
| Security | Spring Security and JWT | Stateless authentication and role authorization |
| Persistence | Spring Data JPA and Hibernate | MySQL mapping and repository access |
| Database | MySQL 26.7.0 | Central relational data store |
| File storage | Local filesystem | Supporting files and issued documents |
| Email | Gmail SMTP through JavaMailSender | Status notifications |
| Build | Maven Wrapper and npm | Repeatable backend and frontend commands |
| Version control | Git and GitHub | Source management and group collaboration |

The exact package versions are recorded in the Maven POM and npm lock file. The lock files, rather than this narrative document, are the final version authority during implementation.

Relevant official references:

- [Spring Boot system requirements](https://docs.spring.io/spring-boot/system-requirements.html)
- [Spring Boot email support](https://docs.spring.io/spring-boot/reference/io/email.html)
- [Spring guide for MySQL data access](https://spring.io/guides/gs/accessing-data-mysql/)
- [Spring guide for multipart file uploads](https://spring.io/guides/gs/uploading-files/)
- [React with TypeScript](https://react.dev/learn/typescript)
- [Vite guide](https://vite.dev/guide/)
- [Bootstrap accessibility guidance](https://getbootstrap.com/docs/5.3/getting-started/accessibility/)
- [AnimateIcons installation](https://animateicons.in/icons/docs)
- [MySQL 26.7 Reference Manual](https://dev.mysql.com/doc/refman/26.7/en/)

## 7. Architecture summary

UniDoc is a feature-organized modular monolith.

~~~mermaid
flowchart LR
    Browser["Web browser<br/>React + TypeScript"]
    API["UniDoc API<br/>Spring Boot"]
    DB[("MySQL<br/>unidoc")]
    Files[("Local files<br/>data/uploads")]
    Gmail["Gmail SMTP"]

    Browser -->|"HTTPS/HTTP JSON and multipart<br/>Bearer JWT"| API
    API -->|"JPA / SQL"| DB
    API -->|"Read and write"| Files
    API -.->|"Best-effort email"| Gmail
~~~

The browser never connects directly to MySQL or the upload directory. Every request passes through the Spring Boot API.

### 7.1 Backend responsibilities

The backend owns:

- authentication and token creation;
- account status checks;
- role authorization;
- student-record ownership checks;
- input validation;
- request workflow transitions;
- file validation and protected downloads;
- MySQL transactions;
- in-app notification creation;
- email sending;
- pagination, filtering, and reporting; and
- consistent error responses.

### 7.2 Frontend responsibilities

The frontend owns:

- responsive screens;
- form state and immediate usability validation;
- role-specific navigation;
- protected and role-restricted routes;
- safe display of backend data;
- API calls;
- loading, empty, error, and success states;
- confirmation dialogs for significant actions; and
- clearing the local session during sign-out or authentication failure.

Frontend checks improve usability but never replace backend authorization.

### 7.3 MySQL responsibilities

MySQL stores:

- user accounts;
- student profiles;
- document catalogue entries;
- document requests;
- workflow history;
- file metadata;
- issued-document metadata; and
- in-app notifications.

File bytes are not stored in MySQL.

### 7.4 Filesystem responsibilities

The filesystem stores:

- initial supporting documents;
- additional-information attachments; and
- issued electronic documents.

Only relative storage paths and metadata are stored in MySQL. Files are downloaded through authorized API endpoints, never through a public static directory.

### 7.5 Email responsibilities

Email mirrors important notification events. In-app notifications remain the authoritative notification record. A Gmail SMTP failure is logged but does not undo a successful request-status change.

## 8. Backend module map

The intended Java package structure is:

~~~text
com.unidoc
├── admin
├── auth
├── common
│   ├── api
│   ├── exception
│   └── web
├── config
├── dev
├── document
├── email
├── file
├── notification
├── profile
├── report
├── request
└── user
~~~

Each feature package may contain its controller, service, repository, entity, DTOs, enums, and feature-specific exceptions. This is preferred over large global controller, service, and repository folders because it keeps related code together.

### 8.1 Layering rule

A normal request follows:

~~~text
Controller
→ validates transport input
→ calls one service use case
→ service enforces role/ownership/state rules
→ repository reads or writes entities
→ service maps entities to response DTOs
→ controller returns HTTP response
~~~

Rules:

- Controllers remain thin.
- Services own business decisions and transaction boundaries.
- Repositories contain persistence queries, not business rules.
- Entities are not returned directly from public controllers.
- DTOs define the public API boundary.
- Cross-feature access goes through a service when a business rule is involved.

## 9. Frontend module map

The intended frontend structure is:

~~~text
frontend/src
├── api
│   ├── client.ts
│   ├── auth.ts
│   ├── catalogue.ts
│   ├── requests.ts
│   ├── notifications.ts
│   └── admin.ts
├── auth
│   ├── AuthContext.tsx
│   ├── ProtectedRoute.tsx
│   ├── RoleRoute.tsx
│   └── storage.ts
├── components
│   ├── FeedbackBanner.tsx
│   ├── PageHeader.tsx
│   ├── PageState.tsx
│   ├── Pagination.tsx
│   ├── RequestStatus.tsx
│   └── ConfirmDialog.tsx
├── features
│   ├── catalogue
│   ├── requests
│   ├── notifications
│   ├── profile
│   └── admin
├── layout
│   └── AppLayout.tsx
├── types
├── App.tsx
├── main.tsx
└── styles.css
~~~

Pages may remain within feature folders. A component becomes shared only when at least two screens genuinely reuse it.

## 10. User roles and main journeys

### 10.1 Student journey

1. Register with an unrestricted valid email address.
2. Sign in.
3. complete or update the student profile.
4. browse active document types.
5. read requirements and select electronic or physical delivery.
6. enter purpose and required date.
7. attach supporting files when required.
8. submit the request.
9. track status and history.
10. respond if staff asks for more information.
11. receive in-app and email updates.
12. download an electronic document or read physical collection instructions.

### 10.2 Staff journey

1. Sign in using an administrator-created account.
2. view pending requests.
3. open a request and inspect student details and supporting files.
4. move the request to Under Review.
5. either request more information, approve, or reject it.
6. start processing an approved request.
7. upload an issued PDF for electronic delivery, or mark a physical request ready.
8. record physical collection when applicable.

Every active staff member can process every request. There is no staff assignment or claim mechanism.

### 10.3 Administrator journey

1. Sign in.
2. create staff or administrator accounts.
3. activate or deactivate student, staff, or administrator accounts.
4. reset an account password.
5. create and edit document types.
6. activate or deactivate document types.
7. monitor requests without performing staff workflow actions.
8. view dashboard totals.
9. filter the request report.
10. export the current report result as CSV.

## 11. Canonical request lifecycle

~~~mermaid
stateDiagram-v2
    [*] --> SUBMITTED
    SUBMITTED --> UNDER_REVIEW: Staff starts review
    UNDER_REVIEW --> ADDITIONAL_INFORMATION_REQUIRED: Staff asks student
    ADDITIONAL_INFORMATION_REQUIRED --> SUBMITTED: Student responds
    UNDER_REVIEW --> APPROVED: Staff approves
    UNDER_REVIEW --> REJECTED: Staff rejects
    APPROVED --> PROCESSING: Staff starts processing
    PROCESSING --> READY: PDF uploaded or physical copy ready
    READY --> COMPLETED: Download or physical collection
    REJECTED --> [*]
    COMPLETED --> [*]
~~~

The backend transition matrix is authoritative. The UI hides unavailable actions, but the service rejects invalid transitions even if an API is called manually.

### 11.1 Meaning of statuses

| Status | Meaning |
| --- | --- |
| SUBMITTED | The student submitted or resubmitted the request; staff action is pending. |
| UNDER_REVIEW | A staff member opened the workflow and is checking the request. |
| ADDITIONAL_INFORMATION_REQUIRED | Staff needs a written response or more files from the student. |
| APPROVED | The request is accepted but document preparation has not been marked as started. |
| REJECTED | The request is declined. A reason is required. This is terminal. |
| PROCESSING | Staff is preparing the document. |
| READY | The electronic file is available or the physical copy is ready for collection. |
| COMPLETED | The electronic document was first downloaded or the physical document was collected. |

## 12. Delivery behavior

### 12.1 Electronic

- Staff may upload exactly one current issued document for a request.
- The issued document must be PDF.
- Uploading it from PROCESSING makes the request READY.
- Only the owning student and authorized staff can access related request data.
- The owning student can download the issued document.
- The first completed server-side download response changes READY to COMPLETED.
- Later downloads remain available and do not create another transition.

### 12.2 Physical

- The request contains a snapshot of the collection location and instructions.
- Staff changes PROCESSING to READY using the ready-for-collection action.
- The student sees the location and instructions.
- Staff records the collection date and an optional note.
- Recording collection changes READY to COMPLETED.

## 13. Notification behavior

In-app notifications and email are produced for:

- request submitted;
- additional information required;
- additional information submitted;
- request approved;
- request rejected;
- processing started;
- electronic document ready;
- physical document ready for collection; and
- request completed.

Active staff members receive notifications for new and resubmitted requests. Students receive all events that apply to their requests.

## 14. User-interface direction

### 14.1 Product personality

UniDoc should feel:

- calm;
- trustworthy;
- academic;
- clear;
- practical; and
- modern without resembling a generic decorative dashboard.

### 14.2 Branding

- Use a simple **UD** letter mark.
- Show **UniDoc** as the main product name.
- Use **University Document Request Management System** as the subtitle where appropriate.
- Do not use an official university logo.
- Do not place a university, faculty, or department name in the application branding.
- Use **#970000** as the primary brand colour.

### 14.3 Visual rules

- Use white and neutral surfaces with maroon accents.
- Use semantic colour sparingly.
- Never communicate status by colour alone; always show text.
- Avoid rows of bright generic badges.
- Use a compact status component with label and optional icon.
- Use subtle borders and shadows.
- Use one obvious primary action per view.
- Do not animate decoration continuously.
- Animate icons only on hover, focus, click, or a meaningful state change.
- Respect reduced-motion preferences.

### 14.4 Required screen states

Every data-driven screen must explicitly model:

1. **Loading** - the request is in progress.
2. **Empty** - the request succeeded and returned no records.
3. **Data** - records are available.
4. **Error** - the request failed.

Loading must never be presented as an empty state. Buttons that submit changes show a busy state and prevent accidental duplicate submission.

### 14.5 Responsive behavior

- Desktop uses a full navigation layout and tables when appropriate.
- Tablet reduces spacing and allows filters to wrap.
- Mobile uses stacked cards or horizontally scrollable tables only when a card would hide important relationships.
- Form controls remain at least comfortably touchable.
- Dialogs fit within the viewport and allow scrolling.
- File names wrap instead of overflowing.

## 15. Coding conventions

### 15.1 Backend

- Java packages and types use domain language.
- Constructors are used for required dependency injection.
- DTOs use Java records when practical.
- Request DTOs use Jakarta Bean Validation.
- Services use transactional boundaries for multi-record state changes.
- Time values are stored in UTC.
- Date-only business values use LocalDate.
- Public API responses contain no password hashes, storage paths, or internal secrets.
- Enumerations are stored as readable strings.
- Exceptions are mapped centrally to a stable error envelope.
- Repository methods are named for explicit use cases.

### 15.2 Frontend

- TypeScript strict mode remains enabled.
- API response and request types are explicit.
- Components use named exports unless a framework entry point benefits from a default export.
- API calls remain in the API layer rather than directly inside arbitrary components.
- Shared authentication behavior lives in one API client.
- Forms use controlled input state or a single consistent form approach.
- Effects synchronize with external systems only; derived values are computed during rendering.
- Role guards affect navigation, but backend errors are still handled.
- User-facing status names are readable title case; raw enum values are not displayed.

### 15.3 Git

- Work is committed in small, working increments.
- Commit messages describe the user-visible or technical change.
- Secrets, generated uploads, build output, and local database files are ignored.
- The default branch should remain demonstrable.

## 16. Data and privacy boundaries

The application handles student identity data and potentially sensitive supporting documents.

Minimum rules:

- access requires authentication except registration, login, and health check;
- students see only their own requests and files;
- staff see request information needed for processing;
- administrators can monitor records but do not perform staff workflow actions;
- file paths are never accepted directly from clients;
- downloads use server-generated identifiers and authorization checks;
- logs do not contain passwords, JWTs, file contents, or complete sensitive payloads;
- passwords use BCrypt hashes; and
- secrets are loaded from ignored environment configuration.

## 17. Operational model

UniDoc runs locally using:

- MySQL on port 3306 by default;
- Spring Boot API on port 8080;
- Vite frontend on port 5173; and
- Gmail SMTP over port 587 with STARTTLS.

The root startup script:

1. verifies Java, Node.js, npm, and configuration;
2. ensures frontend dependencies are installed;
3. starts the backend;
4. waits for the health endpoint;
5. starts the frontend; and
6. opens the application.

A guarded reset script resets and reseeds database records. It intentionally does not delete upload files.

## 18. Demonstration dataset

The deterministic seed contains:

- one administrator;
- at least one staff account;
- at least two student accounts;
- five document types;
- electronic and physical requests;
- requests in the principal lifecycle states;
- request history;
- sample notifications; and
- safe sample attachments where needed.

Suggested demo accounts:

| Role | Email | Password use |
| --- | --- | --- |
| Administrator | admin.demo@unidoc.test | Local demo only |
| Staff | staff.demo@unidoc.test | Local demo only |
| Student | student.demo@unidoc.test | Local demo only |

The actual demo password is documented in the developer/demo guide and must never be reused outside the local dataset.

## 19. Quality target

The project is considered ready when:

- frontend lint passes;
- frontend production build succeeds;
- backend tests pass on Java 21;
- the API starts against MySQL 26.7.0;
- all documented status transitions behave correctly;
- unauthorized cross-student access is rejected;
- invalid files are rejected;
- email failure does not corrupt request state;
- both delivery paths pass manual end-to-end testing;
- the layout is usable at desktop, tablet, and mobile widths;
- CSV export matches the visible filters;
- demo seed and reset work repeatedly; and
- documentation matches the implemented behavior.

## 20. Deliberate exclusions

The following are outside the project:

- payments and fees;
- cloud hosting;
- cloud object storage;
- microservices;
- message brokers;
- WebSockets or server-sent events;
- mobile applications;
- staff assignment or queues;
- multi-level approval;
- electronic signatures;
- document templates and document generation;
- file version history;
- student request cancellation;
- password recovery by email;
- single sign-on;
- PDF report generation;
- advanced analytics;
- real-time messaging;
- external student-information-system integration;
- antivirus infrastructure;
- offline mode; and
- automated deletion of uploaded files during demo reset.

## 21. Delivery sequence

| Date | Primary output |
| --- | --- |
| 9 October | Repository structure, MySQL connection, account model, authentication |
| 10 October | student profile, admin account management, document catalogue |
| 11-12 October | request submission, attachments, status history, staff actions |
| 13 October | electronic/physical delivery and notifications |
| 14 October | dashboard, reports, filtering, CSV export |
| 15 October | responsive UI, demo seed, startup/reset scripts |
| 16 October | essential tests and documentation correction |
| 17 October | full rehearsal, defect fixes, submission preparation |

If delivery slips, visual extras and nonessential refinements are reduced before any proposal requirement is removed.

## 22. Glossary

| Term | Meaning |
| --- | --- |
| Catalogue | Active document types available for student requests |
| Document request | A student's request for one official document |
| Supporting document | A student-uploaded PDF or image required to assess a request |
| Issued document | The final electronic PDF uploaded by staff |
| Delivery method | ELECTRONIC or PHYSICAL |
| Request history | Append-only record of workflow changes |
| In-app notification | A notification stored in MySQL and displayed in UniDoc |
| Email notification | A best-effort SMTP copy of an important event |
| Active account | An account allowed to authenticate and use permitted features |
| Terminal status | REJECTED or COMPLETED; no later workflow transition is allowed |
| Scope authority | The proposal used to accept or reject project features |

## 23. Document set

This overview is supported by:

- 02-requirements-and-scope.md
- 03-c4-diagrams.md
- 04-data-model.md
- 05-api-design.md
- 06-security-design.md
- 07-storage-and-sync-strategy.md
- 08-error-handling-and-logging.md
- 09-deployment-strategy.md
- 10-testing-strategy.md
- 11-architecture-decision-record.md

When documents disagree, resolve the conflict in this order:

1. approved proposal;
2. requirements and scope;
3. architecture decision records;
4. API, data, security, storage, error, deployment, and test details;
5. implementation code.

The implementation and documents must then be corrected together so they no longer disagree.
