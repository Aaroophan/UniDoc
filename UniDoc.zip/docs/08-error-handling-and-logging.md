# UniDoc Error Handling and Logging

**Goal:** Make failures consistent, actionable, secure, and diagnosable without adding heavy observability infrastructure.  
**Backend approach:** Domain exceptions plus one global HTTP exception handler.  
**Frontend approach:** Typed API errors plus page-level and action-level feedback.

## 1. Principles

1. Expected business failures are not 500 errors.
2. Every API error uses one response shape.
3. Stable machine code controls client behavior.
4. Human message is safe and understandable.
5. Field validation identifies fields.
6. Unexpected errors are logged with a request ID.
7. Client responses do not contain stack traces, SQL, or paths.
8. Controllers do not repeat try/catch mapping.
9. A warning does not automatically mean an operation failed.
10. Email failure never changes a committed request outcome.

## 2. Error categories

| Category | Example | HTTP | Log level |
| --- | --- | --- | --- |
| Authentication | Invalid credentials | 401 | INFO or WARN with rate care |
| Authorization | Wrong role | 403 | WARN |
| Hidden ownership | Other student's request | 404 | WARN or INFO |
| Validation | Missing purpose | 400 | INFO/DEBUG |
| Malformed transport | Invalid JSON | 400 | INFO |
| Not found | Unknown document type | 404 | INFO |
| Conflict | Invalid transition | 409 | INFO/WARN |
| Concurrency | Stale version | 409 | WARN |
| Storage | Disk write failed | 500 | ERROR |
| External side effect | SMTP failure | Mutation remains successful | WARN |
| Infrastructure | Database unavailable | 500/503 | ERROR |
| Programming defect | Null/unhandled exception | 500 | ERROR |

## 3. Standard error response

~~~json
{
  "timestamp": "2026-10-09T08:30:00Z",
  "status": 409,
  "error": "Conflict",
  "code": "INVALID_REQUEST_TRANSITION",
  "message": "Only a request under review can be approved.",
  "path": "/api/staff/requests/123/approve",
  "requestId": "4ae4f241-9a7a-4dfd-a884-d6f813b69474",
  "fieldErrors": null
}
~~~

Field validation:

~~~json
{
  "timestamp": "2026-10-09T08:30:00Z",
  "status": 400,
  "error": "Bad Request",
  "code": "VALIDATION_ERROR",
  "message": "Request validation failed.",
  "path": "/api/student/profile",
  "requestId": "b608e4ea-f0ee-4711-8575-d6b470f034ee",
  "fieldErrors": {
    "registrationNumber": "Registration number is required.",
    "academicYear": "Academic year must be between 1 and 8."
  }
}
~~~

Response fields:

| Field | Required | Meaning |
| --- | :---: | --- |
| timestamp | Yes | UTC failure time |
| status | Yes | Numeric HTTP status |
| error | Yes | Standard HTTP status phrase |
| code | Yes | Stable application error code |
| message | Yes | Safe user-oriented summary |
| path | Yes | Request path without query secrets |
| requestId | Yes | Correlation identifier |
| fieldErrors | No | Map of request-field errors |

## 4. Request correlation

A OncePerRequestFilter:

1. reads optional X-Request-ID;
2. accepts it only if it matches a short safe pattern;
3. otherwise generates a UUID;
4. places it in MDC as requestId;
5. returns it in X-Request-ID;
6. clears MDC in finally.

The request ID:

- is not authentication;
- does not contain user data;
- helps connect a frontend error to logs;
- appears in unexpected-error messages if useful.

Suggested pattern:

~~~text
^[A-Za-z0-9._-]{8,80}$
~~~

If a client value is absent or invalid, generate a UUID.

## 5. Backend exception design

### 5.1 Feature exceptions

Use descriptive runtime exceptions:

- InvalidCredentialsException
- InactiveAccountException
- SessionRevokedException
- DuplicateEmailException
- DuplicateRegistrationNumberException
- UserNotFoundException
- DocumentTypeNotFoundException
- DocumentTypeInactiveException
- DuplicateDocumentTypeCodeException
- ProfileIncompleteException
- DocumentRequestNotFoundException
- InvalidRequestTransitionException
- DeliveryMethodMismatchException
- RequestVersionConflictException
- FileValidationException
- FileStorageException
- AttachmentNotFoundException
- IssuedDocumentNotFoundException
- IssuedDocumentAlreadyExistsException

Avoid:

- throwing generic RuntimeException for expected cases;
- using exception message text as the only classification;
- controller-specific try/catch blocks;
- one exception class for every tiny validation rule when a code parameter is clearer.

### 5.2 FileValidationException

A single file validation exception may carry an allowed code:

- FILE_EMPTY;
- FILE_TOO_LARGE;
- FILE_COUNT_EXCEEDED;
- UNSUPPORTED_FILE_TYPE;
- SUPPORTING_DOCUMENT_REQUIRED.

This avoids several near-identical classes while preserving stable error codes.

### 5.3 Exception-to-response mapping

| Exception/category | Status | Code |
| --- | --- | --- |
| InvalidCredentialsException | 401 | AUTH_INVALID_CREDENTIALS |
| Invalid/expired bearer token | 401 | AUTHENTICATION_REQUIRED or INVALID_TOKEN |
| SessionRevokedException | 401 | SESSION_REVOKED |
| InactiveAccountException | 403 | ACCOUNT_INACTIVE |
| AccessDeniedException | 403 | ACCESS_DENIED |
| Owner-scoped missing record | 404 | REQUEST_NOT_FOUND |
| Other feature not found | 404 | Specific NOT_FOUND |
| Bean validation | 400 | VALIDATION_ERROR |
| Constraint violation | 400 | VALIDATION_ERROR |
| Malformed JSON/multipart | 400 | MALFORMED_REQUEST |
| Invalid enum/query/sort/page | 400 | INVALID_PARAMETER |
| Business input invalid | 400 | Specific code |
| Duplicate unique value | 409 | Specific duplicate code |
| Invalid transition | 409 | INVALID_REQUEST_TRANSITION |
| Optimistic lock | 409 | REQUEST_VERSION_CONFLICT |
| Storage exception | 500 | FILE_STORAGE_ERROR |
| Unhandled exception | 500 | INTERNAL_ERROR |

## 6. Global exception handler

Use @RestControllerAdvice.

Responsibilities:

- map known exceptions;
- collect field errors;
- add request ID and path;
- log at appropriate level;
- return safe message;
- catch the final Exception fallback.

It must not:

- contain feature workflow rules;
- expose stack traces;
- expose raw SQL/database error;
- return exception class names;
- log expected field errors as ERROR.

### 6.1 Bean-validation field errors

When multiple errors exist for one field:

- preserve the first deterministic error;
- use LinkedHashMap;
- do not expose internal object names;
- use JSON field names in DTOs.

Class-level errors such as password mismatch can map to:

~~~text
confirmPassword: Password confirmation does not match.
~~~

### 6.2 Malformed enum

Bad status query:

~~~text
GET /api/staff/requests?status=WAITING
~~~

Response:

- 400;
- INVALID_PARAMETER;
- message naming valid request status values if safe and concise.

### 6.3 Unique-constraint fallback

Services check uniqueness for good messages, but concurrent requests can still reach the database.

DataIntegrityViolationException should be inspected only enough to map known constraint names:

- uq_users_email → EMAIL_ALREADY_EXISTS;
- uq_student_profiles_registration → REGISTRATION_NUMBER_ALREADY_EXISTS;
- uq_document_types_code → DOCUMENT_TYPE_CODE_EXISTS;
- uq_document_types_name → DOCUMENT_TYPE_NAME_EXISTS;
- uq_issued_documents_request → ISSUED_DOCUMENT_ALREADY_EXISTS.

Unknown integrity failures return CONFLICT or INTERNAL_ERROR without raw database text.

## 7. Spring Security failures

Failures can occur before controllers and therefore need JSON handlers:

### 7.1 Authentication entry point

Missing or invalid credentials:

~~~json
{
  "status": 401,
  "code": "AUTHENTICATION_REQUIRED",
  "message": "Authentication is required to access this resource."
}
~~~

### 7.2 Access denied handler

Authenticated wrong-role caller:

~~~json
{
  "status": 403,
  "code": "ACCESS_DENIED",
  "message": "You do not have permission to perform this action."
}
~~~

### 7.3 Active-user filter

- inactive → 403 ACCOUNT_INACTIVE;
- auth version mismatch → 401 SESSION_REVOKED;
- stored role differs → 401 SESSION_REVOKED;
- missing user → 401 SESSION_REVOKED.

Handlers should write the same ApiErrorResponse format.

## 8. Frontend error model

Define:

~~~typescript
export interface ApiErrorResponse {
  timestamp: string;
  status: number;
  error: string;
  code: string;
  message: string;
  path: string;
  requestId: string;
  fieldErrors?: Record<string, string> | null;
}
~~~

Helper:

~~~typescript
export function getApiError(error: unknown): ApiErrorResponse | null
~~~

The helper:

- recognizes Axios errors;
- checks response data shape;
- returns null for non-API/network failures;
- provides a safe fallback message.

## 9. Frontend error behavior

### 9.1 Page-load error

Use PageState error panel:

- plain explanation;
- retry button;
- optional request ID;
- no raw JSON;
- keep page header/navigation usable.

Example:

~~~text
We could not load your requests.
Try again. If the problem continues, reference request 4ae4f241.
~~~

### 9.2 Form validation

On VALIDATION_ERROR:

- map fieldErrors to fields;
- show a concise form-level summary;
- focus the first invalid field where practical;
- preserve entered values;
- keep submit enabled after response.

### 9.3 Action failure

Action feedback appears near the action area or as a top feedback banner.

Examples:

- invalid transition: explain data changed and reload;
- storage error: explain file could not be stored and no successful change was recorded;
- network error: explain connection failed and state is unknown; refetch before retrying a workflow action.

### 9.4 Authentication failure

On ordinary authenticated 401:

- clear session;
- redirect to login;
- show Session expired. Please sign in again.

Do not clear session for a failed login request.

On ACCOUNT_INACTIVE:

- clear session;
- show Account is inactive. Contact an administrator.

On 403 ACCESS_DENIED:

- preserve valid session;
- show permission error or role dashboard.

### 9.5 Version conflict

On REQUEST_VERSION_CONFLICT:

1. show The request changed while you were viewing it.;
2. refetch detail;
3. do not automatically repeat the action;
4. let the user review the newest status.

### 9.6 Unknown mutation outcome

If network interruption happens after a mutation was sent, do not immediately resubmit.

Instead:

1. show Could not confirm whether the action completed.;
2. refetch the resource;
3. infer result from current status/history;
4. only offer the action again if still valid.

This avoids duplicate submissions.

## 10. Logging framework and format

Use SLF4J with Logback provided by Spring Boot.

Local console pattern should include:

- timestamp;
- level;
- thread;
- requestId;
- logger;
- message.

Example:

~~~text
2026-10-09T08:30:00.123Z INFO  [http-nio-8080-exec-2] [requestId=4ae4f241] c.u.request.DocumentRequestService - Request UDR-000123 transitioned UNDER_REVIEW -> APPROVED by userId=8
~~~

No external log collector or structured JSON logging dependency is required.

## 11. Log levels

### TRACE

Disabled. Not needed for normal development.

### DEBUG

Development detail:

- allowed sort/filter interpretation;
- non-sensitive seeder decisions;
- internal mapping steps;
- skip reason for disabled email.

Do not enable verbose Spring Security token logging.

### INFO

Expected milestones:

- application started;
- storage root initialized;
- demo seeding started/completed;
- user account created by actor ID;
- account status changed;
- document type created/updated/status changed;
- request created;
- workflow transition;
- file accepted by ID/type/size;
- CSV export count;
- guarded reset completed.

### WARN

Recoverable/suspicious events:

- invalid login, with normalized/masked identity only if needed;
- access denied;
- ownership mismatch attempt;
- stale version;
- SMTP failure;
- file cleanup failure;
- file metadata exists but bytes absent;
- malformed client request;
- unsupported configuration value ignored only when safe.

### ERROR

Unexpected operation failure:

- database unavailable;
- file write/move failure;
- unhandled exception;
- reset failure;
- startup configuration that prevents safe operation.

## 12. Event logging catalogue

| Event | Level | Fields |
| --- | --- | --- |
| Login succeeded | INFO | userId, role |
| Login failed | INFO/WARN | masked email, reason category |
| Registration | INFO | new userId |
| Account status changed | INFO | actorId, targetUserId, old/new |
| Password reset | INFO | actorId, targetUserId; never password |
| Profile updated | INFO | userId |
| Catalogue changed | INFO | actorId, documentTypeId, action |
| Request submitted | INFO | requestId, requestNumber, studentUserId, delivery |
| Request transition | INFO | requestId, actorId, previous/new |
| Invalid transition | WARN | requestId, actorId, current, attempted |
| Attachment stored | INFO | requestId, attachmentId, kind, size, content type |
| Issued document stored | INFO | requestId, issuedDocumentId, size |
| File download | INFO | requestId, fileId, callerId, callerRole |
| SMTP failed | WARN | notificationId, recipientId, exception category |
| CSV export | INFO | actorId, filter summary, row count |
| Unexpected failure | ERROR | requestId, endpoint, exception stack in server log |

## 13. Privacy and redaction

### Never log

- password/confirmation;
- BCrypt hash;
- JWT;
- Authorization header;
- SMTP App Password;
- database password;
- full request/supporting file contents;
- multipart bytes;
- full purpose or staff/student message;
- physical absolute path;
- full CSV contents.

### Minimize

- email: use user ID or mask;
- registration number: use record ID in normal logs;
- original filename: omit at INFO when sensitive;
- free-text q filter: do not log raw at INFO;
- IP address: not required for local MVP.

### Stack traces

- expected exceptions: normally no stack trace;
- unexpected exceptions: stack trace in server log at ERROR;
- never in HTTP response.

## 14. Email failure logging

Good warning:

~~~text
Email notification failed notificationId=77 recipientUserId=3 type=REQUEST_APPROVED cause=MailSendException
~~~

Bad warning:

~~~text
SMTP password abc123 failed while sending all request details and token...
~~~

No SMTP exception should escape into the workflow transaction response when the domain commit succeeded.

## 15. File failure logging

On storage failure, record:

- request ID if assigned;
- storage operation ID;
- stage/move/read/cleanup;
- content type;
- size;
- exception category;
- requestId.

Absolute path may appear only at DEBUG/ERROR if necessary for local diagnosis and never in client response.

## 16. Error-message catalogue

| Code | Safe message |
| --- | --- |
| AUTH_INVALID_CREDENTIALS | Email or password is incorrect. |
| ACCOUNT_INACTIVE | This account is inactive. Contact an administrator. |
| SESSION_REVOKED | Your session is no longer valid. Please sign in again. |
| ACCESS_DENIED | You do not have permission to perform this action. |
| EMAIL_ALREADY_EXISTS | An account already uses this email address. |
| REGISTRATION_NUMBER_ALREADY_EXISTS | This registration number is already in use. |
| PROFILE_INCOMPLETE | Complete your student profile before submitting a request. |
| DOCUMENT_TYPE_NOT_FOUND | The document type was not found. |
| DOCUMENT_TYPE_INACTIVE | This document type is not available for new requests. |
| REQUEST_NOT_FOUND | The document request was not found. |
| INVALID_REQUEST_TRANSITION | This action is not available for the request's current status. |
| REQUEST_VERSION_CONFLICT | The request changed while you were viewing it. Reload and try again. |
| SUPPORTING_DOCUMENT_REQUIRED | Add at least one supporting document. |
| FILE_COUNT_EXCEEDED | You can upload a maximum of three files for this action. |
| FILE_TOO_LARGE | One or more files exceed the allowed size. |
| UNSUPPORTED_FILE_TYPE | Only PDF, JPG, and PNG files are allowed. |
| ISSUED_DOCUMENT_ALREADY_EXISTS | An issued document already exists for this request. |
| DOCUMENT_NOT_READY | The document is not ready for download. |
| FILE_STORAGE_ERROR | The file could not be stored. No successful upload was recorded. |
| INTERNAL_ERROR | An unexpected error occurred. Use the request reference if you need support. |

Do not include technical internals in user messages.

## 17. Common scenarios

### 17.1 Duplicate email

- Service precheck finds existing normalized email.
- Throw DuplicateEmailException.
- Global handler returns 409 EMAIL_ALREADY_EXISTS.
- Frontend attaches message to email field.
- Log at INFO without password.

### 17.2 Student requests another student's record

- Owner-scoped query returns empty.
- Throw DocumentRequestNotFoundException.
- Return 404 REQUEST_NOT_FOUND.
- Log WARN with caller user ID and requested ID.
- Do not reveal owner.

### 17.3 Two staff actions

- First transaction commits.
- Second throws optimistic-lock exception.
- Map to 409 REQUEST_VERSION_CONFLICT.
- UI reloads.
- Log WARN; no server defect.

### 17.4 Email outage

- Request transaction commits.
- Listener fails.
- Log WARN.
- No change to response or request.
- User sees in-app notification.

### 17.5 File missing during download

- Metadata exists; file read fails not-found.
- Return 404 FILE_CONTENT_NOT_FOUND or ISSUED_DOCUMENT_NOT_FOUND.
- Log WARN/ERROR with metadata ID and storage operation.
- Do not mark electronic request completed.

### 17.6 Database unavailable

- Repository throws.
- Transaction rolls back.
- Moved files are cleaned best-effort.
- Return 500 INTERNAL_ERROR, or 503 when explicitly recognized.
- Log ERROR with stack trace and request ID.

## 18. Spring error configuration

Set:

~~~properties
server.error.include-message=never
server.error.include-binding-errors=never
server.error.include-stacktrace=never
server.error.include-exception=false
~~~

The custom handler provides safe messages. Default error exposure remains disabled as defense in depth.

## 19. Frontend feedback component rules

FeedbackBanner variants:

- success;
- warning;
- error;
- information.

Rules:

- use role=alert for new errors requiring attention;
- success messages need not trap focus;
- do not auto-dismiss important errors;
- avoid stacking multiple banners;
- clear stale success on a new operation;
- preserve request ID in technical detail disclosure, not as the main message;
- never display raw Axios error objects.

## 20. Testing error behavior

Automated tests verify:

- response schema for validation;
- stable code/status mapping;
- security entry point/denied handler JSON;
- no stack trace fields;
- field errors;
- optimistic lock mapping;
- unique-constraint fallback;
- safe not-found ownership behavior;
- file-storage error cleanup path;
- SMTP failure does not fail workflow;
- request ID echoed/generated;
- logs avoid known secret test markers where practical.

Manual tests verify:

- page error retry;
- form field errors;
- session expiry redirect;
- access denied behavior;
- conflict reload;
- offline/network failure wording;
- download-not-ready behavior.

## 21. Completion checklist

- [ ] All errors use ApiErrorResponse.
- [ ] Security filter errors use same shape.
- [ ] Stable codes documented and typed in frontend.
- [ ] Field errors bind to forms.
- [ ] Expected exceptions are not ERROR logs.
- [ ] Unexpected exceptions have request ID and server stack trace.
- [ ] Client receives no stack trace, SQL, or storage path.
- [ ] Token/password/secrets absent from logs.
- [ ] Ownership failure does not reveal another user's record.
- [ ] SMTP failure is warning only.
- [ ] Unknown mutation outcome triggers refetch, not blind retry.
- [ ] Version conflict reload behavior implemented.
- [ ] Log wording matches domain terminology.
