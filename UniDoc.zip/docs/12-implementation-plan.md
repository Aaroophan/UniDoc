# Issue 1 - Establish the Repository and Local Development Baseline

Create the smallest complete workspace from which every later UniDoc feature can be built and demonstrated. This issue establishes the documented `backend`, `frontend`, `data`, `docs`, and `scripts` boundaries; pins the agreed Java/Spring and React/Vite stack; prepares safe configuration; and proves that the browser, API, MySQL, and filesystem can start together. Do not implement business features yet. The output is a repeatable local baseline on Windows, with no cloud service, container platform, migration framework, or additional application runtime. Complete this issue before feature entities or pages are added, because every later issue depends on the project structure, configuration names, ports, and build commands defined here.

## Issue 1.1 - Create the Canonical Repository Structure

Create the root `UniDoc` workspace with `backend/`, `frontend/`, `data/uploads/`, `docs/`, and `scripts/`. Place backend source only under `backend/src`, frontend source only under `frontend/src`, and operational PowerShell scripts under `scripts/`. Add root launch wrappers later in this plan, but reserve their names now: `start-dev.cmd` and `reset-demo-data.cmd`. Copy the approved architecture documents into `docs/`, including this plan, so implementation and documentation travel together. Add `data/uploads/.gitkeep` solely to preserve the empty directory. Do not place uploaded files in frontend public assets or Spring static resources. Do not add monorepo tooling, containers, a second backend, or shared-package infrastructure. Verify the tree matches the deployment document exactly and that both application directories can be opened and built independently.

## Issue 1.2 - Initialize the Java 21 Spring Boot Backend

Create a Maven-based Spring Boot 4.1.1 application in `backend/` with Java 21 and base package `com.unidoc`. Include the Maven Wrapper files so contributors use `mvnw`/`mvnw.cmd` without requiring a global Maven installation. Name the artifact so packaging produces `unidoc-backend-0.0.1-SNAPSHOT.jar`. Add the application entry point and confirm the compiler release is 21. Keep a single deployable application; do not create modules that compile or run as separate services. Configure UTF-8 source handling and standard test execution. The issue is complete when `backend\mvnw.cmd --version` reports Java 21 and `backend\mvnw.cmd clean package` can build the empty application without relying on machine-specific absolute paths.

## Issue 1.3 - Add Only the Approved Backend Dependencies

Add Spring MVC, Spring Security, OAuth2 Resource Server JWT support, Spring Data JPA, Jakarta Validation, Spring Mail, the MySQL driver, and Spring Boot test dependencies. Add Spring Security test support, H2 only in test scope for fast repository tests, and the normal test stack that supplies JUnit 5, Mockito, and AssertJ. Do not add WebFlux, a workflow engine, a message broker, cloud storage SDKs, PDF generation, Flyway, a JWT blacklist store, or observability platforms. Keep versions governed by the Spring Boot parent where possible to reduce compatibility decisions. Record any directly pinned version in `pom.xml`; the POM is the implementation-time version authority. Verify dependency resolution with the Maven Wrapper and review the dependency tree for accidental reactive or container-related infrastructure.

## Issue 1.4 - Initialize the React TypeScript Frontend

Create `frontend/` using the Vite React TypeScript template with TypeScript strict mode enabled. Install React Router, Axios, Bootstrap 5.3, and `@animateicons/react`; retain the selected Vite/React packages in `package.json` and the exact resolved versions in `package-lock.json`. Add scripts for `dev`, `build`, and `lint`. Remove template demonstration components and assets while keeping a minimal renderable root. Do not add Next.js, Tailwind, Redux, a large admin theme, browser automation, or another form/state framework unless a later approved change explicitly justifies it. Verify `npm ci`, `npm run lint`, `npm run build`, and `npm run dev` work from `frontend/`. The resulting page may be minimal, but it must contain no TypeScript errors and must be ready for React Router and Bootstrap setup.

## Issue 1.5 - Establish Ignore Rules and Secret Boundaries

Create a root `.gitignore` that excludes `.env`, `frontend/.env.local`, `frontend/node_modules/`, `frontend/dist/`, `backend/target/`, all generated files below `data/uploads/`, database dumps, and `*.log`, while retaining `data/uploads/.gitkeep`. Review Git status after dependency installation and a backend build to confirm generated artifacts are absent. Search tracked text for placeholder secret markers and ensure no real database password, Gmail App Password, or JWT secret is present. The only frontend environment value allowed is the non-secret `VITE_API_BASE_URL`; no backend secret may use a `VITE_` prefix. Add a short comment in `.gitignore` explaining that local upload bytes and configuration must never be committed. This issue is complete when a clean build leaves only intended source/configuration changes visible to Git.

## Issue 1.6 - Create the Safe Environment Configuration Template

Add root `.env.example` containing every agreed name: `UNIDOC_DB_URL`, `UNIDOC_DB_USERNAME`, `UNIDOC_DB_PASSWORD`, `UNIDOC_JWT_SECRET`, `UNIDOC_JWT_EXPIRATION_SECONDS`, `UNIDOC_ALLOWED_ORIGINS`, `VITE_API_BASE_URL`, `UNIDOC_FRONTEND_URL`, `UNIDOC_STORAGE_ROOT`, `UNIDOC_SUPPORTING_MAX_BYTES`, `UNIDOC_ISSUED_MAX_BYTES`, `UNIDOC_EMAIL_ENABLED`, `UNIDOC_EMAIL_FROM`, `UNIDOC_SMTP_HOST`, `UNIDOC_SMTP_PORT`, `UNIDOC_SMTP_USERNAME`, `UNIDOC_SMTP_APP_PASSWORD`, `UNIDOC_SMTP_AUTH`, `UNIDOC_SMTP_STARTTLS`, `UNIDOC_SEED_DEMO`, `UNIDOC_RESET_DEMO`, and `UNIDOC_RESET_CONFIRMATION`. Use placeholders, not credentials. Default email/reset off. Document copying to `.env` and protect the App Password from screenshots. Include no cloud, queue, payment, or public-hosting settings.

## Issue 1.7 - Prepare the Local MySQL Schema and Application Account

Using MySQL 26.7.0 locally, create the `unidoc` schema with `utf8mb4` and `utf8mb4_0900_ai_ci`. Create `unidoc_app@localhost` with a strong local password and grant only SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, and REFERENCES on `unidoc.*`; never configure the application to use MySQL root. Put the JDBC URL `jdbc:mysql://localhost:3306/unidoc?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC` and application credentials in `.env`. Record the SQL in developer setup documentation, not as an automatic destructive script. Verify `SHOW GRANTS`, a connection from the configured application account, UTF-8 storage, and access limited to the UniDoc schema. Local `useSSL=false` is permitted only because the database and API run on the same demonstration laptop.

## Issue 1.8 - Map Environment Values into Spring Configuration

Create `backend/src/main/resources/application.properties` using the exact mappings from the deployment strategy. Configure datasource, MySQL driver, `spring.jpa.hibernate.ddl-auto=update`, `open-in-view=false`, Hibernate UTC, JWT properties, explicit CORS origins, frontend URL, storage limits/root, email toggle/from/SMTP settings with five-second connection/read/write timeouts, demo flags, multipart outer limits, and Spring error-detail suppression. Bind application-owned groups to small validated configuration-property classes instead of scattering raw environment lookups. Do not load `.env` through frontend code or return configuration values from an endpoint. Fail startup for missing database credentials, invalid JWT material once JWT support is added, or unusable storage. Verify defaults match the documents and that configuration overrides work without source changes.

## Issue 1.9 - Initialize the Protected Storage Root

On backend startup, resolve `UNIDOC_STORAGE_ROOT`, normalize it, create `data/uploads` and `.tmp` when absent, and verify the root is a writable directory rather than a regular file. Keep the normalized root internal; do not log its absolute path at INFO or expose it through the health response. Add the request subdirectory convention (`requests/{requestId}/supporting`, `additional-information`, and `issued`) to a storage-path utility, but do not yet accept uploads. Database paths must later use forward-slash relative values. Fail startup with a clear server log if the root is unsafe or unwritable. Confirm the directory is outside frontend/public and backend/static, and that direct browser requests cannot retrieve a test file placed there.

## Issue 1.10 - Add the Public Health Endpoint and Baseline Smoke Check

Implement `GET /api/health` returning HTTP 200 and `{ "status": "ok" }`. Permit this endpoint anonymously while every future endpoint remains denied by default until explicitly configured. Keep the payload intentionally small; do not expose datasource URLs, credentials, filesystem paths, dependency versions, or environment values. Add one MockMvc smoke test and manually start the API on port 8080 against local MySQL, then start Vite on 5173 and confirm a browser can reach the frontend and health endpoint. Record the exact commands in a temporary implementation checklist. The issue is done when a new developer can copy `.env.example`, configure MySQL, build both projects, start both processes, and receive the health response without editing source.

# Issue 2 - Implement the Relational Domain Model and Persistence Layer

Translate the approved eight-table MySQL model into explicit JPA entities, enums, repositories, constraints, and query foundations. This issue establishes the persistent language used by all services: accounts, profiles, catalogue entries, requests, attachments, issued documents, status history, and notifications. Use BIGINT identities, string enums, UTC timestamps, `LocalDate` for business dates, and no normal hard-delete operations. Keep entity serialization out of controllers and avoid bidirectional JSON relationships. The issue depends on Issue 1 and must finish before authentication, catalogue, requests, files, notifications, or reports are implemented.

## Issue 2.1 - Establish Shared Persistence and Time Conventions

Enable Spring Data JPA auditing and create a small auditable base or consistent entity fields for `createdAt` and, where required, `updatedAt`, stored as `DATETIME(6)` in UTC. Use `Instant` for timestamps and `LocalDate` for required/collection dates. Define `UserRole`, `UserStatus`, `DeliveryMethod`, `RequestStatus`, `AttachmentKind`, and `NotificationType` enums with exactly the documented values and persist them using `EnumType.STRING`; never use ordinal values or an UNKNOWN fallback. Configure Hibernate JDBC time zone to UTC. Add normalization helpers for email, registration number, and document code, but keep business validation in services. Verify entity mappings write readable enum names and ISO UTC values through a focused repository test.

## Issue 2.2 - Implement the User Entity and Repository

Create `User` mapped to `users` with BIGINT auto-increment ID, normalized unique email up to 254 characters, BCrypt hash up to 100, full name up to 150, role, ACTIVE/INACTIVE status, integer `authVersion` defaulting to zero, and audit timestamps. Prevent password hash, auth version, or mutable entity state from being used as controller output. Create repository methods for normalized email lookup, existence checks, active staff lookup, and pageable filtering needed by account administration. Represent role/status with strings and include indexes for `(role,status)` and creation time. Do not add password-reset tokens, first-login flags, soft-delete timestamps, or staff assignment. Test unique email enforcement and normalized lookup behavior.

## Issue 2.3 - Implement the Student Profile Entity and Repository

Create `StudentProfile` mapped to `student_profiles`, with a unique one-to-one `userId`, unique normalized uppercase registration number, optional phone, required faculty, department, degree programme, academic year 1-8, and audit timestamps. Prefer an explicit `User` relation or user ID mapping that does not expose circular JSON; entities must never be serialized directly. Add repository lookups by user ID and registration number, including an existence check excluding the current profile for updates. Database constraints must enforce one profile per user and unique registration number; the service will later enforce that the user role is STUDENT. Add the department index documented in the model. Verify boundary academic years and both uniqueness constraints with repository tests.

## Issue 2.4 - Implement the Document Type Entity and Repository

Create `DocumentType` mapped to `document_types` with unique uppercase code, unique name, description, requirements, supporting-document flag, electronic/physical availability flags, optional collection information, active flag, creating/updating admin relations, and timestamps. Add an active-name index and repository queries for active types ordered by name plus pageable admin search by code/name and active state. Do not hard-delete catalogue entries. Preserve nullable collection instructions, but require a collection location through service validation whenever physical delivery is enabled. Keep audit user IDs internal to admin responses unless the API document explicitly needs them. Test code/name uniqueness and active catalogue ordering.

## Issue 2.5 - Implement the Document Request Aggregate Entity

Create `DocumentRequest` as the workflow aggregate mapped to `document_requests`. Include request number, owning student, document type, document-type-name snapshot, delivery method, status, purpose, required date, current additional-information message, rejection reason, collection-location/instructions snapshots, ready/completed timestamps, collection date/note, timestamps, and a `@Version` BIGINT field. Keep request number temporarily nullable only during the initial insert/flush, then set `UDR-` plus a six-digit zero-padded database ID before the creation transaction returns. Add the documented indexes for owner/creation, status, type, delivery/status, required date, and creation time. Do not add assigned staff, generic custom status, payment, cancellation, or document-generation fields.

## Issue 2.6 - Implement Attachment and Issued Document Entities

Create `RequestAttachment` mapped to `request_attachments` for immutable student-uploaded metadata and `IssuedDocument` mapped to `issued_documents` for the one-to-one final electronic file. Both store parent request, uploader, sanitized original filename, unique generated stored filename, unique relative path, validated content type, size, and creation time. Attachments also store `INITIAL_SUPPORT` or `ADDITIONAL_INFORMATION`. Issued documents add unique request ID, download count, first/last download timestamps, and PDF metadata only. Enforce one issued row per request; do not model replacement or versions. Store no absolute paths, bytes, public URLs, or client temporary paths. Add documented indexes and test duplicate issued-document rejection.

## Issue 2.7 - Implement Status History and Notification Entities

Create append-only `RequestStatusHistory` mapped to `request_status_history` with request, nullable previous status for initial submission, required new status, actor, optional plain-text note, and creation time. Add deterministic ordering by `(createdAt,id)` and expose no update/delete workflow. Create `Notification` mapped to `notifications` with recipient, documented event type, title, message, optional internal action path, read flag, read timestamp, and creation time. Index notifications by recipient/creation and recipient/read/creation. Require internal action paths beginning with `/` later in the service. Add no email delivery status, retry count, HTML body, or generic audit tables. Verify ordered history and newest-first recipient queries.

## Issue 2.8 - Define Referential Actions and Repository Boundaries

Match the data model’s foreign-key behavior: profile and notification cascade only when their user is removed by guarded reset; requests restrict deletion of student/type; request children cascade with a deleted request; actor/uploader relationships restrict deletion. Normal services must never call hard delete for users, document types, requests, files, history, or notifications. Create feature-local repositories rather than one generic persistence layer. Repositories may express owner-scoped reads, pageable filters, counts, and existence checks, but may not decide workflow transitions. Review generated MySQL DDL to ensure all foreign keys and unique constraints exist and use InnoDB. Document any Hibernate name difference that affects constraint-to-error mapping.

## Issue 2.9 - Build Query Specifications and Aggregate Projections

Create reusable JPA Specifications or one explicit query-building approach for student, staff/admin, user, document-type, and report filters. Student request queries must always constrain `studentUserId`. Staff/admin request queries must support request number, student name/email/registration number, status, document type, delivery method, inclusive creation-date range, and required date without loading all rows. Add projection/query methods for status counts, delivery counts, requests by document type, recent ten requests, and unread notifications. Allow-list sort properties at the service/API boundary; never concatenate user-provided SQL. Verify generated queries are paginated and that no repository method returns an unbounded growing list except deliberate CSV export.

## Issue 2.10 - Validate Schema Creation and Persistence Integrity

Drop and recreate a local `unidoc` schema once, start the backend with `ddl-auto=update`, and compare the generated tables, columns, types, unique keys, foreign keys, and indexes with `04-data-model.md`. Correct JPA annotations rather than hand-editing the database to hide mapping defects. Persist a minimal graph containing all eight entity types and reload it to verify enums, UTC timestamps, relationships, snapshots, and optimistic versioning. Confirm a stale concurrent update throws an optimistic-lock failure. Record any MySQL-specific behavior not reproduced by H2 for final smoke testing. The issue is complete only when clean startup produces a usable schema without manual table alteration and no unsupported table is introduced.

# Issue 3 - Implement Shared API, Validation, Error, and Logging Infrastructure

Build the cross-cutting HTTP foundation used by all feature controllers. The goal is one stable response language for pagination and errors, one request-correlation mechanism, safe validation and query handling, explicit DTO mapping, and useful local logs without leaking credentials or personal file content. Feature controllers added later must be able to remain thin and must not repeat exception mapping. This issue depends on Issues 1-2 and precedes authentication and all public feature endpoints.

## Issue 3.1 - Implement the Standard Page Response Contract

Create a generic `PageResponse<T>` matching the documented fields: `items`, zero-based `page`, `size`, `totalItems`, `totalPages`, `first`, and `last`. Provide one mapper from Spring `Page<T>` so every list returns identical metadata and never returns `items: null`. Establish defaults of page 0 and size 20, with maximum 100, but validate values before creating pageable objects. Do not introduce a generic success envelope around individual resources. Add JSON serialization tests for empty and populated pages and confirm numeric totals use suitable Java types. Frontend types will later mirror this contract exactly.

## Issue 3.2 - Implement the Standard API Error Contract and Code Catalogue

Create `ApiErrorResponse` with UTC timestamp, numeric status, standard error phrase, stable code, safe message, request path, request ID, and optional ordered `fieldErrors`. Define the documented codes centrally so controllers and frontend behavior do not depend on exception text. Include authentication, account, validation, catalogue, request, concurrency, file, not-ready, and general codes already listed in `05-api-design.md`; do not invent feature codes before a real documented case exists. Ensure error JSON cannot contain stack traces, exception class names, SQL, storage paths, JWTs, or SMTP details. Add snapshot-like serialization tests for ordinary and field-validation responses.

## Issue 3.3 - Create Focused Domain and File Exceptions

Implement descriptive runtime exceptions for the documented expected failures: invalid credentials, inactive/revoked session, duplicate email/registration/catalogue values, missing/inactive catalogue entry, incomplete profile, hidden/missing request, invalid transition, delivery mismatch, version conflict, missing/duplicate issued document, and storage failures. Use one `FileValidationException` carrying only allowed file-validation codes for empty, too large, count exceeded, unsupported type, and required-support missing. Avoid a giant generic business exception whose message determines HTTP behavior, while also avoiding a class for every annotation failure. Exceptions must carry only safe identifiers/context; never embed passwords, tokens, raw payloads, or absolute paths.

## Issue 3.4 - Implement the Global Exception Handler

Create one `@RestControllerAdvice` that maps feature exceptions to the documented 400/404/409/500 statuses, maps validation failures into deterministic camelCase field names, maps malformed JSON/multipart and bad enum/query values, and provides a final safe `INTERNAL_ERROR` fallback. Inspect known unique constraint names only enough to produce the documented duplicate codes; unknown integrity errors must not return raw database messages. Map optimistic locking to 409 `REQUEST_VERSION_CONFLICT`. Log expected failures at INFO/WARN rather than ERROR, and unexpected failures at ERROR with the correlation ID and server-side stack trace. Configure Spring’s default error exposure settings as defense in depth.

## Issue 3.5 - Build JSON Writers for Security-Layer Failures

Create reusable components for Spring Security’s authentication entry point and access-denied handler so failures occurring before a controller still use `ApiErrorResponse`. Missing/invalid authentication returns 401 `AUTHENTICATION_REQUIRED`; authenticated wrong-role access returns 403 `ACCESS_DENIED`. Leave expired/invalid token and active-user distinctions available for the authentication issue to supply. Obtain request path and correlation ID from the current request without exposing query secrets. Return JSON with the correct content type and do not redirect to HTML login pages. Add focused tests that compare these responses with controller-originated error shape.

## Issue 3.6 - Implement Request Correlation IDs

Add a highest-practical-precedence `OncePerRequestFilter` that reads optional `X-Request-ID`, accepts only `^[A-Za-z0-9._-]{8,80}$`, otherwise generates a UUID, places the value in MDC, adds it to every response header, and clears MDC in `finally`. The identifier is diagnostic only and must not affect authentication or authorization. Ensure exception handlers and security JSON writers obtain the same ID. Expose `X-Request-ID` through CORS later. Add tests for valid echo, invalid replacement, absent generation, inclusion in an error response, and MDC cleanup between requests.

## Issue 3.7 - Standardize Pagination, Filtering, and Sort Validation

Create shared helpers that validate page/size, parse asc/desc, validate inclusive date ranges, length-limit free-text queries, and translate only feature-specific allow-listed sort names into JPA properties. Reject negative pages, size outside 1-100, unknown enums, unsupported sort fields, and `from > to` with 400 `INVALID_PARAMETER`. Do not silently fall back when the client supplies an invalid value, and never forward an arbitrary property name into `Sort`. Each feature service may define its own allowed sort map while reusing the common validation machinery. Test all boundary values and ensure page numbering remains zero-based across backend and frontend.

## Issue 3.8 - Establish Explicit DTO Mapping and Data-Minimization Rules

Create shared DTOs such as `UserSummary`, actor summary, attachment metadata, history entry, and request summary only where two or more features genuinely reuse them. Use Java records where practical and explicit mapper methods; do not expose JPA entities or bidirectional relationships. Review every mapper to exclude password hashes, auth version, stored filenames, relative/absolute paths, secrets, internal configuration, and fields not permitted for the caller’s role. Keep student, staff, and admin request-detail DTOs role-specific when data access differs. Add mapping tests for sensitive-field absence and ensure optional values serialize as documented nulls while empty collections serialize as `[]`.

## Issue 3.9 - Configure Safe, Useful Application Logging

Use Spring Boot’s SLF4J/Logback stack with a console pattern containing UTC timestamp, level, thread, request ID, logger, and message. Implement consistent event wording for account, catalogue, request transition, file, email warning, CSV export, seed, and reset events as those features arrive. Establish redaction rules in code review: never log passwords, hashes, JWT/Authorization, database/SMTP secrets, multipart bodies, file bytes, full purpose/messages, or absolute paths at INFO. Use IDs, roles, states, sizes, and exception categories instead. Keep TRACE disabled and do not add an external logging service. Verify one normal request and one failure include the same correlation ID.

## Issue 3.10 - Test the Cross-Cutting HTTP Foundation

Create a compact test suite covering page serialization, field-error ordering, malformed JSON, invalid enum/query values, known/unknown data-integrity failures, optimistic lock mapping, storage failure mapping, generic 500 redaction, security entry/denied JSON, and request-ID behavior. Include a marker secret and marker path in test exceptions and assert neither appears in response bodies or normal logs where log capture is practical. Confirm `server.error.*` settings prevent fallback disclosures. Treat these tests as a gate: feature teams may add exception mappings, but they may not create controller-local response shapes or bypass request correlation.

# Issue 4 - Implement Authentication, JWT Validation, and Role Security

Deliver the complete backend identity boundary: public student registration, login, current-account lookup, one-hour HS256 JWTs, per-request account revalidation, route-role authorization, and immediate session revocation through `authVersion`. The API remains stateless and uses Bearer tokens; no cookie session, refresh token, blacklist, SSO, forgotten-password workflow, or forced first-login change is allowed. This issue depends on Issues 2-3. Its service and HTTP tests must pass before protected feature endpoints are considered secure.

## Issue 4.1 - Implement Identity Normalization and Password Policy

Create reusable server-side validation for trimmed/lowercased email using `Locale.ROOT` and passwords of 8-72 characters containing uppercase, lowercase, number, and special character. Enforce full name 2-150 and email maximum 254. Use BCrypt with strength 12 through one configured `PasswordEncoder`; never store or compare plain text manually. Implement password/confirmation matching as DTO/class validation that maps the error to `confirmPassword`. Ensure the public registration DTO has no role/status/authVersion fields, or ignores and rejects unknown privilege-bearing input according to the JSON configuration. Add tests for every password boundary and normalization behavior, including case-insensitive duplicates.

## Issue 4.2 - Implement Public Student Registration

Create registration request/response DTOs, `AuthenticationService.registerStudent`, and `POST /api/auth/register`. In one transaction, normalize email, check uniqueness, hash the password, create ACTIVE STUDENT with authVersion 0, and return `UserSummary` with HTTP 201. Registration must not create a profile, issue a token, or accept a staff/admin role. Handle the database uniqueness race as 409 `EMAIL_ALREADY_EXISTS`. Log only the new user ID. Add service and MockMvc tests for valid creation, field errors, duplicate casing, password mismatch, forced STUDENT role, and absence of password data in the JSON.

## Issue 4.3 - Implement JWT Configuration Validation and Token Creation

Bind issuer `unidoc`, Base64 secret, and expiry seconds. At startup, Base64-decode the secret, require at least 32 random bytes, and require expiry between 300 and 86400 seconds, default 3600. Configure HS256 encoder/decoder and issuer/expiry validation using Spring Security JWT support. Generate claims `sub` as user ID string, `iss`, `iat`, `exp`, normalized email, role, and `authVersion`; include no profile or file data. Return expiry time alongside the token. Add tests that decode a generated token and assert every required claim, signature algorithm, issuer, and lifetime; invalid secrets/lifetimes must fail configuration early.

## Issue 4.4 - Implement Login with Generic Credential Failure

Create login DTOs and `POST /api/auth/login`. Normalize email, locate the user, compare BCrypt password, reject INACTIVE accounts, and issue a JWT only for a valid active account. Unknown email and wrong password must both return 401 `AUTH_INVALID_CREDENTIALS` with the same message. Inactive accounts return 403 `ACCOUNT_INACTIVE`. The success body contains token, `Bearer`, expiry, and public user summary. Do not create a server session or refresh token. Log successful user ID/role and only a masked identifier plus reason category for failures. Test all success/failure paths and confirm no response/log distinguishes unknown account from wrong password.

## Issue 4.5 - Configure Stateless Spring Security and Route Families

Create `SecurityConfig` with stateless session policy, CSRF disabled for Bearer-header authentication, CORS enabled, OAuth2 resource server JWT, JSON failure handlers, no form login, and no HTTP Basic. Permit only health, registration, and login anonymously. Require STUDENT for `/api/student/**`, STAFF for `/api/staff/**`, ADMIN for `/api/admin/**`, and authentication for notifications, active catalogue, and `/api/auth/me`. Deny any unmatched endpoint unless explicitly allowed. Map the `role` claim to the authority convention used by route checks. Add route-matrix tests proving each role’s allowed and forbidden families and anonymous rejection.

## Issue 4.6 - Implement Per-Request Active User Revalidation

Add an `ActiveUserFilter` after Bearer authentication. For every authenticated call, parse the subject, load the current user, and require the account to exist, be ACTIVE, have the same role as the token, and have matching `authVersion`. Missing user, stale version, or role mismatch returns 401 `SESSION_REVOKED`; inactive returns 403 `ACCOUNT_INACTIVE`. Replace or enrich the authentication principal only with safe current identity data needed by services. Do not log tokens. Add tests for active match, absent user, inactive status, stale version, role mismatch, and filter bypass on the three public endpoints.

## Issue 4.7 - Implement the Current-Account Endpoint

Create `GET /api/auth/me` for any authenticated role. Resolve the user ID from the validated principal rather than accepting an ID parameter, reload or use the current stored account, and return `UserSummary`. This endpoint is the frontend’s session-authority check after refresh and must naturally fail for expired, revoked, or inactive sessions through the security chain. Return no token refresh, profile details, password fields, or permissions beyond role/status. Add tests for all three roles, a missing token, and a token invalidated by an authVersion change.

## Issue 4.8 - Configure Exact Local CORS Behavior

Read a comma-separated origin allow-list from `UNIDOC_ALLOWED_ORIGINS`, defaulting to `http://localhost:5173`. Allow GET, POST, PUT, PATCH, and OPTIONS; allow Authorization, Content-Type, Accept, and X-Request-ID; expose Content-Disposition and X-Request-ID. Do not use wildcard origin, credentialed cookie mode, DELETE, or unnecessary headers. Normalize configured origins without accepting trailing paths. Add tests showing the configured frontend origin receives appropriate preflight headers and an unrelated origin does not. Keep local HTTP; do not add TLS termination because public deployment is outside scope.

## Issue 4.9 - Establish the Authenticated Principal Contract

Define one small method/component through which services obtain the current numeric user ID, role, email, status, and auth version from the security context. Controllers may accept `Jwt` or a custom principal, but they must never accept the current user ID from request bodies or query parameters. Use this contract for later owner-scoped repository calls and actor history. Keep authorization decisions in services even after route rules pass. Add unit tests for malformed/non-numeric subjects and supported roles. Document the pattern in code comments so junior developers do not reimplement JWT parsing in each controller.

## Issue 4.10 - Complete Authentication and Security Regression Tests

Create `AuthenticationServiceTests`, `ActiveUserFilterTests`, JWT tests, and MockMvc route tests matching the testing strategy. Cover registration role escalation attempts, duplicate email, password hashing, valid/inactive login, generic failures, token claims, invalid signature, expiration, issuer, missing subject, stale authVersion, role mismatch, and all role route families. Assert errors use the shared envelope and contain a request ID. Run repository uniqueness tests and manually verify that changing a password/status later will invalidate an existing token. The issue is complete when only the three intended endpoints are public and no protected controller can be reached with the wrong role.

# Issue 5 - Build the Frontend Application Shell and Authentication Experience

Create the reusable React foundation that every role-specific screen will use: typed API contracts, one Axios client, sessionStorage-backed authentication state, route guards, role-aware navigation, shared page states, and the registration/login/account experiences. The frontend may improve usability but must never be treated as an authorization boundary. Use Bootstrap and small custom CSS rather than a dashboard template, and apply the generic UniDoc identity without institutional branding. This issue depends on the completed authentication API in Issue 4 and should be stable before feature pages are added.

## Issue 5.1 - Define Shared Frontend API Types

Create strict TypeScript definitions for `UserSummary`, login/register payloads and responses, `PageResponse<T>`, `ApiErrorResponse`, field-error maps, roles, account statuses, delivery methods, request statuses, and other already-approved shared enums. Keep raw backend enum values at the API boundary and provide separate human-readable label maps for rendering. Do not use `any`, loosely typed Axios responses, generated clients, or speculative fields. Add narrow type guards for `ApiErrorResponse` and role/status values when reading untrusted browser storage. Ensure optional fields match the API’s null behavior and collections are never typed as nullable. Verify `npm run build` detects a deliberately mismatched test assignment, then remove the test.

## Issue 5.2 - Implement the Central Axios Client

Create `src/api/client.ts` using `VITE_API_BASE_URL`, JSON defaults, and no embedded secret. Add a request interceptor that reads the current session and sets `Authorization: Bearer` only when a token exists. Add response handling that recognizes ordinary authenticated 401, `SESSION_REVOKED`, and `ACCOUNT_INACTIVE`, clears the session, and emits a centralized session-ending event; do not clear the session for a failed login call. Preserve valid sessions on 403 `ACCESS_DENIED`. Provide safe helpers for API errors and binary downloads without displaying raw Axios objects. Keep feature paths in feature API modules, not components. Test behavior manually with valid, expired, and invalid tokens.

## Issue 5.3 - Implement Session Storage and Auth Context

Create one versioned sessionStorage key containing token, expiry, and public user summary. Validate parsed data before use; corrupted or expired data must be removed. Implement `AuthContext` with initializing, authenticated, and unauthenticated states, plus `login`, `logout`, and current-user access. On app startup with a stored token, call `/api/auth/me`; accept the session only when the API confirms it. Clear both storage and memory on sign-out or centralized authentication failure. Do not use localStorage, cookies, refresh tokens, or background token refresh. Ensure the UI shows a loading shell while session verification is in progress instead of briefly rendering a protected page.

## Issue 5.4 - Implement Protected and Role Routes

Create `ProtectedRoute` to require an authenticated user and `RoleRoute` to restrict children to an explicit allowed-role array. Unauthenticated navigation should preserve a safe intended path when practical and redirect to `/login`; authenticated wrong-role navigation should redirect to the appropriate role dashboard or show the shared permission state. These components prevent confusing navigation only—the backend remains authoritative. Avoid role checks scattered across every page. Add manual cases for direct URL entry, refresh, login redirect, and each wrong-role combination. If small component tests are added later, they must not delay feature work.

## Issue 5.5 - Define the Complete Route Map

Configure React Router for `/`, `/login`, `/register`; shared `/dashboard`, `/catalogue`, `/notifications`, `/account`; student `/profile`, `/requests`, `/requests/new`, `/requests/:requestId`; staff `/staff/requests` and `/staff/requests/:requestId`; and administrator `/admin/dashboard`, `/admin/users`, `/admin/document-types`, `/admin/requests`, `/admin/requests/:requestId`, and `/admin/reports`. Protect every authenticated page and wrap role-specific pages in `RoleRoute`. Use a simple not-found page with an appropriate return action. `/dashboard` redirects by role. Add no payment, cancellation, password-recovery, assignment, chat, or other excluded page.

## Issue 5.6 - Build the Role-Aware Application Layout

Implement `AppLayout` with a compact UD letter mark, UniDoc name, optional system subtitle, main content container, role-specific navigation, notification entry, account entry, and sign-out action. Use Bootstrap’s responsive navigation patterns with keyboard-operable collapse behavior. Show only routes applicable to the current role: students see profile/catalogue/requests; staff see catalogue/work list; admins see catalogue, dashboard, users, document types, monitoring, and reports. Mark the active route textually and visually. Do not show staff workflow links to admin or admin actions to staff. Keep white/neutral surfaces and reserve `#970000` for brand emphasis and primary actions.

## Issue 5.7 - Create Shared Page and Feedback Components

Implement `PageHeader`, `PageState`, `FeedbackBanner`, `Pagination`, `RequestStatus`, and `ConfirmDialog` skeletons with typed props. `PageState` must distinguish loading, empty, error, and data rather than treating missing data as empty; its error state includes retry and optional request ID. `FeedbackBanner` supports success, warning, error, and information, avoids stacking, and uses `role=alert` for new actionable errors. `Pagination` uses server metadata and zero-based API pages while displaying human-friendly numbering. `ConfirmDialog` must be keyboard accessible and reusable for significant/terminal actions. Feature-specific behavior will be added later without changing these contracts.

## Issue 5.8 - Implement the Login Page

Build `/login` with visible email/password labels, controlled values, basic client validation mirroring server requirements where useful, submitting state, and form-level error handling. Call the typed login API, store the returned session through AuthContext, then navigate to the role dashboard. Map `AUTH_INVALID_CREDENTIALS` to a generic message and `ACCOUNT_INACTIVE` to the documented contact-an-administrator message. Preserve email but never password after a failed request. Disable only while submitting to prevent duplicates. Provide links to student registration and no forgotten-password flow. Verify keyboard submission, invalid fields, server unavailable, all three demo roles, and no token/password output in the console.

## Issue 5.9 - Implement the Student Registration Page

Build `/register` for full name, unrestricted email, password, and confirmation. Mirror length/complexity rules and show field errors near controls while retaining the backend as authority. Submit to `/api/auth/register`; on success, show a clear confirmation and direct the user to login rather than automatically authenticating. Handle duplicate email and validation errors through the shared error helper. Include no role selector, status field, university-domain restriction, profile fields, or email verification. Make password guidance concise and accessible rather than decorative. Test at mobile width and with keyboard navigation.

## Issue 5.10 - Implement Account, Sign-Out, and Role Dashboard Entry

Build `/account` to show the current user’s full name, email, role, status, and a sign-out button—no profile mutation or password-change feature. Implement sign-out by clearing sessionStorage, in-memory state, and role-specific cached page state, then navigating to login. Build `/dashboard` as a role-aware redirect or minimal landing page that exposes only each role’s primary next actions. Handle a session revoked while the page is open by clearing state and showing “Session expired. Please sign in again.” Keep authentication failure messages across the redirect without exposing raw query data. Verify refresh, multiple tabs ending independently according to sessionStorage behavior, and clean sign-out.

# Issue 6 - Implement Student Profile Management

Deliver the student-owned academic profile required before request submission. The backend must combine account identity with profile data, update full name and academic data atomically, enforce ownership and uniqueness, and represent first login as a normal incomplete profile. The frontend must provide a clear responsive form and direct an incomplete student toward completion. This issue depends on authentication, the profile entity, shared error handling, and the frontend shell. It must finish before the new-request workflow.

## Issue 6.1 - Define Profile DTOs and Validation

Create `StudentProfileResponse` and `UpdateStudentProfileRequest` matching the API document. Response includes user ID, immutable email, account full name, registration number, optional phone, faculty, department, degree programme, academic year, `complete`, and update time. Apply the exact validation catalogue: name 2-150; registration 2-50 using letters, digits, slash, and hyphen; phone optional 7-30 using approved characters; faculty/department 2-100; programme 2-150; year 1-8. Normalize whitespace and uppercase registration number in the service, not the controller. Do not allow email, role, status, or user ID updates through the DTO.

## Issue 6.2 - Implement the Own-Profile Read Service

Implement `StudentProfileService.getCurrentProfile(currentUserId)` using the authenticated identity. Load the STUDENT account and optional profile. When no profile exists, return HTTP 200 data with account name/email, null academic fields, and `complete=false`; do not use 404 for first-login state. When present, compute `complete` from all required fields rather than trusting a stored flag. The method may return only the current student’s data and must reject non-student callers even though route security also restricts access. Add tests for missing, complete, and structurally incomplete legacy records.

## Issue 6.3 - Implement Atomic Profile Create or Update

Implement one transactional upsert method for the current student. Validate role, normalize registration, check uniqueness excluding the current profile, update `users.full_name`, then create or update the single `student_profiles` row. Persist both changes in the same transaction so a failure cannot leave name and academic details inconsistent. Preserve immutable account email and user relation. Map a concurrent unique constraint violation to 409 `REGISTRATION_NUMBER_ALREADY_EXISTS`. Do not create separate create/update endpoints or permit staff/admin profile editing. Verify both first creation and repeated update return the canonical response.

## Issue 6.4 - Expose and Secure Profile Endpoints

Create `GET /api/student/profile` and `PUT /api/student/profile`, both STUDENT-only. Controllers obtain the current user from the principal, use `@Valid`, call one service method, and return response DTOs; they must contain no ownership logic or repository access. Confirm staff/admin receive 403 and an unauthenticated caller receives the standard 401 JSON. Ensure the PUT path never accepts a user ID. Add MockMvc tests for field validation, successful create/update, and error envelope behavior.

## Issue 6.5 - Implement the Frontend Profile API Module

Create typed `getProfile` and `updateProfile` functions under the profile feature/API layer. Keep endpoint strings, request/response types, and error behavior out of page components. Do not cache profile beyond page state in a way that can become authoritative. Make PUT replace the editable representation and return the updated profile. Add a helper that identifies incomplete profiles solely from the returned `complete` value and required fields, not by guessing whether a request failed.

## Issue 6.6 - Build the Profile Page States

Build `/profile` using `PageHeader` and explicit loading, load-error/retry, incomplete, complete, editing, submitting, success, and submit-error states. Show email as read-only, while full name and academic fields are editable. On first login, explain that profile completion is required before document submission and make the form the obvious primary action. On a complete profile, display the data cleanly and allow editing without introducing a separate profile-history feature. Preserve entered values on server validation errors and show request ID only as secondary diagnostic text.

## Issue 6.7 - Implement Profile Form Validation and Accessibility

Mirror the server’s field lengths, patterns, and academic-year range in the frontend for immediate feedback, while always processing backend field errors. Associate labels, help text, invalid feedback, and controls with IDs and ARIA attributes. Focus the first invalid field where practical after submission. Use suitable input types but do not rely on browser validation alone. Ensure phone remains optional, registration guidance mentions allowed slash/hyphen, and email is visibly non-editable. Disable submit only while the current update is in flight. Verify keyboard-only operation and 360 px layout.

## Issue 6.8 - Enforce the Profile Prerequisite for New Requests

Create a small frontend guard used by the new-request page: load the current profile, and when `complete=false`, present a clear action to open `/profile` rather than rendering an unusable request form. This is a usability control only. Define the backend request service contract to call the authoritative completeness check independently before creation and return 400 `PROFILE_INCOMPLETE`. Do not mark profile complete based on local form state alone. Add an integration/manual scenario proving direct navigation and a direct API call are both blocked until the profile is stored.

## Issue 6.9 - Handle Registration-Number Conflicts Correctly

When `REGISTRATION_NUMBER_ALREADY_EXISTS` is returned, attach the message to the registration number field, keep all other input, and allow correction. The service must first provide a clear precheck and still map the database uniqueness race. Do not disclose which student owns the number. Log only current user ID and conflict category, not the registration number at INFO. Add a two-student test in which student B attempts to use student A’s value, and a same-student update test proving an unchanged number remains valid.

## Issue 6.10 - Verify Profile Behavior End to End

Complete the service, repository, controller, and manual tests from the testing strategy: incomplete response, create, atomic name/profile update, ownership, uniqueness, year bounds, role denial, page refresh persistence, and request prerequisite. Confirm profile update changes the displayed account full name after an AuthContext refresh or explicit state update without changing email. Run backend tests, frontend lint/build, and mobile/tablet/desktop checks. The feature is done only when a newly registered student can complete the profile without database intervention and a different user cannot target the record by ID.

# Issue 7 - Implement Administrator Account Management

Provide the administrator-only account functions required by the proposal: paginated/filterable listing, creation of STAFF or ADMIN users, activation/deactivation, and manual password reset. Account changes must invalidate existing tokens through `authVersion`; normal hard deletion, email delivery of passwords, student creation through the admin endpoint, and forced first-login changes remain excluded. This issue depends on authentication, shared pagination/errors, and the frontend shell.

## Issue 7.1 - Implement Account List Filtering and Pagination

Create an admin user query service supporting free-text name/email search, exact role, exact status, allowed sorts `createdAt`, `fullName`, `email`, `role`, and `status`, direction, page, and size. Apply filters in the repository using specifications and return `PageResponse<UserSummary>`. Default to newest-created or the documented UI choice and retain server metadata. Limit `q` and bind parameters; do not load all users or sort in memory. Add tests for each filter, combinations, empty results, boundaries, and unsupported sort rejection.

## Issue 7.2 - Implement Administrator Creation of Staff and Admin Accounts

Create a validated request containing full name, email, role, and initial password. `UserService.createManagedAccount` must accept only STAFF or ADMIN, normalize/check email, hash with BCrypt 12, create ACTIVE with authVersion 0, and return 201 `UserSummary`. Do not accept STUDENT, confirmation through email, temporary-password flags, or automatic mail. Reuse the approved password policy and map uniqueness races. Log actor ID, new user ID, and role only. Test both allowed roles, forbidden STUDENT, duplicates, invalid password, and wrong-role caller.

## Issue 7.3 - Implement Account Activation and Deactivation

Implement `PATCH /api/admin/users/{userId}/status` with ACTIVE or INACTIVE. Reject an administrator attempting to deactivate the currently authenticated own account with `SELF_DEACTIVATION_NOT_ALLOWED`. When the status actually changes, increment `authVersion`; setting the same status is idempotent and must not increment again. Do not delete the account or alter role/password. Return the updated public summary. Verify that a deactivated user cannot log in and an already issued JWT is rejected on the next request; reactivation permits a new login but does not revive an old token whose auth version is stale.

## Issue 7.4 - Implement Manual Password Reset

Implement `POST /api/admin/users/{userId}/reset-password` with new password and confirmation. Validate policy/match, hash it, increment `authVersion`, and return 204. Do not return, email, log, or persist the plain password outside the hash. Do not create a password-change-required state or forgot-password token. A missing user returns the documented safe not-found response. Test that the old password and old token stop working, the new password works for an active account, and a reset does not automatically activate an inactive account.

## Issue 7.5 - Expose the Admin User API Boundary

Create `GET /api/admin/users`, `POST /api/admin/users`, `PATCH /api/admin/users/{id}/status`, and `POST /api/admin/users/{id}/reset-password`. Use validated DTOs and authenticated actor ID, with controllers limited to HTTP mapping. Ensure only ADMIN can access these endpoints and all outputs use `UserSummary`. Return 201 for creation, 200 for status, and 204 for reset. Validate positive IDs and pagination consistently. Add MockMvc tests for role denial, field errors, duplicate mapping, self-deactivation, and absence of sensitive fields.

## Issue 7.6 - Create the Frontend Admin User API Module

Define typed functions for listing users with filters/page, creating a managed account, changing status, and resetting password. Serialize enum and paging query parameters consistently and omit blank filters. Keep password values only in local form state for the duration of submission and never store them in URL, browser storage, or logs. Update the list from mutation responses or refetch authoritatively. Map `SELF_DEACTIVATION_NOT_ALLOWED`, duplicate email, validation, session, and network errors through the shared model.

## Issue 7.7 - Build the Account Management List Page

Build `/admin/users` with filters for text, role, and status; clear-all action; server pagination; loading/empty/error/data states; and responsive rendering. Show full name, email, role, status, and creation date plus allowed actions. Keep filters stable while paging and reset to page 0 when filters change. On mobile, use a readable card or controlled horizontal table without dropping role/status/action context. Provide one obvious “Create account” action. Do not add delete, role-edit, bulk import, or student-profile editing.

## Issue 7.8 - Build the Managed Account Creation Form

Create a modal or dedicated section for full name, email, STAFF/ADMIN role, initial password, and confirmation. Use visible labels and policy guidance; never prefill a password. Submit once, show field-specific/server errors, close or reset only after success, then refresh/list the created user. The UI must not offer STUDENT. Include a reminder that the administrator must communicate the initial password outside UniDoc and that no forced-change flow exists. Test keyboard focus entry/return and small-screen dialog scrolling.

## Issue 7.9 - Build Status and Password Reset Actions

Add activation/deactivation with explicit confirmation showing the target name and intended state; deactivation must warn that active sessions will be revoked. Add a separate reset-password dialog requiring new value and confirmation, never displaying the existing password. Disable each action while pending and refresh on success. For a network interruption after submission, refetch the user before encouraging retry. Surface self-deactivation denial clearly. Keep the action controls text-labeled and avoid ambiguous icon-only buttons.

## Issue 7.10 - Verify Account Administration and Session Revocation

Run `UserServiceTests`, repository pagination/filter tests, route security tests, and the admin manual scenario. Cover managed STAFF/ADMIN creation, STUDENT rejection, duplicate email, status idempotency, self-deactivation, authVersion changes, reset hashing, old-token rejection, and responsive UI states. Verify staff cannot access the page/API, admin cannot see passwords, and no account DELETE endpoint exists. Complete only when the feature works from the UI without database editing and an account status/password change is enforced on the target user’s very next authenticated request.

# Issue 8 - Implement the Document Catalogue

Deliver the active document catalogue used by all authenticated users and the full administrator management interface. The initial five types are seeded later, but the domain rules and UI must support creating, editing, activating, and deactivating entries now. Historical requests will snapshot selected values later, so this issue must avoid deletion. The feature depends on the document-type entity, authentication, shared contracts, and frontend shell, and it must complete before request submission.

## Issue 8.1 - Define Catalogue DTOs and Business Validation

Create student/shared catalogue response and administrator request/response DTOs. Validate code 2-50 with uppercase letters, digits, underscore, or hyphen; name 2-150; description 10-2000; requirements 3-4000; collection location maximum 255 and required for physical; collection instructions maximum 2000; and at least one delivery flag true. Represent student availability as `availableDeliveryMethods` while admin responses may retain booleans for editing. Normalize code uppercase and text whitespace. When supporting documents are required, require meaningful requirements text through the existing requirements rule without creating another field.

## Issue 8.2 - Implement the Active Catalogue Read Service

Implement unpaged `GET /api/document-types` and `GET /api/document-types/{id}` for any authenticated role. Return only active entries, ordered by name, with descriptions, requirements, support requirement, methods, and physical collection information. An inactive/missing ID on this route returns 404 `DOCUMENT_TYPE_NOT_FOUND`. The list is deliberately unpaged because it is a bounded catalogue; do not generalize this exception to growing lists. Return no creator/updater audit IDs. Add service/controller tests for ordering, inactive exclusion, and all three roles.

## Issue 8.3 - Implement the Administrator Catalogue List

Implement `GET /api/admin/document-types` with free-text code/name search, active filter, page/size, and allowed sort fields `name`, `code`, `createdAt`, and `active`. Include active and inactive records and return admin DTOs containing every editable field. Apply repository pagination and validation helpers. Do not include a delete operation. Test combined filters, uniqueness case behavior, paging, and inactive visibility.

## Issue 8.4 - Implement Document Type Creation

Implement `POST /api/admin/document-types`. Validate cross-field delivery/location rules, normalize code, check code and name uniqueness, set creator/updater to the current ADMIN, and persist timestamps and requested active state. Return 201. Map prechecks and database races to `DOCUMENT_TYPE_CODE_EXISTS` or `DOCUMENT_TYPE_NAME_EXISTS`. Do not seed or hard-code the five proposal types in this service; the deterministic seeder owns initial data. Log actor ID and document type ID, not full requirement text.

## Issue 8.5 - Implement Document Type Detail and Update

Implement admin `GET` and `PUT /api/admin/document-types/{id}`. PUT replaces all editable catalogue fields under the same validation rules, updates the admin audit actor, and leaves ID/creation metadata unchanged. Allow an entry to be renamed or have collection guidance changed, understanding that later requests will snapshot values at submission. Handle uniqueness while excluding the current row. Do not modify existing request rows when a type changes. Return the updated admin DTO and add transactional tests.

## Issue 8.6 - Implement Activation and Deactivation

Implement `PATCH /api/admin/document-types/{id}/status` with `{ "active": boolean }`. Setting the same value is idempotent. Deactivation prevents future selection through active endpoints but must not delete the row, erase files, or hide existing requests. Reactivation restores catalogue visibility. Return the updated DTO and add tests proving active list behavior. There is no DELETE endpoint and no “archive requests” side effect.

## Issue 8.7 - Create Typed Catalogue API Modules

Add frontend functions for active list/detail and administrator list/create/detail/update/status. Define exact payloads, responses, pagination, and error codes. Convert admin delivery booleans to form values without losing the ability to represent electronic-only or physical-only types, even though the initial seed supports both. Keep all endpoint construction outside components. Ensure blank optional collection instructions serialize as null/empty consistently with the backend.

## Issue 8.8 - Build the Authenticated Catalogue Experience

Build `/catalogue` for all roles using responsive cards or a clear list. Display name, description, requirements, support-document requirement, supported delivery methods, and physical collection guidance where applicable. Provide student-facing navigation to `/requests/new` with the selected type only when the current user is STUDENT; staff/admin view the information without a submit action. Implement loading, empty, error, and data states. Avoid bright badge rows; use text-first labels and restrained icons. Never display inactive entries.

## Issue 8.9 - Build Administrator Catalogue Management

Build `/admin/document-types` with search, active filter, pagination, create/edit form, and activate/deactivate confirmation. The form must conditionally require collection location when physical is selected and prevent both delivery methods being unchecked. Show support requirement and concise delivery labels in the list. Preserve input and map field errors after failed saves. Ensure edit reads current server data before opening, and a network-uncertain mutation triggers refetch. Do not add delete, fee, payment, template generation, or file configuration fields.

## Issue 8.10 - Verify Catalogue Rules and Historical Safety Boundary

Run service/repository/controller tests for valid combinations, no-method rejection, physical-location requirement, case-insensitive duplicates, update, activation, active ordering, role restrictions, and paging. Manually verify all roles can browse, only admin can manage, and an inactive entry is unavailable for new request selection. Add a placeholder integration assertion or later test note that request submission must copy the name/location/instructions; do not implement request snapshots by mutating the catalogue. Run frontend lint/build and responsive checks before closing the issue.

# Issue 9 - Implement In-App Notifications and Best-Effort Email Infrastructure

Create the reusable notification capability before request workflows begin so every later transition can persist an authoritative in-app event and optionally send a plain-text Gmail message after commit. Users may list and mark only their own notifications. SMTP is never part of a domain transaction and may be disabled through a no-op sender. Do not add retries, an outbox, HTML templates, attachments, public links, WebSockets, or SMS. This issue depends on authentication, notification persistence, shared errors, and the frontend shell.

## Issue 9.1 - Define Notification Types, DTOs, and Message Inputs

Use exactly the documented notification types: `REQUEST_SUBMITTED`, `ADDITIONAL_INFORMATION_REQUIRED`, `ADDITIONAL_INFORMATION_SUBMITTED`, `REQUEST_APPROVED`, `REQUEST_REJECTED`, `PROCESSING_STARTED`, `ELECTRONIC_DOCUMENT_READY`, `PHYSICAL_DOCUMENT_READY`, and `REQUEST_COMPLETED`. Create `NotificationResponse`, unread-count response, and an internal creation command containing recipient user ID, type, title, message, and optional action path. Validate title/message limits and require action paths to begin with `/`; do not permit arbitrary external URLs. Keep text plain and concise, without sensitive attachment contents or full workflow payloads.

## Issue 9.2 - Implement Transactional Notification Creation

Create `NotificationService.create` for use inside the calling workflow transaction. It validates the recipient and internal action path, saves an unread notification, and publishes a small event referencing the committed notification/recipient data needed for email. The notification row must commit atomically with the request status/history when invoked from those services. Do not start a separate transaction that could survive a failed workflow action. Return the created entity/DTO to the caller only where useful. Add tests for unread defaults, invalid paths, missing recipients, and event publication.

## Issue 9.3 - Implement Recipient-Scoped Notification Queries

Implement a pageable current-user list with optional `read` and `type` filters and fixed newest-first ordering. Add an unread-count query that counts only the authenticated recipient. Never accept recipient ID as a public parameter and never retrieve all notifications to filter in memory. Map to DTOs containing ID, type, title, message, action path, read state/times, and creation time. Test student, staff, and admin isolation, combinations, pagination, and empty results.

## Issue 9.4 - Implement Mark-One and Mark-All Read Operations

Implement `markRead(notificationId,currentUserId)` using a recipient-scoped lookup and `markAllRead(currentUserId)` using a bounded update/query. Marking one already-read notification returns the existing state without changing `readAt`; marking all changes only the current user’s unread rows. An ID belonging to another recipient returns a safe 404. Use a transaction for mark-all. Do not implement delete, unread reversal, bulk targeting of another user, or notification preferences. Add idempotency and isolation tests.

## Issue 9.5 - Expose Notification Endpoints

Create `GET /api/notifications`, `GET /api/notifications/unread-count`, `POST /api/notifications/{id}/read`, and `POST /api/notifications/read-all`. Allow all authenticated roles and derive recipient identity from the principal. Return `PageResponse`, count JSON, updated notification, and 204 respectively. Validate page/filter values using shared helpers. Ensure wrong-owner IDs do not reveal the recipient. Add MockMvc tests for unauthenticated access, each role, invalid type/page, and standard error shape.

## Issue 9.6 - Implement Configurable Email Sender Abstraction

Define a small email-sending interface with `SmtpEmailSender` when `app.email.enabled=true` and `NoOpEmailSender` when false. Use `JavaMailSender` and `SimpleMailMessage`, a configured from address, stored recipient email, `[UniDoc]` subject prefix, title, concise message, authenticated frontend action link, and automatic-message footer. Require STARTTLS/auth as configured and rely on finite five-second timeouts. Never attach supporting/issued files, include JWTs, or send passwords. Missing/invalid email configuration must fail clearly when email is enabled but must not block startup when disabled.

## Issue 9.7 - Send Email Only After a Successful Commit

Implement an `@TransactionalEventListener(phase = AFTER_COMMIT)` and `@Async` listener that loads or receives the minimal safe notification information and calls the configured sender. Ensure the event is not processed for a rolled-back transaction. Catch mail exceptions inside the listener, log WARN with notification ID, recipient user ID, type, and exception category, and never rethrow into a completed HTTP mutation. Enable async execution with the simplest Spring configuration; no broker, retry, scheduler, or durable outbox. Add tests for successful formatting, rollback suppression where practical, and swallowed failure.

## Issue 9.8 - Build the Frontend Notification API and Page

Create typed list, unread-count, mark-one, and mark-all functions. Build `/notifications` with read-state filter, pagination, loading/empty/error/data states, mark-one action, and mark-all action. Render title, message, readable type/time, and an internal navigation action when present; never render notification text as HTML. Update local rows and unread count from authoritative responses. Provide clear empty copy for all versus unread filters. Ensure mobile layout wraps messages and action paths are routed internally.

## Issue 9.9 - Integrate Notification Access into the Layout

Add a notification navigation item and unread count to `AppLayout`. Refresh count when authentication initializes, after read actions, and when pages explicitly create known events; optional 60-second polling while authenticated may be added because it is documented, but it must stop on sign-out and is not required for correctness. Do not use WebSockets or server-sent events. Use text plus a restrained count indication rather than an unexplained blue badge. Ensure zero is either hidden accessibly or rendered without visual noise, and provide an accessible label describing unread count.

## Issue 9.10 - Verify Notification and Email Failure Semantics

Run service, recipient isolation, endpoint, listener, and formatter tests. With email disabled, confirm workflow-ready notification calls still succeed through the no-op sender. With a controlled Gmail App Password later, send one test event and verify the plain-text message/action URL. Then intentionally use invalid SMTP settings and prove the database notification remains, the initiating operation still returns success, and only a WARN is logged without credentials. Confirm no email delivery-status table or retry UI was introduced.

# Issue 10 - Implement Protected Local File Storage

Build the common storage service used by initial attachments, additional-information attachments, and the final issued PDF. The service must validate count, size, extension, declared type, and signature; stage bytes; generate safe UUID names; move files into request-specific directories; resolve authorized reads beneath the configured root; and support compensating cleanup. It does not decide workflow state or ownership—calling request services do that. This issue depends on storage initialization, persistence metadata, common errors, and logging, and must finish before multipart request submission.

## Issue 10.1 - Bind and Validate File Storage Configuration

Create validated properties for root, 5 MiB supporting maximum, and 10 MiB issued maximum, using the documented defaults. Resolve the root once at startup and supply it to storage services. Reject non-positive/unreasonable configured limits, a root that is a regular file, or a non-writable directory. Create `.tmp` but do not scan/delete final files. Keep multipart server limits at 10 MB per file and 20 MB per request as a coarse boundary; application validation remains authoritative. Add configuration tests using temporary directories and a failure case for an invalid root.

## Issue 10.2 - Sanitize Original Display Filenames

Implement a filename sanitizer that strips directory components for both slash styles, control characters, header-breaking characters, and excessive length while retaining a safe Unicode display name where possible. Original names are display/Content-Disposition metadata only and must never influence a directory or base storage name. If sanitization becomes empty, use a safe type-specific fallback. Do not trust the original extension until validation completes. Test traversal names, Windows paths, quotes, CR/LF, spaces, Unicode, very long values, and empty names.

## Issue 10.3 - Detect and Validate Supported File Formats

Implement lightweight signature detection for `%PDF-`, JPEG `FF D8 FF`, and the PNG signature. For student files, require a supported agreement among sanitized extension, declared MIME type, and signature: PDF, JPG/JPEG, or PNG. For issued files, require only PDF. Reject empty content before signature parsing and do not read entire large files simply to detect type. This is format validation, not malware scanning; do not claim antivirus protection. Return stable `FILE_EMPTY`, `FILE_TOO_LARGE`, or `UNSUPPORTED_FILE_TYPE` errors without exposing bytes.

## Issue 10.4 - Validate Student File Collections

Implement a method that accepts zero-to-three multipart files for one submission action, a flag indicating whether at least one is required, and the configured 5 MiB limit. Reject more than three before writing anything, reject missing support with `SUPPORTING_DOCUMENT_REQUIRED`, and validate every file before any final database change. A failed file must prevent the entire collection from being accepted. Return an immutable set/list of validated descriptors containing sanitized original name, server-selected extension/type, and size. Test zero optional, zero required, one of each format, fourth file, mixed valid/invalid, and exact size boundaries.

## Issue 10.5 - Validate the Single Issued PDF

Implement a separate issued-document validation entry point requiring exactly one non-empty PDF no larger than 10 MiB, with matching extension, MIME, and signature. Keep it separate from supporting-file rules so an image can never be accepted as an issued document and the 5 MiB limit is not applied incorrectly. This method does not know whether the request is electronic or PROCESSING; the workflow service checks that before storage. Test exact maximum, over maximum, image, disguised text, and valid PDF.

## Issue 10.6 - Stage Files with UUID Storage Names

For every validated file, generate a UUID plus the server-selected lowercase extension and copy it into `data/uploads/.tmp` using safe create-new semantics. Return a staging handle containing an operation ID, staged path internal to the service, stored filename, relative final category intent, and metadata. Clean all files staged by the operation if any staging copy fails. Do not persist metadata here or log bytes/original sensitive names. Add tests for collision resistance, partial failure cleanup, and absence of client filename material in stored names.

## Issue 10.7 - Finalize Files into Request Directories

Implement finalization from staging into `requests/{id}/supporting`, `additional-information`, or `issued`, creating directories as required. Use atomic move when supported and a safe replacement-free fallback; never overwrite an existing target. Normalize target paths and verify they remain beneath the configured root. Return forward-slash relative paths for database metadata. Track every moved path in the operation so the caller can request best-effort compensation if a later database operation fails. Add tests for all categories, path normalization, duplicate target refusal, and move failure.

## Issue 10.8 - Implement Compensating Cleanup

Provide explicit cleanup methods for staged and newly finalized files owned by the current storage operation. Cleanup is best effort: attempt every path, report failures in WARN logs using operation/request IDs and stage category, and never mask the original exception. It must never accept an arbitrary client path, delete an entire request directory, or delete pre-existing files. The request service will invoke it when validation/staging, final move, or database commit work fails. Test cleanup after single/multiple moves and a simulated deletion failure.

## Issue 10.9 - Implement Safe File Resolution and Response Metadata

Implement a read method that accepts only server-stored relative metadata after the caller has authorized the database record. Resolve and normalize against the root, require the path to stay below root, reject unsafe values, require a regular existing file, and read/return a Spring resource or complete bytes according to the later download algorithm. Provide a helper for safe `Content-Disposition`, exact validated content type, `X-Content-Type-Options: nosniff`, `Cache-Control: private, no-store`, and `Pragma: no-cache`. Never expose a physical path in errors. Test missing files, traversal metadata, header filenames, and each content type.

## Issue 10.10 - Complete File Storage and Security Tests

Use `@TempDir` to cover valid PDF/JPEG/PNG, empty files, both size limits, fourth file, extension/MIME/signature mismatches, UUID naming, traversal names, root escape, staging/final movement, compensation, missing reads, and relative-only metadata. Confirm tests never touch normal `data/uploads`. Add a startup test for unwritable/invalid root and a response-header test. Manually confirm placing a file below the upload root does not make it publicly reachable. Close the issue only when the storage service contains no request-status logic and callers cannot supply paths.

# Issue 11 - Implement Request Submission and Student Tracking Backend

Create the central document-request aggregate services and student endpoints for submission, paginated own-request tracking, detail/history, and attachment download. Request creation must coordinate profile/catalogue validation, staged files, request-number generation, snapshots, immutable attachment metadata, history, in-app notifications, and after-commit email using the documented compensation strategy. Students cannot edit or cancel a submitted request. This issue depends on profile, catalogue, notifications, storage, and persistence foundations.

## Issue 11.1 - Centralize Request Status and Action Rules

Create a `RequestTransitionValidator` or equivalent single source of truth representing only the allowed status transitions and delivery constraints in the approved contract. At this stage expose submission and helper queries, while later staff/delivery services call the same validator. No generic `setStatus` endpoint or free-form transition is allowed. Provide a method to compute role-appropriate `availableActions` without granting authority. Include terminal-state behavior and explicit action names. Add a parameterized test that lists every valid edge and confirms all unlisted edges are invalid, so a new state/action cannot appear silently.

## Issue 11.2 - Define Request Creation and Detail Contracts

Create `CreateDocumentRequest` with document type ID, purpose, required date, and delivery method; apply purpose 5-1000, date required/today-or-future service check, and enum validation. Define student request summary/detail, attachment metadata, history entry, student summary, issued metadata placeholder, available actions, version, and timestamps according to `05-api-design.md`. Keep multipart JSON part name `request` and file part name `files`. Do not accept student ID, status, request number, snapshots, uploader, or internal paths from the client.

## Issue 11.3 - Validate the Complete Submission Command

In `DocumentRequestService.create`, obtain current STUDENT, require a complete own profile, load the document type, require active, validate required date against the application’s current local calendar date, ensure selected method is enabled, and validate the supporting collection with the type’s requirement flag. Perform all business validation before inserting database rows, while allowing staging only after every file is format-valid. Reject missing/inactive type, unavailable method, past date, incomplete profile, and support errors using documented codes. Do not treat the requested date as a service guarantee.

## Issue 11.4 - Persist the Request Number and Catalogue Snapshots

Within one transaction, insert the request in SUBMITTED, flush to obtain its numeric ID, set `requestNumber` to `UDR-` plus six-digit ID, and copy the current type name plus physical collection location/instructions into snapshot fields. Keep the document-type foreign key for filtering. For an electronic request, collection snapshots may be null; for physical, preserve the submitted-time values even if admin edits the catalogue later. Ensure no response is built before request number is set. Test example ID 123 becomes `UDR-000123` and a later catalogue rename leaves the detail display unchanged.

## Issue 11.5 - Coordinate Initial File Finalization and Metadata

Stage validated files before the transaction, then after request ID creation move them to `requests/{id}/supporting` and create immutable `RequestAttachment` rows with kind `INITIAL_SUPPORT`, current student uploader, sanitized original name, generated name, relative path, type, and size. If final move fails, throw `FILE_STORAGE_ERROR` and roll back database work. If database work/commit fails after moves, invoke best-effort compensation for only files from this operation. Do not store metadata for a file that did not reach its final path. Test no files, multiple files, move failure, and database failure compensation.

## Issue 11.6 - Append the Initial Status History

Create a workflow-owned helper that appends `RequestStatusHistory` whenever the request enters a state. For submission, store previous status null, new status SUBMITTED, actor as the student, a concise fixed note such as “Request submitted.”, and UTC time. History must be written in the same transaction as the request and must not be editable through a repository/controller API. Ensure deterministic response ordering by creation time then ID. Add tests proving exactly one initial history row and correct actor/state.

## Issue 11.7 - Create Submission Notifications

In the creation transaction, create a confirmation notification for the student and one notification for every ACTIVE STAFF account, using `REQUEST_SUBMITTED` and role-appropriate internal action paths. Do not notify inactive staff, administrators, or arbitrary emails. Publish email events through the notification service; SMTP begins only after commit. A failed email must not change the 201 response. Add tests for recipient sets, no inactive staff, rollback producing no committed notifications/email, and consistent request number in safe message text.

## Issue 11.8 - Implement the Owner-Scoped Student Request List

Implement `GET /api/student/requests` with optional status/delivery filters, allowed sorts `createdAt`, `updatedAt`, `requiredDate`, `status`, and `requestNumber`, and standard page/size. Always query by current `studentUserId`; never load by role alone or accept owner ID. Return only own summaries with request number, snapshot type name, method, status, dates, and version as appropriate. Default newest first. Add tests with two students proving isolation, filters, sorting, empty pages, and maximum-size validation.

## Issue 11.9 - Implement Student Request Detail and Attachment Download

Implement `GET /api/student/requests/{id}` using `findByIdAndStudentUserId`, mapping request data, snapshot display fields, current additional-information message, rejection/collection fields, attachment metadata, issued metadata when allowed, ordered history, version, and student-appropriate actions. Implement `GET /api/student/requests/{requestId}/attachments/{attachmentId}`: verify the owner-scoped request, verify the attachment belongs to that request, then call safe storage read. A different student or mismatch returns 404 without revealing existence. Do not yet implement issued-document download or information response; later issues own those commands.

## Issue 11.10 - Expose and Test the Student Request API

Create the multipart POST plus list/detail/attachment GET controllers with STUDENT access, `@Valid` JSON part handling, positive IDs, correct 201/200 statuses, and safe file headers. Add service, storage-coordination, MockMvc multipart, ownership, snapshot, number, history, notification, and query tests listed in the testing strategy. Verify there is no PUT/PATCH/DELETE for student requests. Manually submit one optional-file and one required-file request through Postman before building the page. The issue is complete only when a failure leaves neither misleading database metadata nor untracked new final files from that operation.

# Issue 12 - Build the Student Catalogue, Submission, and Tracking Experience

Implement the student-facing React journey from active catalogue selection through request creation and ongoing tracking. The UI must use the typed backend, load profile/catalogue authority, build the documented multipart body, display filters and server pagination, show full history/files/delivery state, and never offer edit or cancellation. This issue depends on Issues 6, 8, 10, and 11. Additional-information response and issued download controls are added when their backend commands are implemented later.

## Issue 12.1 - Create Typed Student Request API Functions

Define request summary/detail, attachment, history, and available-action types exactly matching the backend. Implement typed functions for create, list, detail, and attachment download. Build `FormData` with an `application/json` Blob named `request` and each selected file named `files`; do not manually set multipart boundaries. Serialize only nonblank list filters. For downloads, read `Content-Disposition` safely and fall back to metadata name. Keep all HTTP and blob URL cleanup logic out of page components.

## Issue 12.2 - Connect Catalogue Selection to New Request

Allow a STUDENT on `/catalogue` to choose a type and navigate to `/requests/new` with a safe type ID in route state or query. The new page must still reload the active type by ID; navigation state is not authoritative. If the type became inactive/missing, show the documented unavailable message and return to catalogue. Preselect only a delivery method actually supported, and display requirements, support requirement, and physical collection details before form fields. Do not let staff/admin enter this flow.

## Issue 12.3 - Enforce the Profile Prerequisite in the New-Request Page

Load the student profile before enabling the form. While loading, show PageState; on error, allow retry; when incomplete, show a focused explanation and link/button to `/profile`. Never infer completeness from AuthContext or a prior visit. Even after showing the form, handle backend `PROFILE_INCOMPLETE` by redirecting/prompting because another session may have changed data. Do not copy profile identity into editable request inputs; show a read-only summary if useful.

## Issue 12.4 - Build the Request Fields and Delivery Controls

Create controlled fields for purpose, required date, and supported delivery method. Set HTML date minimum to the student’s current date while retaining backend validation. Explain that required date is requested, not guaranteed. Render electronic/physical choices only when enabled by the loaded type; if only one is available, show it clearly without creating an invalid second choice. Display the type’s collection snapshot source guidance for physical selection. Do not add fees, address, urgency, cancellation, or free-form status.

## Issue 12.5 - Build the Supporting File Selector

Accept `.pdf,.jpg,.jpeg,.png`, display the maximum three/5 MiB rules, show selected names and sizes, allow removal before submission, and require at least one when the type says so. Client-side extension/size/count checks provide quick feedback but must not claim signature validation. Wrap long filenames and label the input accessibly. Clear the browser input when the selected list is reset. Do not preview files unless trivially safe; download-based handling is sufficient and less risky.

## Issue 12.6 - Submit Multipart Data Safely

On submit, validate visible fields/files, disable the primary action and show a busy label/icon, call the typed multipart API once, and navigate to the created request detail on 201 with a success message. Map backend field/file/profile/type errors to the relevant form area. If a network interruption makes the outcome unknown, do not blindly resubmit; offer navigation/refetch of “My requests” so the user can check whether a request number was created. Preserve form values on confirmed failure. Revoke any temporary blob URLs if used.

## Issue 12.7 - Build the My Requests List

Build `/requests` with status and delivery filters, clear filters, server pagination, and newest-first default. Show request number, snapshot type name, readable delivery/status, required date, submitted and updated times, plus a clear detail action. Implement loading, empty, error/retry, and data states. Empty unfiltered state should lead to the catalogue/new request; filtered empty state should explain that no matches exist. Reset to page 0 on filter changes and preserve filters while paging. Use cards or a controlled responsive table on small screens.

## Issue 12.8 - Build Student Request Detail and History

Build `/requests/:requestId` showing request number, snapshot document information, purpose, required date, delivery method, current status explanation, submitted/updated times, relevant information/rejection/collection fields, attachment list, issued metadata placeholder, and ordered history. Render history actor/name/role, transition labels, note, and time as plain text. Show only backend-provided/student-valid actions. A 404 should use the same not-found view regardless of whether the ID belongs to another user. Keep terminal requests readable with no mutation controls.

## Issue 12.9 - Implement Supporting Attachment Downloads

For each attachment metadata row, offer a text-labeled download action that calls the owner-scoped endpoint and saves the returned blob using the safe response filename/metadata fallback. Show per-file busy/error state without blocking the whole detail page. Do not construct a static upload URL or expose relative/stored paths. Revoke created object URLs after triggering download. Confirm PDF/JPEG/PNG download with `nosniff` and no-store headers and verify a copied URL cannot be used without authentication.

## Issue 12.10 - Verify the Student Submission and Tracking Journey

Manually execute registration/profile/catalogue/submission/list/detail/attachment scenarios at 360, 768, and 1366 px. Test required and optional files, invalid type/size/count, past date, inactive type, loading/error/empty states, duplicate-submit prevention, refresh persistence, another student’s direct URL, and absence of edit/cancel actions. Run backend request tests plus frontend lint/build. Record defects against this issue rather than adding scope. Close only when a first-time student can identify the next action on every screen without database or developer assistance.

# Issue 13 - Implement the Staff Work List, Detail View, and Review Entry

Create the staff processing foundation: every active STAFF user can see every request, filter/paginate the shared work list, inspect the student/profile/request/files/history, and move a submitted request into review. There is no assignment, claim, department routing, or administrator processing privilege. Optimistic versioning and backend-computed actions must be established here because every later staff command depends on them. This issue depends on request persistence, security, file downloads, notifications, and the frontend shell.

## Issue 13.1 - Implement the Staff Request Filter Specification

Build the repository specification/query for `q` across request number, student name, email, and registration number; exact status; document type ID; delivery method; inclusive submitted-from/to dates; exact required date; allowed sorts; page; and size. Join users/profile/type only as needed and display the snapshot type name. Default to `createdAt desc`. Treat date-to as inclusive through the end of the chosen date and reject from-after-to. Do not introduce assigned-staff predicates. Test each search field, combined filters, null profiles, date boundaries, paging, and database-side sorting.

## Issue 13.2 - Implement the Staff Work-List Service and Endpoint

Create `GET /api/staff/requests`, STAFF-only, returning `PageResponse<RequestSummary>` from the filter specification. Every active staff account sees the same matching set. Validate IDs, enums, dates, sort, page, and size through shared helpers. Include version in summaries where it helps identify stale rows, but require a fresh detail before mutation. The service is read-only and must not auto-start review merely because a row was opened. Add controller tests proving STUDENT/ADMIN denial and all-staff visibility.

## Issue 13.3 - Implement Staff Request Detail Aggregation

Create `GET /api/staff/requests/{id}` that assembles the student account and academic profile, request/snapshot fields, all supporting attachments, issued metadata if present, ordered history, version, and backend-computed `availableActions`. Staff may view any request. Return no password/authVersion/stored file path. Handle an absent profile defensively even though submission normally requires one. Opening detail has no workflow side effect. Add mapping tests for each delivery/status and a missing request.

## Issue 13.4 - Compute Available Actions from Role, State, and Delivery

Implement one action calculator shared by staff detail and later student/admin mapping. For STAFF: SUBMITTED offers START_REVIEW; UNDER_REVIEW offers REQUEST_INFORMATION, APPROVE, REJECT; APPROVED offers START_PROCESSING; PROCESSING offers UPLOAD_ISSUED_DOCUMENT for electronic or READY_FOR_COLLECTION for physical; READY physical offers COMPLETE_COLLECTION; electronic READY allows staff verification download but not completion; terminal states offer no transitions. This list is a convenience only; action services independently validate. Add a table-driven test for every status/delivery pair.

## Issue 13.5 - Implement the Start-Review Transition

Create a request DTO containing `expectedVersion` and implement `POST /api/staff/requests/{id}/start-review`. In one transaction load the request, compare version, require SUBMITTED, set UNDER_REVIEW, append history with the staff actor, and return updated detail. No notification/email is required for this transition because the notification event list begins with student submission and later status outcomes. Reject stale version with `REQUEST_VERSION_CONFLICT` and invalid state with `INVALID_REQUEST_TRANSITION`. Add tests for success, every invalid current state, ADMIN/STUDENT denial, and two competing staff calls.

## Issue 13.6 - Standardize Optimistic Concurrency Handling

Require `expectedVersion` on every staff mutation, validate it against the current request, and retain JPA `@Version` as the database-level guard. Map explicit mismatch and `OptimisticLockingFailureException` to the same 409 code/message. Return the new version after successful action. Never silently overwrite, pessimistically lock across user interaction, or retry a business action automatically. Write a two-transaction/repository test in which one update succeeds and the stale update fails. Document the frontend behavior: show conflict, refetch, and require a new decision.

## Issue 13.7 - Implement Staff Attachment Download

Create `GET /api/staff/requests/{requestId}/attachments/{attachmentId}`. Require STAFF, load the request, verify the attachment belongs to that request, then resolve the file through the storage service. Staff does not need student ownership because all staff process all requests, but attachment/request mismatch must be hidden as not found. Use safe headers and no static file route. Log request/attachment/caller IDs and role without filename/content. Add authorization, mismatch, missing-byte, and header tests.

## Issue 13.8 - Build the Staff Request Work List UI

Build `/staff/requests` with text, status, document type, delivery, submitted range, and required-date filters; clear-all; server pagination; and responsive data rendering. Load active catalogue types for the filter only. Show request number, student/registration, snapshot type, method, status, required/submitted/updated dates, and detail action. Maintain filters during pagination and reset page on change. Provide useful empty and error/retry states. Do not show assignment, claim, department queue, or bulk workflow actions.

## Issue 13.9 - Build the Staff Request Detail and Action Framework

Build `/staff/requests/:id` with student/account/profile sections, request data, file downloads, history, issued metadata, version/conflict context, and an action area driven by `availableActions`. Create a reusable mutation wrapper that disables the active action, submits expectedVersion, replaces detail from success response, reports errors, and refetches after an unknown outcome. Implement Start Review first. Keep significant actions in clearly labeled buttons; do not infer actions from status on the client beyond rendering the backend list.

## Issue 13.10 - Verify Staff Read and Start-Review Behavior

Run specification/query tests, role-boundary MockMvc tests, detail mapping tests, attachment access tests, action-calculator tests, transition tests, and optimistic-lock tests. Manually sign in as two staff accounts, open the same SUBMITTED request, start review in one, and confirm the other receives a conflict/reload rather than overwriting. Verify ADMIN can monitor only through later admin routes and cannot call this endpoint. Run lint/build and responsive checks for filters, detail, and long filenames.

# Issue 14 - Implement Review Decisions and the Additional-Information Cycle

Complete the central staff review workflow from UNDER_REVIEW through information request/resubmission, approval or rejection, and APPROVED to PROCESSING. Each transition must enforce role, current state, required text, expected version, append-only history, notification recipients, and after-commit email. The student response may add up to three validated files and returns the request to SUBMITTED. No internal notes, arbitrary status editing, admin override, or student cancellation may be added. This issue depends on the staff foundation, storage, and notifications.

## Issue 14.1 - Implement a Transactional Transition Helper

Within `DocumentRequestService`, create a private/domain helper that verifies expected version and allowed action, captures previous status, applies only documented fields, appends history with actor/note, creates required notifications, and maps the updated detail. Keep each public use case explicit; do not expose a generic status parameter endpoint. Ensure request/status/history/notifications commit atomically. File-moving actions may wrap this helper later with compensation. Add tests showing an exception after status change but before completion rolls back all database changes.

## Issue 14.2 - Implement Request-Additional-Information

Create `POST /api/staff/requests/{id}/request-information` with mandatory message 5-2000 and expectedVersion. Require UNDER_REVIEW, set ADDITIONAL_INFORMATION_REQUIRED, store the current `additionalInformationMessage`, append history including the message, and notify the owning student in-app/email with a student-detail action path. Do not alter original request fields or attachments. Reject blank/short message, stale version, wrong role, and all other statuses. Return updated staff detail.

## Issue 14.3 - Implement the Student Information Response

Create multipart `POST /api/student/requests/{id}/information-response` with JSON part `response` containing message 2-2000 and optional zero-to-three PDF/JPEG/PNG files at 5 MiB. Load by request ID and owning student, require ADDITIONAL_INFORMATION_REQUIRED, validate/stage files, then transactionally finalize into `additional-information`, insert attachment rows with that kind, clear current staff message, change status to SUBMITTED, append history with the student response, confirm to the student, and notify active staff. Apply compensating cleanup on failure. Return updated student detail.

## Issue 14.4 - Implement Approval

Create `POST /api/staff/requests/{id}/approve` with expectedVersion. Require UNDER_REVIEW, set APPROVED, append history with the staff actor and a concise fixed note, create `REQUEST_APPROVED` notification/email for the student, and return detail. There is no approval note, approval chain, assigned approver, or automatic processing. Test stale version, wrong role, repeated approval, and every unsupported state.

## Issue 14.5 - Implement Rejection as a Terminal Decision

Create `POST /api/staff/requests/{id}/reject` with reason 5-2000 and expectedVersion. Require UNDER_REVIEW, set REJECTED, store `rejectionReason`, append history including the reason, and notify/email the student. REJECTED is terminal: no later transition, issued upload, collection action, or student response is valid. Do not add undo/reopen. Confirm the student detail displays the reason and no action. Add validation and terminal-state tests.

## Issue 14.6 - Implement Start Processing

Create `POST /api/staff/requests/{id}/start-processing` with expectedVersion. Require APPROVED, set PROCESSING, append history, and create `PROCESSING_STARTED` student notification/email. Do not create a file or READY state in this action. The next action depends on delivery method and is calculated separately. Test both ELECTRONIC and PHYSICAL requests, wrong statuses, stale version, and role denial.

## Issue 14.7 - Build Staff Review Decision Controls

Extend staff detail with Request Information, Approve, Reject, and Start Processing controls only when returned in `availableActions`. Request-information and rejection dialogs require visible message/reason fields before final confirmation; approve/start processing use concise confirmation as significant actions. Send the current version and replace the detail from the response. Show validation near inputs and avoid closing a dialog after failure. Do not expose a status dropdown. After success, update history/status/available actions and unread-count-related state as appropriate.

## Issue 14.8 - Build the Student Response Experience

When student detail is ADDITIONAL_INFORMATION_REQUIRED and the backend offers RESPOND, show the latest staff message prominently and a form for required written response plus optional up-to-three files. Reuse file guidance/validation and multipart behavior. Disable while submitting, preserve data on failure, and navigate/update detail on success to show SUBMITTED and the new history/attachments. Do not permit editing purpose/date/delivery or responding from another status. Handle unknown network outcome by refetching before a retry.

## Issue 14.9 - Implement Conflict and Unknown-Outcome Recovery

In staff action handling, map `REQUEST_VERSION_CONFLICT` to the documented explanation, immediately refetch detail, and never repeat the command automatically. When a mutation has a network failure after sending, show “Could not confirm whether the action completed,” refetch, and infer success from current status/history before showing another action. Apply the same pattern to student information response. Keep valid authentication on 409/ordinary network errors. Verify with simulated delayed/concurrent calls.

## Issue 14.10 - Complete the Workflow Transition Test Matrix

Implement parameterized service tests for every valid transition introduced so far and every action from unsupported statuses, including terminal REJECTED/COMPLETED behavior, role restrictions, owner restriction, method-independent review steps, required text, stale version, history actor/note, and notification recipients/types. Add multipart/compensation tests for information response and manual E2E additional-information and rejection scenarios. Close only when the state matrix contains no undocumented edge and frontend action availability agrees with the backend calculator.

# Issue 15 - Implement Electronic Document Delivery

Deliver the electronic path from PROCESSING through one staff-uploaded issued PDF, READY notification, authorized downloads, and automatic COMPLETED status on the first successful student response preparation. Later student downloads remain available, while staff verification never affects completion metadata. The feature must coordinate file storage and database state without a distributed transaction and must use safe download headers. It depends on the complete request workflow, storage, notifications, and staff/student detail pages.

## Issue 15.1 - Implement the Issued-Document Multipart Endpoint Contract

Create `POST /api/staff/requests/{id}/issued-document` accepting multipart `file` and text/integer `expectedVersion`. Require STAFF and validate missing/invalid parts consistently. Return updated request detail with 200. Keep the file part singular and do not accept metadata, target path, replacement flag, or status from the client. Map multipart outer-limit failures safely. Add MockMvc tests for correct parts, absent version/file, wrong content type, and role denial.

## Issue 15.2 - Enforce Electronic Upload Preconditions

Before staging, load request and require matching version, delivery method ELECTRONIC, status PROCESSING, and no existing issued-document row. Validate the file through the 10 MiB issued-PDF validator. Wrong method returns `DELIVERY_METHOD_MISMATCH`; wrong state returns `INVALID_REQUEST_TRANSITION`; existing row returns `ISSUED_DOCUMENT_ALREADY_EXISTS`. Retain the database unique request constraint as concurrency fallback. Do not permit replacement/versioning even if the old physical file is missing.

## Issue 15.3 - Store Issued Metadata and Enter READY Atomically

Stage the PDF, then transactionally move it to `requests/{id}/issued`, insert the one-to-one metadata with STAFF uploader and download count zero, set request READY and `readyAt`, append PROCESSING→READY history, and create the student notification. If move fails, roll back; if database work fails after move, compensate only this file. Map a unique race to the documented duplicate-issued error. Return detail only after metadata and status are committed.

## Issue 15.4 - Notify the Student That the Electronic Document Is Ready

Create `ELECTRONIC_DOCUMENT_READY` in-app notification and plain-text email with a safe message and `/requests/{id}` action path inside/after the same workflow transaction pattern. Do not attach the PDF or include a public/signed URL. SMTP failure leaves READY and the in-app notification intact. Test recipient, event type, action path, rollback behavior, and failed mail semantics.

## Issue 15.5 - Implement First Student Download Completion

Implement `GET /api/student/requests/{id}/issued-document`. Load by owner, require ELECTRONIC and READY or COMPLETED, load metadata, resolve and read the complete PDF before changing workflow state. If READY, transactionally set COMPLETED/`completedAt`, increment count, set first and last download timestamps, append READY→COMPLETED history with the student actor, and create `REQUEST_COMPLETED` notification. Then return the prepared PDF. A missing/unreadable file must not complete the request. This server-side preparation is the accepted success boundary; no client acknowledgment protocol is added.

## Issue 15.6 - Support Later Student and Staff Verification Downloads

For a student request already COMPLETED, permit the same endpoint, increment `downloadCount`, update `lastDownloadedAt`, and do not add another history/notification or alter `firstDownloadedAt`. Implement staff verification at `GET /api/staff/requests/{id}/issued-document`; require STAFF and matching metadata, return PDF, but do not change request status, first/last student timestamps, or download count. ADMIN receives no file access by default. Add tests differentiating first, later, and staff downloads.

## Issue 15.7 - Apply Secure PDF Response Headers

Return exact `application/pdf`, safely encoded original filename via Spring’s ContentDisposition builder or equivalent, `nosniff`, private/no-store cache control, and pragma no-cache. Do not stream from a public URL, expose stored filenames/paths, or concatenate raw filename into headers. Verify long/Unicode/quote-containing names and confirm an unauthenticated copied endpoint URL returns 401. Map READY without metadata to `ISSUED_DOCUMENT_NOT_FOUND` and other premature access to `DOCUMENT_NOT_READY` without leaking storage details.

## Issue 15.8 - Build Staff Issued-PDF Upload and Verification UI

On staff detail in PROCESSING/ELECTRONIC, render an upload control accepting PDF, display 10 MiB/one-file rules, require confirmation, send expectedVersion, and update detail to READY. If issued metadata exists, show name/size/upload time and a staff verification download action. Preserve selected file on validation failure when browser behavior allows and clear after success. Do not offer replace/delete/version actions. Show per-action progress and map duplicate/version/file errors clearly.

## Issue 15.9 - Build the Student Issued-Document Download Experience

On student detail when the backend allows download, show one obvious “Download document” action with metadata and status explanation. Download through the authenticated blob API, save with safe filename, then refetch detail/unread count so the first download visibly changes READY to COMPLETED. Keep the action available in COMPLETED for later downloads. If download fails or bytes are missing, do not locally mark complete. Do not preview through a public iframe or create a permanent object URL.

## Issue 15.10 - Verify the Complete Electronic Path

Automate upload precondition, signature/size, unique issued row, storage compensation, READY transition, notification, owner-only download, missing file, first completion, later counters, one history record, staff-neutral verification, safe headers, and concurrency tests. Manually execute the electronic E2E from new request through second download and verify in-app/email behavior. Check ADMIN cannot call staff upload or file endpoints. Run frontend lint/build and all three responsive widths before closure.

# Issue 16 - Implement Physical Ready-for-Collection and Completion

Deliver the physical path from PROCESSING to READY, showing the immutable collection snapshots, and then to COMPLETED when staff records a valid collection date and optional note. No file upload/download is involved in this branch. The student is notified at readiness and completion, while only STAFF can perform transitions. This issue depends on the workflow, snapshot model, notification infrastructure, and detail pages.

## Issue 16.1 - Implement Mark Ready for Collection

Create `POST /api/staff/requests/{id}/ready-for-collection` with expectedVersion. Require STAFF, PHYSICAL delivery, PROCESSING status, and version match. Set READY and `readyAt`, append history, create `PHYSICAL_DOCUMENT_READY` notification/email, and return detail. Reject electronic requests with `DELIVERY_METHOD_MISMATCH`, wrong states, and stale versions. Do not accept new location/instruction input here; use request snapshots captured at submission.

## Issue 16.2 - Preserve and Expose Collection Snapshots

Ensure staff and student detail responses show `collectionLocation` and `collectionInstructions` from request snapshot fields, not current document type values, for PHYSICAL requests. Require a nonblank location at submission through catalogue rules; handle an unexpected legacy null safely in display without inventing a new value. Add a test: submit physical request, edit catalogue location, mark ready, and confirm the request still shows the original collection details.

## Issue 16.3 - Define Collection Completion Validation

Create `CompleteCollectionRequest` with required `collectionDate`, optional note maximum 1000, and expectedVersion. Validate the date is not in the future using the same application/local calendar convention as required-date validation. Normalize blank note to null and trim text. Do not accept collector identity, signature, payment, or document-receipt upload. Map annotation errors through the standard field-error contract.

## Issue 16.4 - Implement Physical Collection Completion

Create `POST /api/staff/requests/{id}/complete-collection`. Require PHYSICAL and READY, validate version/date, set `collectionDate`, optional `collectionNote`, COMPLETED, and `completedAt`; append history with the note or concise fixed text; and create completion notification/email in one transaction. COMPLETED is terminal. Return updated detail. Reject future date, electronic method, repeated completion, and every unsupported state.

## Issue 16.5 - Implement Physical Workflow Notifications

Ensure readiness sends type `PHYSICAL_DOCUMENT_READY` with collection-aware safe wording/action path, and collection sends `REQUEST_COMPLETED`. Store notifications inside the transition transactions and send email after commit. Do not put detailed personal data or the collection note in email. Test student recipient, exact event order, failed SMTP behavior, and no duplicate notification on a rejected repeat action.

## Issue 16.6 - Build Staff Mark-Ready Controls

On staff detail for PROCESSING/PHYSICAL, show “Mark ready for collection” only when returned by `availableActions`. Before confirmation, display the snapshot location/instructions so staff can verify what the student will see. Submit expectedVersion, show busy state, replace detail on success, and handle conflict/refetch. Do not ask staff to re-enter collection information or upload a file.

## Issue 16.7 - Show Physical Collection Details to the Student

On student detail for a PHYSICAL request, show collection location/instructions prominently when READY and retain them after COMPLETED. Include `readyAt`, current status, and clear guidance that physical collection is required. Before READY, show the delivery method without falsely suggesting collection is available. Render snapshot text as plain text and handle long instructions responsively. No student “mark collected” or download action is added.

## Issue 16.8 - Build the Record-Collection Form

On staff detail for READY/PHYSICAL, provide a confirmation form with required collection date, optional note, and expectedVersion. Set the browser maximum to today while processing backend validation. Explain that submitting completes the request and is terminal. Keep labels visible, preserve values on error, disable while pending, and refetch on unknown outcome. After success, show collection fields/history and no further workflow buttons.

## Issue 16.9 - Finalize Delivery-Specific Action Enforcement

Review the transition validator, available-action calculator, controllers, and UI so electronic and physical commands can never cross: physical requests cannot upload/download issued files; electronic requests cannot be marked ready/collected; staff verification is electronic only; first student download completion is electronic only. Ensure wrong direct API calls return 409 delivery mismatch/state error rather than relying on hidden buttons. Add a complete status×method×action matrix test.

## Issue 16.10 - Verify the Complete Physical Path

Automate ready/collection transitions, snapshot stability, date/note validation, history, notifications, version conflicts, terminal behavior, role restrictions, and delivery mismatch. Manually execute a physical request from submission through collection, including a future-date failure, and confirm student location/instructions and both emails/in-app events. Check responsive forms/dialogs, frontend lint/build, and that no filesystem row/file is created for the physical delivery step.

# Issue 17 - Implement Administrator Monitoring, Dashboard, Reports, and CSV

Provide the proposal-required administrator insight without granting workflow or file-processing authority. ADMIN can read paginated request monitoring details, view explicitly defined dashboard totals, filter a request report, and export all matching rows as safe UTF-8 CSV. The report and screen must share one filter definition, and all growing lists remain server-paginated. Do not add PDF/XLSX generation, advanced charts, BI infrastructure, arbitrary analytics, or staff actions. This issue depends on completed workflows so metrics can be verified against real states.

## Issue 17.1 - Implement Read-Only Administrator Request Monitoring

Create `GET /api/admin/requests` using the same database-side filters/pagination as the staff list and `GET /api/admin/requests/{id}` using an ADMIN-specific detail DTO. Include identity/profile/request/history information needed for monitoring but omit workflow mutation actions and direct file download URLs by default. `availableActions` should be empty or absent for ADMIN. Reuse mapping/query services where safe without calling staff mutation services. Add role tests proving ADMIN read access, STAFF/STUDENT denial, and ADMIN denial on every `/api/staff/**` command.

## Issue 17.2 - Build the Administrator Monitoring Pages

Build `/admin/requests` and `/admin/requests/:id` using the same filter vocabulary and PageState patterns as staff, but render a visibly read-only experience. Show status/history/student/request/collection/issued metadata required for oversight, with no download or workflow buttons. Preserve filters/pagination and provide clear terminal/current-state information. Do not duplicate staff components if shared presentational sections can be reused without leaking permissions. Verify direct navigation cannot reveal an action hidden only by CSS.

## Issue 17.3 - Implement Dashboard Aggregate Queries

Create repository/service queries for total, pending (`SUBMITTED`, `UNDER_REVIEW`, `ADDITIONAL_INFORMATION_REQUIRED`), exact APPROVED, PROCESSING supporting count, exact REJECTED, READY, COMPLETED, delivery-method totals, grouped request counts by document type, and recent ten by creation descending. Several clear small aggregate queries are preferred to one fragile complex query. Display/group using snapshot name where historical meaning matters while retaining document type ID. Test definitions against a known dataset and ensure no in-memory scan of all requests.

## Issue 17.4 - Expose the Administrator Dashboard Endpoint

Create `GET /api/admin/dashboard` returning the exact documented shape, including `totalRequests`, primary status counts, `processingRequests`, `byDeliveryMethod`, `byDocumentType`, and `recentRequests`. Return zero/empty structures rather than null for an empty database. Require ADMIN and make the service read-only. Add controller serialization and role tests. Keep dashboard normally under three seconds on the local demo dataset; no caching layer is required.

## Issue 17.5 - Build the Responsive Administrator Dashboard

Build `/admin/dashboard` with text-labeled statistic cards, a simple requests-by-type representation, electronic/physical totals, and recent requests linking to monitoring detail. Use Bootstrap only; do not add a chart library unless the existing documents require one—they do not. Pending must use the canonical three-state definition. Avoid decorative badge overload and communicate counts with headings/text, not color alone. Implement loading/error/retry/data/empty states and ensure the mobile card order follows task importance.

## Issue 17.6 - Implement the Paginated Request Report

Create a report filter object for submitted-from/to, status, document type ID, and delivery method plus page/size/sort/direction for the screen. Apply dates to `createdAt`, with from inclusive at 00:00 and to inclusive through the selected day. Return `PageResponse<RequestReportRow>` containing request number, registration, name, email, snapshot type name, purpose, method, required date, status, created/updated/completed values. Use current user/profile details as explicitly accepted. Test individual/combined filters and page metadata.

## Issue 17.7 - Expose and Build the On-Screen Report

Create `GET /api/admin/reports/requests` and the `/admin/reports` page. The UI provides date range, status, document type, delivery filters, apply/clear behavior, pagination, and a readable result table/card layout. Keep the active filter object as the single source used for both screen requests and CSV download. Show exactly the documented columns where practical, with purpose wrapping safely. Invalid date order must be caught both client-side and server-side. No PDF or print-layout work is included.

## Issue 17.8 - Implement Safe UTF-8 CSV Serialization

Create a small CSV serializer with the required header/order. Correctly quote values containing commas, quotes, CR/LF; double embedded quotes; preserve Unicode; and prefix cells beginning with `=`, `+`, `-`, or `@` to reduce spreadsheet formula injection. Serialize null completion as empty. Use the same filtered row mapping as the screen and include a header even when no rows match. Do not add an XLSX library. Unit-test special filenames/names/purpose values, Unicode, formulas, empty results, and deterministic column order.

## Issue 17.9 - Implement the CSV Export Endpoint and UI Action

Create `GET /api/admin/reports/requests.csv` accepting exactly the screen filters but no page/size. Query all matching rows for the academic/demo dataset, generate UTF-8 CSV, and return `text/csv; charset=UTF-8`, no-store cache headers, and `unidoc-request-report-{date}.csv`. Log actor ID, safe filter summary, and row count. Add an Export CSV button using the current applied filters—not unsaved form values—and download through the authenticated Axios blob path. Verify exported rows match the filtered screen set across multiple pages.

## Issue 17.10 - Verify Administrator Read-Only Analytics

Run dashboard/report service, repository, CSV, controller, role, empty-data, and performance smoke tests. Manually compare dashboard totals with the deterministic seed; apply each and combined report filters; export/open the CSV; verify quoting/formula defense and match all pages. Confirm ADMIN cannot download files or invoke staff actions, and STAFF cannot access dashboard/report endpoints. Run responsive checks and frontend lint/build. Close only when definitions exactly match `02-requirements-and-scope.md` rather than visually plausible but inconsistent counts.

# Issue 18 - Complete Responsive, Accessible, and Recoverable UX

Perform the cross-feature user-interface completion pass after required behavior works. Apply the generic maroon/neutral visual language, responsive layouts, semantic status treatment, accessible interactions, and standardized recovery for validation, permission, session, conflict, network, and page-load failures. This issue refines existing pages; it must not introduce new features, a large design system, or continuous animation. Completion requires checking every documented route at desktop, tablet, and mobile widths in current Chrome and Edge.

## Issue 18.1 - Finalize Brand Tokens and Global Styling

Define CSS variables centered on `#970000`, neutral backgrounds/surfaces, readable text, subtle borders/shadows, focus colors, and restrained success/warning/error colors. Style the UD mark, typography, spacing, buttons, links, cards, tables, and form controls consistently through a small `styles.css` layer over Bootstrap. Do not invent a university/faculty identity or use an official logo. Check contrast and ensure maroon is not used for every element. Keep one obvious primary action per page and remove leftover template blue or decorative dashboard styling.

## Issue 18.2 - Harden Responsive Navigation and Layout

Review `AppLayout` at approximately 360, 768, and 1366 pixels. Ensure nav collapse is keyboard operable, role links remain reachable, active state is visible, main content does not overflow, and page headers/actions stack appropriately. Keep dialogs within viewport with scrollable bodies and comfortable touch targets. Avoid automatically killing or changing ports for layout reasons. Verify long names/emails/request numbers do not break the shell.

## Issue 18.3 - Standardize Forms and Submission Feedback

Audit registration, login, profile, account management, catalogue, request, staff decisions, and collection forms. Every control needs a persistent label; required fields/help text must be clear; field errors must be associated; the first invalid field should receive focus where practical; values must remain after failure; and the active submit control must show busy/disabled state. Significant or terminal actions require confirmation. Remove duplicate validation implementations that drift from the server and never disable unrelated page actions unnecessarily.

## Issue 18.4 - Standardize Loading, Empty, Data, and Error States

Apply `PageState` or equivalent explicit state handling to every data-driven page. Loading may use a restrained spinner/skeleton but must not show “no records.” Empty copy must distinguish a genuinely empty feature from filters with no matches and offer the next appropriate action. Error panels retain page navigation/header and offer retry; populated data does not disappear during a background action unless required. Ensure no unhandled promise rejection or blank page occurs when an endpoint fails.

## Issue 18.5 - Finalize Text-First Request Status Presentation

Implement one `RequestStatus` component mapping all eight enum values to title-case label, optional concise explanation, and restrained semantic style/icon. Always render text; color/icon is secondary. Remove raw enum strings and rows of noisy generic badges from all list, detail, dashboard, and report pages. Ensure terminal and attention states are distinguishable without color. Keep explanations on detail pages rather than cluttering dense tables. Test unknown enum handling as a safe visible fallback during development rather than silently mislabeling.

## Issue 18.6 - Optimize Tables, Cards, Filters, and Pagination for Mobile

For each list/report, decide deliberately between stacked cards and horizontal table scrolling based on whether relationships would be lost. Preserve critical fields and actions at mobile width, wrap long filenames/purpose, and allow filters to wrap/collapse without hiding their applied state. Pagination must remain operable and announce current page. Clear-all filters should be one action. Do not silently remove columns essential to decisions; move secondary fields into labeled card rows when needed.

## Issue 18.7 - Verify Keyboard, Focus, and Dialog Accessibility

Test tab order, visible focus, skip/landmark structure, heading hierarchy, form labels, table headers, alert semantics, and icon button names. Confirm Bootstrap dialogs trap/restore focus appropriately, escape/cancel behaves safely, and submit is not triggered twice. Ensure navigation and every workflow can be completed with keyboard only. Do not use color-only validation or status cues. Record and fix route-specific failures rather than adding an accessibility framework outside scope.

## Issue 18.8 - Apply AnimateIcons Sparingly and Respect Reduced Motion

Use `@animateicons/react` only for meaningful hover/focus/click or state-change feedback on a small set of actions. Provide accessible names through surrounding text or ARIA, never let animation carry meaning, and add CSS behavior honoring `prefers-reduced-motion`. Remove continuous, decorative, or attention-stealing animation. A static Bootstrap/icon/text alternative is acceptable where animation adds no clarity. Verify keyboard focus and reduced-motion mode do not trigger unnecessary movement.

## Issue 18.9 - Finalize Frontend Error and Recovery Behavior

Audit shared Axios/error handling: authenticated 401 clears session and returns to login with expiry message; `ACCOUNT_INACTIVE` uses its contact-admin message; ordinary 403 preserves the session and shows permission guidance; validation binds fields; 409 version conflict refetches; unknown mutation outcomes refetch before retry; network/page failures show retry; storage/download errors never fake success. Show optional request ID in secondary technical detail. Never display raw JSON, stack traces, Axios objects, paths, or server exception messages.

## Issue 18.10 - Execute Responsive, Accessibility, and Browser UAT

Run every route and core action at 360×800, 768×1024, and 1366×768 in current Chrome and Edge. Check overflow, navigation, filters, dialogs, focus, keyboard operation, labels, errors, status text, contrast, icon names, reduced motion, touch sizes, filenames, and loading/empty/error/data states. Firefox is optional only after required checks. Record results and fix Critical/High usability defects; do not introduce new functional scope. Require frontend lint and production build to pass after visual changes.

# Issue 19 - Implement Deterministic Demo Data and Local Operations

Make the completed application reliably start, reset, reseed, and demonstrate on one Windows laptop. Provide synthetic deterministic accounts, profiles, the five required catalogue entries, representative request states/files/history/notifications, guarded database-only reset, environment/bootstrap scripts, and troubleshooting guidance. Reset must preserve `data/uploads`. Cloud deployment, containers, public hosting, automatic killing of unknown processes, production backup automation, and automatic orphan deletion are outside scope.

## Issue 19.1 - Seed Deterministic Demo Accounts and Profiles

Implement `DemoDataSeeder`, enabled only by `UNIDOC_SEED_DEMO=true`, that upserts known accounts by normalized email: at least one ADMIN, one STAFF, and two STUDENT accounts including the agreed generic addresses. Hash one documented local-only demo password without logging it. Upsert profiles by user with synthetic registration/contact/academic data. Keep all accounts ACTIVE unless a deliberate inactive test record is documented. Re-running normal startup must not duplicate or unexpectedly overwrite manually progressed demo workflows.

## Issue 19.2 - Seed the Five Required Document Types

Upsert by stable codes the Student Confirmation Letter, Academic Transcript, Recommendation Letter, Certificate, and Student Status Letter. Each initially supports ELECTRONIC and PHYSICAL, with meaningful description, requirements, support flag, collection location/instructions, and active state suitable for demonstration. Use the seeded admin as creator/updater. Keep names exactly aligned with requirements and do not add fees. Re-running must update only the intended catalogue seed fields without creating duplicate code/name rows.

## Issue 19.3 - Seed Representative Request Lifecycles

Create deterministic requests identified by fixed seed request numbers covering SUBMITTED electronic, UNDER_REVIEW physical, ADDITIONAL_INFORMATION_REQUIRED electronic, APPROVED physical, PROCESSING electronic, READY electronic, READY physical, REJECTED with reason, COMPLETED electronic, and COMPLETED physical. Populate correct snapshots, status-specific fields, versions, dates, and ownership. Insert each request only if its seed request number is absent; do not reset its status on ordinary startup. Ensure no seeded state violates the transition/data constraints.

## Issue 19.4 - Seed Matching History, Notifications, and Safe Files

For each newly created seed request, create a plausible append-only history that reaches its current state and sample recipient-owned notifications. Where attachment/issued metadata is seeded, also create harmless synthetic PDF/image bytes at the exact relative paths; never create metadata-only broken downloads. Reuse storage services or controlled demo helpers so paths/names remain safe. Disable external email during seeding unless explicitly intended. Do not insert duplicate history/notifications on repeat startup.

## Issue 19.5 - Implement the Guarded Reset Runner

Create a non-web/reset-mode runner that executes only when `UNIDOC_RESET_DEMO=true` and `UNIDOC_RESET_CONFIRMATION=RESET-UNIDOC-DEMO`. It must verify the configured schema is exactly `unidoc`, require the normal server to be run on port 0/from the reset script, delete rows in dependency order, optionally reseed, log a safe summary, and terminate rather than start the web application. If either guard fails, refuse deletion. Never disable safeguards merely for convenience.

## Issue 19.6 - Preserve Uploads During Reset

The reset runner and scripts must not delete `data/uploads`, `.tmp`, request directories, attachments, or issued files. Print a clear warning before reset that database records will be deleted and uploads preserved, potentially leaving orphans. Document optional manual archive/removal only after the user confirms the path; do not automate it. Test by creating a marker upload, canceling reset once, completing reset, and confirming the marker remains while database seed state is restored.

## Issue 19.7 - Build the Interactive Reset Scripts

Create root `reset-demo-data.cmd` that invokes `scripts/reset-demo-data.ps1`. The PowerShell script loads safe environment values, displays target database URL/schema without password, requires the user to type `RESET` exactly, requires/states that the normal backend must be stopped, sets both backend reset guards and `SERVER_PORT=0`, runs the Maven application/reset command, reports success/failure accurately, and explains how reseeding occurs. A canceled or mistyped confirmation performs no database action.

## Issue 19.8 - Build One-Click Local Startup

Create `start-dev.cmd` wrapping `scripts/start-dev.ps1`. The script locates repository directories, verifies Java/Node/npm and Java 21, creates `.env` from example when absent, imports values, validates database settings, generates a missing Base64 32-byte JWT secret, writes `frontend/.env.local`, runs `npm ci` when dependencies are absent/stale, ensures upload/.tmp directories, starts backend in a separate PowerShell, polls `/api/health` for exactly the displayed maximum 180 seconds, then starts frontend and opens `http://localhost:5173`. It must not kill unknown processes.

## Issue 19.9 - Document Manual Startup and Troubleshooting

Complete README/local run guidance for MySQL schema/grants, environment variables, JWT generation, optional Gmail App Password, manual backend/frontend commands, build commands, ports, storage, seed, reset, and demonstration accounts. Include targeted troubleshooting for database connectivity/grants, invalid JWT secret, CORS, upload permissions/limits, Gmail auth, frontend API URL, seed duplicates, and port inspection. Port guidance must identify an owning process before stopping it. Keep secrets and real personal data out of screenshots/examples.

## Issue 19.10 - Validate a Clean Local Deployment

From a clean `unidoc` schema and absent build output/node modules, follow only the documentation and scripts: configure `.env`, start MySQL, launch the stack, verify health, allow schema creation/seed, log in as all roles, retrieve a seeded file, and run a safe reset/reseed. Test email enabled once with Gmail and disabled/no-op mode. Verify ports 5173/8080/3306, writable storage, correct timeout text, no secret in Git status, and repeatable startup. Create a matching manual MySQL/upload backup checkpoint before final-day changes if data matters.

# Issue 20 - Complete Automated Verification, Full UAT, and Release Readiness

Execute the quality strategy as the final dependency gate. The project is complete only when backend rule/security/storage/report tests pass, frontend lint/build pass, MySQL smoke behavior is verified, all ten manual E2E scenarios succeed, responsive/accessibility/browser checks pass, seed/reset/startup are repeatable, and documentation matches code. Keep automation focused on backend risk and manual frontend UAT; do not delay delivery by introducing Playwright, containers, coverage gates, or CI infrastructure not required by the approved design.

## Issue 20.1 - Enforce Compile, Test, Lint, and Package Gates

Run `backend\mvnw.cmd clean test` and `clean package`; require the expected JAR. Run `npm ci`, `npm run lint`, and `npm run build`; require zero lint errors and a valid `frontend/dist`. Fix warnings that indicate correctness/accessibility defects rather than suppressing rules broadly. Record command, result, date/time, and test count in the final test-result record. No ignored failing core tests or “works only from IDE” state is acceptable.

## Issue 20.2 - Complete Authentication, User, Profile, and Catalogue Tests

Audit the automated suites against `10-testing-strategy.md`: registration normalization/role/password/hash/login/token; active-user checks; managed user creation/status/password/self-deactivation; profile missing/create/update/uniqueness/bounds; catalogue delivery/location/uniqueness/activation. Add missing high-value service/repository/MockMvc cases without expanding technology. Confirm stable errors, request IDs, role matrix, secret absence, and clean H2 isolation. Run a final MySQL smoke for mappings/constraints H2 cannot prove.

## Issue 20.3 - Complete Request Creation and Transition Tests

Implement/finish creation tests for profile/type/date/delivery/support files/number/snapshots/history/notifications and rollback. Use a parameterized matrix for all valid and invalid transitions through review, information cycle, approval, rejection, processing, electronic ready/completion, and physical ready/completion. Assert status-specific fields, version, actor/note, notification recipient/type, terminal states, method mismatch, stale version, and role/ownership. Treat any undocumented successful transition as a Critical defect.

## Issue 20.4 - Complete Storage and Download Security Tests

Finish `@TempDir` validation, staging/move/cleanup/path/header/missing-byte tests; issued uniqueness; owner-scoped student attachment/document; staff verification; admin denial; first/later download metadata; and failure-not-completing behavior. Test traversal-style filenames and stored metadata, signature mismatch, exact size/count limits, and no physical path in errors. Ensure automated tests never modify the demo upload root. Manually attempt unauthenticated and cross-student downloads with copied IDs.

## Issue 20.5 - Complete Repository, Web, and Security Boundary Tests

Verify repository uniqueness, foreign keys as practical, pagination, specifications, counts, and optimistic locking. Verify health/register/login public access and every student/staff/admin/shared route combination, malformed JSON/enums/pages/sorts/multipart, field-error shape, request ID, and absence of stack trace/exception. Confirm owner-scoped failures return 404, wrong route role returns 403, and missing authentication 401. Run clean-database MySQL smoke to catch dialect differences.

## Issue 20.6 - Complete Notification, Email, Dashboard, Report, and CSV Tests

Test recipient isolation, unread/read/idempotency, after-commit listener behavior, no-op sender, plain-text composition, swallowed SMTP failure, and no domain rollback. Test every dashboard definition, report filter/date boundary/paging, shared CSV filters, header/order, comma/quote/newline/Unicode escaping, formula defense, and empty export. Verify ADMIN-only access and no request mutation/file privilege. Compare aggregate results with known deterministic seed counts.

## Issue 20.7 - Execute Manual E2E Scenarios 01 through 05

From reset/seeded state, record results for: student registration/profile prerequisite; full electronic request through second download; repeated-capable additional-information cycle; rejection with reason/terminal state; and physical request through invalid future date and valid collection. Exercise validation and notifications, not only happy paths. Use genuine UI/API actions rather than database edits, and verify email once where the scenario calls for it. Capture concise defects and rerun affected regression checks after fixes.

## Issue 20.8 - Execute Manual E2E Scenarios 06 through 10

Record authorization attempts across two students and all roles; admin account/catalogue management with authVersion effects and snapshot preservation; dashboard/report/CSV accuracy; deliberate SMTP failure with successful in-app/domain state; and cancel/confirm reset with deterministic reseed/upload preservation. Confirm the demo can be completed without manual database repair. Any cross-user access, unguarded reset, or blocked proposal workflow is Critical/High and must be fixed before release.

## Issue 20.9 - Run Responsive, Accessibility, Browser, and Performance Smoke Checks

Repeat the Issue 18 checklist in current Chrome and Edge at all three target widths after final functional fixes. With approximately 500 users, 2,000 requests, and 5,000 notifications/history rows where practical, check ordinary JSON/staff filters under two seconds and dashboard/report under three seconds on the demo laptop; use browser timing/logs, not a new load tool. Confirm repository pagination prevents unbounded normal endpoints and the browser remains responsive. Record deviations and fix indexing/query defects before cosmetic items.

## Issue 20.10 - Synchronize Documentation and Rehearse the Final Local Release

Compare implementation against all 12 documents and update documentation where code was corrected without changing accepted scope/ADRs. Verify endpoint names, DTOs, schema, transitions, roles, file limits, environment variables, commands, screenshots/example data, and demo accounts. Confirm no excluded feature or prohibited dependency slipped in. Run the final reset/reseed/start script, rehearse the recommended student→staff→student→physical→admin demonstration, verify no console errors/secrets, and complete the final deployment/test checklists. Release only with no Critical/High defects and no unresolved contradiction between proposal, requirements, accepted ADRs, and code.
