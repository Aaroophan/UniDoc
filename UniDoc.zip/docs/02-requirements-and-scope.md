# UniDoc Requirements and Scope

**Document purpose:** Convert the approved proposal into testable implementation requirements.  
**Interpretation rule:** The smallest behavior that fully satisfies a proposal requirement is mandatory.  
**Priority model:** MUST, SHOULD, COULD, and OUT.

## 1. Scope authority and interpretation

The approved University Document Request Management System proposal is the authority for project scope. This specification clarifies ambiguous implementation details but does not expand the proposal into a larger product.

Interpretation rules:

1. A requirement explicitly stated in the proposal is **MUST**.
2. A small mechanism required to make a proposal requirement secure or demonstrable is also **MUST**.
3. A quality improvement that can be completed after all required behavior is **SHOULD**.
4. A convenience that is helpful but unnecessary for assessment is **COULD**.
5. A feature that creates substantial effort without supporting the proposal is **OUT**.
6. If time is limited, reduce SHOULD and COULD work before changing any MUST requirement.

## 2. Product boundary

### 2.1 In scope

- responsive browser-based application;
- student self-registration and login;
- administrator-created staff and administrator accounts;
- account activation, deactivation, and password reset by an administrator;
- student profile management;
- document catalogue management;
- request submission and supporting-document upload;
- electronic and physical delivery preference;
- request status tracking and history;
- staff review, additional-information request, approval, rejection, processing, readiness, and completion;
- authorized upload and download of electronic documents;
- physical collection information and completion;
- in-app notifications;
- Gmail SMTP email notifications;
- administrator dashboard;
- filterable request report and CSV export;
- deterministic local demonstration data;
- guarded local database reset;
- local startup scripts; and
- essential automated and manual testing.

### 2.2 Out of scope

- payment collection;
- document fees;
- cloud deployment;
- cloud storage;
- public download links;
- mobile applications;
- microservices;
- message queues;
- WebSockets;
- live chat;
- staff assignment;
- workload balancing;
- multiple approvers;
- approval escalation;
- student cancellation;
- document editing inside UniDoc;
- automatic document generation;
- electronic signatures;
- file versioning;
- OCR;
- antivirus service integration;
- university single sign-on;
- forgotten-password emails;
- PDF report generation;
- advanced analytics;
- data warehouse integration;
- SMS notifications;
- multilingual UI;
- offline operation; and
- external university-system integration.

## 3. Actors

| Actor | Description | Account source |
| --- | --- | --- |
| Student | University student who requests documents | Self-registration |
| Staff | University office employee who processes requests | Created by administrator |
| Administrator | Maintains users, catalogue, monitoring, and reports | Seeded initial account or created by an administrator |
| Gmail SMTP | External channel used to send notification email | Configured locally |
| Local operator | Developer or demonstrator starting/resetting the system | Operating-system access, not an application role |

## 4. Role capability matrix

| Capability | Student | Staff | Administrator |
| --- | :---: | :---: | :---: |
| Register own account | Yes | No | No |
| Sign in and sign out | Yes | Yes | Yes |
| View own account | Yes | Yes | Yes |
| Edit student profile | Own only | No | No |
| Browse active document catalogue | Yes | Yes | Yes |
| Submit document request | Yes | No | No |
| View request | Own only | All | All |
| Download supporting attachment | Own only | Yes | No by default |
| Respond to additional-information request | Own only | No | No |
| Start review | No | Yes | No |
| Request additional information | No | Yes | No |
| Approve or reject | No | Yes | No |
| Start processing | No | Yes | No |
| Upload issued PDF | No | Yes | No |
| Mark physical request ready | No | Yes | No |
| Record physical collection | No | Yes | No |
| Download issued document | Own only | Yes for verification | No by default |
| Read own notifications | Yes | Yes | Yes |
| Manage accounts | No | No | Yes |
| Manage document types | No | No | Yes |
| View dashboard | No | No | Yes |
| Generate and export request report | No | No | Yes |
| Change workflow state | No, except information response and first download completion | Yes | No |

The administrator's ability to monitor does not imply permission to process a request.

## 5. Functional requirements

### 5.1 Authentication and account requirements

#### FR-AUTH-001 - Student registration

**Priority:** MUST  
**Actor:** Unauthenticated student

The system shall allow a student to register with:

- full name;
- email;
- password; and
- password confirmation.

Rules:

- email is unrestricted by domain;
- email is trimmed and compared case-insensitively;
- email must be unique;
- password must be at least 8 characters;
- password must contain at least one uppercase letter, one lowercase letter, one number, and one special character;
- password confirmation must match;
- the created role is always STUDENT;
- the created status is ACTIVE;
- the public request cannot choose STAFF or ADMIN;
- password is stored only as a BCrypt hash.

Acceptance criteria:

- valid input creates a student and returns no password data;
- duplicate email returns 409;
- invalid fields return 400 with field errors;
- changing a submitted role-like property cannot create a privileged account.

#### FR-AUTH-002 - Login

**Priority:** MUST  
**Actors:** Student, staff, administrator

The system shall authenticate an active account using email and password and return:

- a Bearer JWT;
- token expiry information; and
- the user's public account details.

Invalid credentials return one generic message so the API does not confirm whether an email exists.

#### FR-AUTH-003 - Current account

**Priority:** MUST

An authenticated user shall be able to retrieve the current account. This is used when the frontend reloads to verify that the stored session is still valid.

#### FR-AUTH-004 - Sign-out

**Priority:** MUST

The frontend shall clear the session from session storage and return the user to the login page. Because the API uses stateless short-lived JWTs, no refresh-token or server blacklist is required.

#### FR-AUTH-005 - Inactive accounts

**Priority:** MUST

An inactive account shall:

- be unable to log in; and
- be rejected on authenticated requests even if an older JWT has not expired.

#### FR-AUTH-006 - Session revocation after account changes

**Priority:** MUST supporting security control

Password reset and account status change shall increment the account authentication version. Tokens with an older version are rejected.

#### FR-AUTH-007 - Administrator account creation

**Priority:** MUST

An administrator shall create STAFF or ADMIN accounts with:

- full name;
- email;
- role; and
- initial password.

No forced first-login password-change flow is required.

#### FR-AUTH-008 - Account administration

**Priority:** MUST

An administrator shall:

- list accounts with pagination;
- filter by free text, role, and status;
- activate an account;
- deactivate an account; and
- set a new password.

Hard deletion is not required.

### 5.2 Student profile requirements

#### FR-PRO-001 - View profile

**Priority:** MUST

The student shall see:

- registration number;
- full name;
- email;
- phone;
- faculty;
- department;
- degree programme; and
- academic year.

Full name and email originate from the user account; the remaining academic fields originate from the student profile.

#### FR-PRO-002 - Create or update profile

**Priority:** MUST

A student shall create or update the profile with:

- registration number;
- full name;
- phone;
- faculty;
- department;
- degree programme; and
- academic year.

Rules:

- registration number is required and unique;
- full name is required;
- phone is optional but validated when supplied;
- faculty, department, and degree programme are required;
- academic year is an integer from 1 to 8;
- email is shown but not changed through this form;
- a student can update only their own profile.

#### FR-PRO-003 - Profile prerequisite

**Priority:** MUST

A student shall complete the required profile fields before submitting a document request. The UI directs an incomplete profile to the profile page, and the backend independently rejects request creation.

### 5.3 Document catalogue requirements

#### FR-CAT-001 - Active catalogue

**Priority:** MUST

Authenticated users shall view active document types containing:

- code;
- name;
- description;
- requirements or instructions;
- whether supporting documents are required;
- available delivery methods;
- collection location and instructions where physical delivery is supported.

#### FR-CAT-002 - Initial document types

**Priority:** MUST

The deterministic seed shall include:

1. Student Confirmation Letter
2. Academic Transcript
3. Recommendation Letter
4. Certificate
5. Student Status Letter

Each initially supports both electronic and physical delivery.

#### FR-CAT-003 - Administrator catalogue management

**Priority:** MUST

An administrator shall:

- list all document types, including inactive entries;
- create a document type;
- edit a document type;
- activate it; and
- deactivate it.

Hard deletion is excluded so historical requests remain understandable.

#### FR-CAT-004 - Catalogue validation

**Priority:** MUST

Rules:

- code and name are required and unique;
- at least one delivery method is enabled;
- collection location is required when physical delivery is enabled;
- supporting-document instructions should explain the requirement when supporting files are mandatory;
- inactive types cannot be selected for a new request;
- existing requests remain available if their type is later deactivated.

### 5.4 Request-submission requirements

#### FR-REQ-001 - Create request

**Priority:** MUST  
**Actor:** Student

The student shall create a request with:

- document type;
- purpose;
- required date;
- delivery method; and
- supporting files when applicable.

Student identity details are loaded from the authenticated account and profile, not typed into the request.

#### FR-REQ-002 - Required date

**Priority:** MUST

The required date:

- is mandatory;
- uses the student's local calendar date;
- cannot be earlier than the current date when submitted; and
- is not treated as a guaranteed completion date.

#### FR-REQ-003 - Delivery preference

**Priority:** MUST

The selected method must be supported by the selected document type:

- ELECTRONIC; or
- PHYSICAL.

#### FR-REQ-004 - Supporting documents

**Priority:** MUST

The initial submission accepts zero to three files.

Each file:

- must be PDF, JPEG, or PNG;
- must not exceed 5 MiB;
- must have a server-validated content type;
- receives a server-generated storage name; and
- is accessible only through an authorized endpoint.

At least one file is required if the document type marks supporting documents as required.

#### FR-REQ-005 - Request creation result

**Priority:** MUST

A successful submission shall:

- create a unique human-readable request number;
- create the request in SUBMITTED;
- preserve a snapshot of relevant catalogue details;
- record the initial status history;
- create a student confirmation notification;
- notify active staff; and
- attempt email delivery after the database change succeeds.

#### FR-REQ-006 - No student editing or cancellation

**Priority:** MUST

After submission, a student cannot edit the request fields and cannot cancel the request. The only student mutation is responding while the status is ADDITIONAL_INFORMATION_REQUIRED.

### 5.5 Request tracking requirements

#### FR-TRK-001 - Student request list

**Priority:** MUST

A student shall view a paginated list of only their own requests with:

- request number;
- document type;
- delivery method;
- current status;
- required date;
- submitted date; and
- last updated date.

The list may be filtered by status and delivery method.

#### FR-TRK-002 - Student request detail

**Priority:** MUST

The detail view shall show:

- request identity;
- document information;
- purpose;
- required date;
- delivery method;
- current status;
- submitted supporting files;
- latest additional-information request when applicable;
- rejection reason when rejected;
- electronic download action when available;
- physical collection details when available; and
- ordered status history.

#### FR-TRK-003 - Append-only status history

**Priority:** MUST

Every status change shall record:

- previous status;
- new status;
- actor;
- optional explanatory note;
- date and time.

History entries are not edited through the application.

### 5.6 Staff-review requirements

#### FR-STF-001 - Staff work list

**Priority:** MUST

Every active staff member shall see all requests. The list supports pagination and filters for:

- free-text student/request search;
- status;
- document type;
- delivery method;
- submitted date range; and
- required date.

There is no staff assignment.

#### FR-STF-002 - Staff detail

**Priority:** MUST

Staff shall see:

- student account and profile details;
- request data;
- files;
- status history; and
- only actions valid for the current status and delivery method.

#### FR-STF-003 - Start review

**Priority:** MUST

A staff member shall move SUBMITTED to UNDER_REVIEW.

#### FR-STF-004 - Request additional information

**Priority:** MUST

From UNDER_REVIEW, staff shall move the request to ADDITIONAL_INFORMATION_REQUIRED. A clear message is mandatory.

The action shall notify the student in-app and by email.

#### FR-STF-005 - Student information response

**Priority:** MUST

While ADDITIONAL_INFORMATION_REQUIRED, the owning student shall submit:

- a written response; and
- optionally up to three PDF, JPEG, or PNG files, each at most 5 MiB.

Success returns the request to SUBMITTED, records the response in history, sends a confirmation to the student, and notifies active staff.

#### FR-STF-006 - Approval

**Priority:** MUST

From UNDER_REVIEW, staff shall approve the request, changing it to APPROVED and notifying the student.

#### FR-STF-007 - Rejection

**Priority:** MUST

From UNDER_REVIEW, staff shall reject the request. A rejection reason is mandatory. REJECTED is terminal.

#### FR-STF-008 - Start processing

**Priority:** MUST

From APPROVED, staff shall start processing, changing the request to PROCESSING and notifying the student.

#### FR-STF-009 - Transition enforcement

**Priority:** MUST

The backend shall reject:

- actions from the wrong role;
- actions on a request that does not exist;
- actions from an invalid current status;
- electronic actions on physical requests;
- physical actions on electronic requests; and
- concurrent updates based on stale entity versions.

### 5.7 Electronic delivery requirements

#### FR-ELC-001 - Upload issued document

**Priority:** MUST

For an ELECTRONIC request in PROCESSING, staff shall upload one issued PDF.

Rules:

- PDF only;
- maximum 10 MiB;
- server-generated storage name;
- replacement/versioning is not supported;
- existing issued document prevents a second upload;
- successful upload changes PROCESSING to READY;
- student is notified in-app and by email.

#### FR-ELC-002 - Secure download

**Priority:** MUST

The owning student shall download the issued PDF through an authenticated endpoint.

The endpoint shall:

- confirm request ownership;
- confirm electronic delivery;
- confirm the request is READY or COMPLETED;
- resolve only the server-stored path;
- use an attachment Content-Disposition header;
- prevent path traversal; and
- return 404 rather than exposing another student's file.

#### FR-ELC-003 - Automatic completion

**Priority:** MUST

On the first successful server-side issued-document response:

- READY changes to COMPLETED;
- completion time is recorded;
- first-download time is recorded;
- download count is incremented;
- history is appended; and
- a completion notification is created.

Later downloads:

- remain allowed;
- increment download metadata; and
- do not create another completion transition.

### 5.8 Physical collection requirements

#### FR-PHY-001 - Mark ready

**Priority:** MUST

For a PHYSICAL request in PROCESSING, staff shall mark it READY.

The student sees:

- collection location;
- collection instructions; and
- ready date.

The student is notified in-app and by email.

#### FR-PHY-002 - Record collection

**Priority:** MUST

For a PHYSICAL request in READY, staff shall record:

- collection date, required; and
- collection note, optional.

The collection date cannot be in the future. Success changes READY to COMPLETED and notifies the student.

### 5.9 Notification requirements

#### FR-NOT-001 - In-app notifications

**Priority:** MUST

The system shall store notifications containing:

- recipient;
- type;
- title;
- message;
- action path;
- read state;
- created time; and
- read time when applicable.

#### FR-NOT-002 - Notification list

**Priority:** MUST

An authenticated user shall:

- list only their notifications;
- filter by read state;
- view unread count;
- mark one notification read; and
- mark all notifications read.

#### FR-NOT-003 - Email

**Priority:** MUST

All agreed workflow notification events shall also be attempted through Gmail SMTP.

Email failure:

- is logged as a warning;
- does not remove the in-app notification;
- does not roll back the request state; and
- is not automatically retried in the MVP.

### 5.10 Administration and reporting requirements

#### FR-ADM-001 - Monitoring

**Priority:** MUST

Administrators shall view request lists and request details for monitoring. Monitoring endpoints shall not expose workflow mutation actions.

#### FR-ADM-002 - Dashboard

**Priority:** MUST

The dashboard shall show:

- total requests;
- submitted/pending requests;
- approved requests;
- rejected requests;
- ready requests;
- completed requests;
- electronic versus physical totals;
- requests by document type; and
- recent requests.

For dashboard definitions:

- **Pending** means SUBMITTED, UNDER_REVIEW, or ADDITIONAL_INFORMATION_REQUIRED.
- **Approved** counts the exact APPROVED status.
- **Processing** may be shown as a separate supporting count but is not required as a primary card.
- **Ready**, **Rejected**, and **Completed** count their exact statuses.

#### FR-ADM-003 - Request report

**Priority:** MUST

The report shall support:

- submitted date from and to;
- status;
- document type;
- delivery method;
- paginated on-screen results; and
- CSV export of all records matching the current filters.

#### FR-ADM-004 - CSV format

**Priority:** MUST

CSV shall contain:

- request number;
- student registration number;
- student name;
- student email;
- document type;
- purpose;
- delivery method;
- required date;
- status;
- submitted time;
- updated time;
- completed time where present.

CSV shall:

- include a header row;
- use UTF-8;
- correctly quote commas, quotes, and new lines;
- use a meaningful filename containing the export date; and
- prevent formula injection by prefixing cells that begin with =, +, -, or @.

## 6. Workflow transition contract

| Current status | Action | Actor | Required input | New status | Main side effects |
| --- | --- | --- | --- | --- | --- |
| None | Submit | Student | Request data; required attachments | SUBMITTED | Number, history, student/staff notifications |
| SUBMITTED | Start review | Staff | None | UNDER_REVIEW | History |
| UNDER_REVIEW | Ask for information | Staff | Message | ADDITIONAL_INFORMATION_REQUIRED | History, student notification |
| ADDITIONAL_INFORMATION_REQUIRED | Respond | Owning student | Response; optional files | SUBMITTED | History, student/staff notifications |
| UNDER_REVIEW | Approve | Staff | Optional internal note excluded | APPROVED | History, student notification |
| UNDER_REVIEW | Reject | Staff | Reason | REJECTED | History, student notification |
| APPROVED | Start processing | Staff | None | PROCESSING | History, student notification |
| PROCESSING | Upload PDF | Staff | Issued PDF; electronic only | READY | File metadata, history, student notification |
| PROCESSING | Mark ready | Staff | Physical only | READY | Ready time, history, student notification |
| READY | Download issued PDF | Owning student | Electronic only | COMPLETED on first response | Download metadata, history, notification |
| READY | Record collection | Staff | Collection date; physical only | COMPLETED | Collection fields, history, notification |

No other transitions are valid.

## 7. Non-functional requirements

### NFR-SEC-001 - Authorization

Only authenticated and authorized users may access student information or documents. Record ownership is checked in the service layer.

### NFR-SEC-002 - Password handling

Passwords are BCrypt-hashed with cost 12. Plain-text passwords are never logged, returned, or stored.

### NFR-SEC-003 - Session handling

JWT lifetime defaults to one hour. Tokens are stored in browser session storage rather than persistent local storage.

### NFR-SEC-004 - Upload safety

The server validates extension, declared content type, detected signature for supported formats, count, and size. Client-supplied file names never determine the storage path.

### NFR-SEC-005 - Secret handling

Database password, Gmail App Password, and JWT secret exist only in ignored local environment configuration.

### NFR-USE-001 - Simplicity

A first-time user should be able to identify the primary action on every page without training.

### NFR-USE-002 - Feedback

Every submission shows progress and a clear success or error result. Duplicate submissions are prevented while a request is running.

### NFR-USE-003 - Accessibility

- visible labels for form controls;
- keyboard-operable navigation and dialogs;
- visible focus indicators;
- sufficient colour contrast;
- status communicated by text, not colour alone;
- semantic headings and table headers;
- meaningful icon labels;
- reduced-motion support.

### NFR-USE-004 - Responsiveness

Core workflows shall remain usable at approximately:

- 360 px mobile width;
- 768 px tablet width; and
- 1366 px desktop width.

### NFR-REL-001 - Transaction consistency

Each workflow transition, its status history, and its in-app notification are committed atomically in one database transaction where practical.

### NFR-REL-002 - File consistency

A database file record is not committed when the corresponding filesystem write fails. A failed database operation triggers best-effort cleanup of the staged file.

### NFR-REL-003 - Optimistic concurrency

Document requests use an entity version. Competing staff actions cannot silently overwrite one another.

### NFR-PER-001 - Normal response

On the demonstration laptop and local database:

- ordinary JSON endpoints should normally respond within 2 seconds;
- dashboard/report queries should normally respond within 3 seconds for the demo dataset;
- file transfer time is allowed to depend on file size and local hardware.

These are demonstration targets, not formal service-level agreements.

### NFR-PER-002 - Pagination

Growing lists use server-side pagination:

- default page size 20;
- maximum page size 100;
- page number is zero-based.

### NFR-AVL-001 - Availability

The application shall be available while the local API, frontend, and MySQL are running. High availability and automatic failover are not required.

### NFR-MNT-001 - Maintainability

- feature-based backend packages;
- typed frontend API models;
- thin controllers;
- service-owned rules;
- repository-level pagination;
- centralized error mapping;
- deterministic demo data; and
- documentation updated with behavior.

### NFR-OBS-001 - Logging

The API shall log startup, request correlation, workflow changes, warnings, and failures without logging credentials, tokens, or file contents.

## 8. Validation catalogue

| Field | Rule |
| --- | --- |
| Full name | Required; 2-150 characters |
| Email | Required; valid format; maximum 254; unique case-insensitively |
| Password | 8-72 characters; upper, lower, number, special |
| Registration number | Required; 2-50; letters, numbers, slash, hyphen allowed; unique |
| Phone | Optional; 7-30; numbers, spaces, plus, hyphen, parentheses |
| Faculty | Required; 2-100 |
| Department | Required; 2-100 |
| Degree programme | Required; 2-150 |
| Academic year | Required; integer 1-8 |
| Document type code | Required; 2-50; uppercase letters, numbers, underscore, hyphen |
| Document type name | Required; 2-150; unique |
| Description | Required; 10-2000 |
| Requirements | Required; 3-4000 |
| Collection location | Required for physical; maximum 255 |
| Collection instructions | Optional; maximum 2000 |
| Purpose | Required; 5-1000 |
| Required date | Today or future |
| Additional-information message | Required; 5-2000 |
| Student response | Required; 2-2000 |
| Rejection reason | Required; 5-2000 |
| Collection note | Optional; maximum 1000 |
| Initial/additional file | 0-3 per action; PDF/JPEG/PNG; 5 MiB each |
| Issued file | Exactly one; PDF; 10 MiB |

Backend validation is authoritative. Frontend validation should mirror it for usability.

## 9. Page inventory

### 9.1 Public

| Route | Page |
| --- | --- |
| / | Landing or redirect page |
| /login | Login |
| /register | Student registration |

### 9.2 Shared authenticated

| Route | Page |
| --- | --- |
| /dashboard | Role-aware landing page |
| /catalogue | Active document catalogue |
| /notifications | Current user's notifications |
| /account | Account summary and sign-out |

### 9.3 Student

| Route | Page |
| --- | --- |
| /profile | Student profile |
| /requests | My requests |
| /requests/new | New request |
| /requests/:requestId | Request detail, response, delivery |

### 9.4 Staff

| Route | Page |
| --- | --- |
| /staff/requests | Staff request work list |
| /staff/requests/:requestId | Review and processing detail |

### 9.5 Administrator

| Route | Page |
| --- | --- |
| /admin/dashboard | Statistics and recent requests |
| /admin/users | Account management |
| /admin/document-types | Catalogue management |
| /admin/requests | Monitoring list |
| /admin/requests/:requestId | Read-only monitoring detail |
| /admin/reports | Filtered report and CSV export |

## 10. UX acceptance rules

### 10.1 Navigation

- navigation items depend on role;
- active route is visibly indicated;
- mobile navigation is keyboard accessible;
- administrator does not see student profile or staff processing navigation;
- staff does not see account-management actions;
- student does not see staff or admin pages.

### 10.2 Forms

- labels remain visible;
- required fields are marked;
- help text explains file rules and delivery differences;
- field errors appear near fields;
- server errors appear in a summary banner;
- submitting state disables the submit control;
- destructive or terminal actions require confirmation;
- rejection and information-request messages are entered before confirmation.

### 10.3 Status display

- status uses readable text;
- colour is secondary;
- a concise explanation may appear on detail pages;
- only valid actions are shown;
- history remains visible even when the request is terminal.

### 10.4 Tables and lists

- empty lists show a clear explanation and appropriate next action;
- loading does not show an empty message;
- mobile layouts preserve critical fields;
- pagination remains visible when multiple pages exist;
- filters can be cleared in one action.

## 11. Reporting definitions

| Metric | Definition |
| --- | --- |
| Total requests | Count of all document_requests rows |
| Pending | Status in SUBMITTED, UNDER_REVIEW, ADDITIONAL_INFORMATION_REQUIRED |
| Approved | Exact APPROVED |
| Rejected | Exact REJECTED |
| Ready | Exact READY |
| Completed | Exact COMPLETED |
| Electronic | delivery_method = ELECTRONIC |
| Physical | delivery_method = PHYSICAL |
| Requests by type | Group by document_type_id/name snapshot |
| Recent requests | Most recent by created_at, limited to 10 |

Dates in report filters apply to request created_at. Date-from is inclusive at 00:00; date-to is inclusive through the end of the selected date.

## 12. Traceability matrix

| Proposal area | Requirement IDs | Main module | Main verification |
| --- | --- | --- | --- |
| Registration and login | FR-AUTH-001 to 006 | auth, user | Auth tests and demo login |
| Student profile | FR-PRO-001 to 003 | profile | Ownership and validation tests |
| Document catalogue | FR-CAT-001 to 004 | document | Admin CRUD and active catalogue |
| Online requests | FR-REQ-001 to 006 | request | Submission scenarios |
| Supporting uploads | FR-REQ-004, FR-STF-005 | file, request | Type/size/ownership tests |
| Request tracking | FR-TRK-001 to 003 | request | Student list/detail/history |
| Approval and rejection | FR-STF-003 to 009 | request | Transition matrix tests |
| Electronic delivery | FR-ELC-001 to 003 | file, request | Upload/download/completion |
| Physical collection | FR-PHY-001 to 002 | request | Ready and collection scenarios |
| Notifications/history | FR-NOT-001 to 003, FR-TRK-003 | notification, email, request | Notification and SMTP-failure tests |
| Admin dashboard | FR-ADM-001 to 002 | report | Query and visible totals |
| Report generation | FR-ADM-003 to 004 | report | Filter and CSV checks |
| Security | NFR-SEC series | auth, config, file | Security tests |
| Usability | NFR-USE series | frontend | Responsive/manual checklist |
| Reliability | NFR-REL series | request, file | Transaction/concurrency tests |

## 13. Definition of done by feature

A feature is done only when:

1. backend rule is implemented;
2. endpoint is authorized;
3. request and response DTOs are defined;
4. validation and error behavior are implemented;
5. frontend loading, empty, data, and error states are handled as applicable;
6. the feature is responsive;
7. important business rules have automated tests;
8. the end-to-end path has been manually verified;
9. seed data supports demonstration where useful; and
10. related documentation matches the code.

## 14. Change-control rule

During the 10-day implementation:

- a new proposal requirement may change the plan;
- a defect that prevents a required path must be fixed;
- a security defect affecting identity, authorization, or file access must be fixed;
- visual polish may proceed only after required paths work;
- a suggested feature outside the proposal is recorded but not implemented;
- no architectural rewrite is started unless the current design cannot meet a MUST requirement.
