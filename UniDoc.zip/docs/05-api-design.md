# UniDoc API Design

**Style:** JSON REST API with protected multipart and file responses  
**Base URL:** http://localhost:8080/api  
**Authentication:** Authorization: Bearer JWT  
**Versioning:** No URL version segment for the course-project MVP  
**Date/time:** ISO 8601; timestamps in UTC

## 1. API design goals

The API must be:

- small enough to implement quickly;
- explicit about role and workflow boundaries;
- consistent across features;
- safe for student data and documents;
- easy to call from the React frontend and Postman;
- predictable in validation and error behavior;
- paginated for growing collections; and
- documented closely enough that endpoint behavior is not guessed during implementation.

## 2. General conventions

### 2.1 URLs

- Use nouns for resources.
- Use plural resource names.
- Use role-specific route families where they make permissions obvious.
- Use action sub-resources for workflow transitions because transitions are business commands, not arbitrary field patches.
- Do not expose storage paths.

Examples:

~~~text
GET  /api/student/requests
POST /api/staff/requests/42/approve
POST /api/staff/requests/42/request-information
GET  /api/student/requests/42/issued-document
~~~

### 2.2 HTTP methods

| Method | Use |
| --- | --- |
| GET | Read without changing business state, except the agreed first-download completion behavior |
| POST | Create resource or invoke workflow action |
| PUT | Replace editable resource representation |
| PATCH | Small explicit state field such as active/inactive |
| DELETE | Not used in the normal UniDoc API |

### 2.3 Content types

- JSON input: application/json
- JSON output: application/json
- Multipart input: multipart/form-data
- Issued PDF output: application/pdf
- Supporting image output: image/jpeg or image/png
- CSV output: text/csv; charset=UTF-8

### 2.4 Authentication

Protected calls include:

~~~text
Authorization: Bearer eyJ...
~~~

Public endpoints:

- GET /api/health
- POST /api/auth/register
- POST /api/auth/login

Every other endpoint is authenticated.

### 2.5 Identifier types

- Path IDs are positive 64-bit integers.
- Public request detail contains both numeric id and requestNumber.
- Frontend routes may use the numeric request ID.
- Guessable IDs do not reduce authorization requirements.

### 2.6 JSON naming

JSON uses camelCase.

~~~json
{
  "requestNumber": "UDR-000123",
  "deliveryMethod": "ELECTRONIC",
  "requiredDate": "2026-10-17",
  "createdAt": "2026-10-09T08:30:00Z"
}
~~~

### 2.7 Null and omission

- Required response fields are always present.
- Optional fields may be null.
- Empty collections return [].
- The API does not use an additional generic success envelope.
- Errors use one error envelope.

### 2.8 Idempotency

Naturally idempotent actions:

- mark notification read;
- mark all notifications read;
- GET operations;
- PUT updates with the same body.

Workflow actions are not generally repeatable. Repeating an action after the status changed returns 409 rather than silently pretending to succeed.

## 3. Standard response models

### 3.1 PageResponse

~~~json
{
  "items": [],
  "page": 0,
  "size": 20,
  "totalItems": 0,
  "totalPages": 0,
  "first": true,
  "last": true
}
~~~

Rules:

- page is zero-based;
- default page is 0;
- default size is 20;
- maximum size is 100;
- invalid values return 400 INVALID_PARAMETER;
- items are never null.

### 3.2 ApiErrorResponse

~~~json
{
  "timestamp": "2026-10-09T08:30:00Z",
  "status": 400,
  "error": "Bad Request",
  "code": "VALIDATION_ERROR",
  "message": "Request validation failed.",
  "path": "/api/auth/register",
  "requestId": "4ae4f241-9a7a-4dfd-a884-d6f813b69474",
  "fieldErrors": {
    "email": "must be a valid email address"
  }
}
~~~

Clients use code for behavior and message for display. Raw Java exception messages are not returned for unexpected failures.

### 3.3 UserSummary

~~~json
{
  "id": 3,
  "email": "student.demo@unidoc.test",
  "fullName": "Demo Student",
  "role": "STUDENT",
  "status": "ACTIVE",
  "createdAt": "2026-10-09T08:00:00Z"
}
~~~

### 3.4 RequestSummary

~~~json
{
  "id": 123,
  "requestNumber": "UDR-000123",
  "studentName": "Demo Student",
  "registrationNumber": "PS3000",
  "documentTypeId": 2,
  "documentTypeName": "Academic Transcript",
  "deliveryMethod": "ELECTRONIC",
  "status": "UNDER_REVIEW",
  "requiredDate": "2026-10-17",
  "createdAt": "2026-10-09T08:30:00Z",
  "updatedAt": "2026-10-09T09:00:00Z",
  "version": 1
}
~~~

Student lists may omit studentName and registrationNumber because the values are already known. A shared DTO may retain them if that simplifies implementation without exposing other users.

## 4. Health endpoint

### GET /api/health

**Access:** Public  
**Purpose:** Startup script readiness check

Response 200:

~~~json
{
  "status": "ok"
}
~~~

The endpoint may verify application availability without exposing database credentials or detailed environment data. A simple database connectivity check is acceptable but not required for the first implementation.

## 5. Authentication endpoints

### POST /api/auth/register

**Access:** Public  
**Requirement:** FR-AUTH-001

Request:

~~~json
{
  "fullName": "Demo Student",
  "email": "student.demo@unidoc.test",
  "password": "Demo@123",
  "confirmPassword": "Demo@123"
}
~~~

Response 201:

~~~json
{
  "id": 3,
  "email": "student.demo@unidoc.test",
  "fullName": "Demo Student",
  "role": "STUDENT",
  "status": "ACTIVE",
  "createdAt": "2026-10-09T08:00:00Z"
}
~~~

Errors:

- 400 VALIDATION_ERROR
- 409 EMAIL_ALREADY_EXISTS

Registration does not automatically authenticate. The student signs in next, keeping the flow explicit.

### POST /api/auth/login

**Access:** Public  
**Requirement:** FR-AUTH-002

Request:

~~~json
{
  "email": "student.demo@unidoc.test",
  "password": "Demo@123"
}
~~~

Response 200:

~~~json
{
  "token": "eyJ...",
  "tokenType": "Bearer",
  "expiresAt": "2026-10-09T09:30:00Z",
  "user": {
    "id": 3,
    "email": "student.demo@unidoc.test",
    "fullName": "Demo Student",
    "role": "STUDENT",
    "status": "ACTIVE",
    "createdAt": "2026-10-09T08:00:00Z"
  }
}
~~~

Errors:

- 401 AUTH_INVALID_CREDENTIALS
- 403 ACCOUNT_INACTIVE

### GET /api/auth/me

**Access:** Any authenticated role  
**Requirement:** FR-AUTH-003

Response 200: UserSummary

Errors:

- 401 AUTHENTICATION_REQUIRED
- 401 SESSION_REVOKED
- 403 ACCOUNT_INACTIVE

There is no required backend logout endpoint. Frontend sign-out deletes the session.

## 6. Student profile endpoints

### GET /api/student/profile

**Access:** STUDENT  
**Requirement:** FR-PRO-001

Response 200:

~~~json
{
  "userId": 3,
  "email": "student.demo@unidoc.test",
  "fullName": "Demo Student",
  "registrationNumber": "PS3000",
  "phone": "+94 77 000 0000",
  "faculty": "Faculty of Science",
  "department": "Department of Computing",
  "degreeProgramme": "BSc in Computer Science",
  "academicYear": 3,
  "complete": true,
  "updatedAt": "2026-10-09T08:10:00Z"
}
~~~

If no profile exists, return 200 with the account fields, null academic fields, and complete false. This is easier for the frontend than using 404 for a normal first-login state.

### PUT /api/student/profile

**Access:** STUDENT  
**Requirement:** FR-PRO-002

Request:

~~~json
{
  "fullName": "Demo Student",
  "registrationNumber": "PS3000",
  "phone": "+94 77 000 0000",
  "faculty": "Faculty of Science",
  "department": "Department of Computing",
  "degreeProgramme": "BSc in Computer Science",
  "academicYear": 3
}
~~~

Response 200: StudentProfileResponse

Errors:

- 400 VALIDATION_ERROR
- 409 REGISTRATION_NUMBER_ALREADY_EXISTS

The service updates users.full_name and the profile in one transaction.

## 7. Catalogue endpoints

### GET /api/document-types

**Access:** Any authenticated role  
**Requirement:** FR-CAT-001

Returns all active types, ordered by name.

Response 200:

~~~json
[
  {
    "id": 2,
    "code": "ACADEMIC_TRANSCRIPT",
    "name": "Academic Transcript",
    "description": "Official record of academic results.",
    "requirements": "Attach supporting evidence when requested.",
    "supportingDocumentsRequired": false,
    "availableDeliveryMethods": [
      "ELECTRONIC",
      "PHYSICAL"
    ],
    "collectionLocation": "University Administration Office",
    "collectionInstructions": "Bring student identification."
  }
]
~~~

### GET /api/document-types/{documentTypeId}

**Access:** Any authenticated role  
**Purpose:** Catalogue detail / request form

Only active types are returned on this public authenticated route.

Errors:

- 404 DOCUMENT_TYPE_NOT_FOUND

## 8. Student request endpoints

### POST /api/student/requests

**Access:** STUDENT  
**Requirements:** FR-REQ-001 to FR-REQ-005  
**Content-Type:** multipart/form-data

Multipart parts:

| Part | Type | Required | Meaning |
| --- | --- | :---: | --- |
| request | application/json | Yes | Request fields |
| files | file array | Conditional | Zero to three supporting files |

Request JSON part:

~~~json
{
  "documentTypeId": 2,
  "purpose": "Required for a scholarship application.",
  "requiredDate": "2026-10-17",
  "deliveryMethod": "ELECTRONIC"
}
~~~

Example browser construction:

~~~typescript
const form = new FormData();
form.append(
  "request",
  new Blob([JSON.stringify(payload)], { type: "application/json" }),
);
files.forEach((file) => form.append("files", file));
~~~

Response 201: RequestDetailResponse

Errors:

- 400 VALIDATION_ERROR
- 400 PROFILE_INCOMPLETE
- 400 INVALID_DELIVERY_METHOD
- 400 SUPPORTING_DOCUMENT_REQUIRED
- 400 FILE_COUNT_EXCEEDED
- 400 FILE_TOO_LARGE
- 400 UNSUPPORTED_FILE_TYPE
- 404 DOCUMENT_TYPE_NOT_FOUND
- 409 DOCUMENT_TYPE_INACTIVE
- 500 FILE_STORAGE_ERROR

### GET /api/student/requests

**Access:** STUDENT  
**Requirement:** FR-TRK-001

Query:

| Parameter | Default | Allowed |
| --- | --- | --- |
| status | none | RequestStatus |
| deliveryMethod | none | ELECTRONIC, PHYSICAL |
| sort | createdAt | createdAt, updatedAt, requiredDate, status, requestNumber |
| direction | desc | asc, desc |
| page | 0 | >= 0 |
| size | 20 | 1-100 |

Response 200: PageResponse<RequestSummary>

Repository query must include student_user_id from the JWT subject.

### GET /api/student/requests/{requestId}

**Access:** STUDENT owner  
**Requirement:** FR-TRK-002

Response 200: RequestDetailResponse

Another student's request returns 404 REQUEST_NOT_FOUND rather than revealing its existence.

### POST /api/student/requests/{requestId}/information-response

**Access:** STUDENT owner  
**Requirement:** FR-STF-005  
**Content-Type:** multipart/form-data

Parts:

- response: application/json
- files: optional, zero to three

Response part:

~~~json
{
  "message": "I have attached the requested identity copy."
}
~~~

Precondition:

- current status is ADDITIONAL_INFORMATION_REQUIRED.

Response 200: updated RequestDetailResponse

Errors:

- 404 REQUEST_NOT_FOUND
- 409 INVALID_REQUEST_TRANSITION
- file-validation errors

### GET /api/student/requests/{requestId}/attachments/{attachmentId}

**Access:** STUDENT owner  
**Purpose:** Download own supporting attachment

Response:

- file content;
- Content-Disposition attachment with sanitized original name;
- X-Content-Type-Options: nosniff.

### GET /api/student/requests/{requestId}/issued-document

**Access:** STUDENT owner  
**Requirements:** FR-ELC-002, FR-ELC-003

Preconditions:

- delivery method ELECTRONIC;
- status READY or COMPLETED;
- issued document exists.

Response 200:

- application/pdf;
- Content-Disposition attachment;
- private no-store cache control.

On first successful server-side file load/response preparation while READY, the service records COMPLETED in the same operation.

Errors:

- 404 REQUEST_NOT_FOUND
- 404 ISSUED_DOCUMENT_NOT_FOUND
- 409 DOCUMENT_NOT_READY

## 9. Staff request endpoints

### GET /api/staff/requests

**Access:** STAFF  
**Requirements:** FR-STF-001

Query:

| Parameter | Meaning |
| --- | --- |
| q | Request number, student name, email, or registration number |
| status | Exact request status |
| documentTypeId | Exact catalogue ID |
| deliveryMethod | ELECTRONIC or PHYSICAL |
| submittedFrom | Inclusive date |
| submittedTo | Inclusive date |
| requiredDate | Exact requested date |
| sort | createdAt, updatedAt, requiredDate, status, requestNumber |
| direction | asc or desc |
| page | Zero-based page |
| size | 1-100 |

Default sort: createdAt desc.

### GET /api/staff/requests/{requestId}

**Access:** STAFF  
**Requirement:** FR-STF-002

Response includes:

- student summary;
- student profile;
- request;
- attachments;
- issued-document metadata if present;
- status history;
- availableActions computed by the backend.

Example:

~~~json
{
  "id": 123,
  "requestNumber": "UDR-000123",
  "student": {
    "id": 3,
    "fullName": "Demo Student",
    "email": "student.demo@unidoc.test",
    "registrationNumber": "PS3000",
    "phone": "+94 77 000 0000",
    "faculty": "Faculty of Science",
    "department": "Department of Computing",
    "degreeProgramme": "BSc in Computer Science",
    "academicYear": 3
  },
  "documentTypeId": 2,
  "documentTypeName": "Academic Transcript",
  "purpose": "Required for a scholarship application.",
  "requiredDate": "2026-10-17",
  "deliveryMethod": "ELECTRONIC",
  "status": "UNDER_REVIEW",
  "additionalInformationMessage": null,
  "rejectionReason": null,
  "collectionLocation": null,
  "collectionInstructions": null,
  "attachments": [],
  "issuedDocument": null,
  "history": [],
  "availableActions": [
    "REQUEST_INFORMATION",
    "APPROVE",
    "REJECT"
  ],
  "version": 1,
  "createdAt": "2026-10-09T08:30:00Z",
  "updatedAt": "2026-10-09T09:00:00Z"
}
~~~

availableActions is a convenience. The backend action endpoint remains authoritative.

### POST /api/staff/requests/{requestId}/start-review

**Transition:** SUBMITTED → UNDER_REVIEW

Request:

~~~json
{
  "expectedVersion": 0
}
~~~

Response 200: RequestDetailResponse

### POST /api/staff/requests/{requestId}/request-information

**Transition:** UNDER_REVIEW → ADDITIONAL_INFORMATION_REQUIRED

Request:

~~~json
{
  "message": "Please upload a clear copy of your student identity card.",
  "expectedVersion": 1
}
~~~

### POST /api/staff/requests/{requestId}/approve

**Transition:** UNDER_REVIEW → APPROVED

Request:

~~~json
{
  "expectedVersion": 1
}
~~~

### POST /api/staff/requests/{requestId}/reject

**Transition:** UNDER_REVIEW → REJECTED

Request:

~~~json
{
  "reason": "The request does not meet the stated document requirements.",
  "expectedVersion": 1
}
~~~

### POST /api/staff/requests/{requestId}/start-processing

**Transition:** APPROVED → PROCESSING

Request:

~~~json
{
  "expectedVersion": 2
}
~~~

### POST /api/staff/requests/{requestId}/issued-document

**Transition:** PROCESSING → READY  
**Delivery:** ELECTRONIC only  
**Content-Type:** multipart/form-data

Parts:

| Part | Type | Required |
| --- | --- | :---: |
| file | PDF | Yes |
| expectedVersion | text integer | Yes |

Response 200: RequestDetailResponse

Errors:

- 400 FILE_TOO_LARGE
- 400 UNSUPPORTED_FILE_TYPE
- 409 INVALID_REQUEST_TRANSITION
- 409 DELIVERY_METHOD_MISMATCH
- 409 ISSUED_DOCUMENT_ALREADY_EXISTS
- 409 REQUEST_VERSION_CONFLICT

### POST /api/staff/requests/{requestId}/ready-for-collection

**Transition:** PROCESSING → READY  
**Delivery:** PHYSICAL only

Request:

~~~json
{
  "expectedVersion": 3
}
~~~

### POST /api/staff/requests/{requestId}/complete-collection

**Transition:** READY → COMPLETED  
**Delivery:** PHYSICAL only

Request:

~~~json
{
  "collectionDate": "2026-10-17",
  "note": "Collected after identity verification.",
  "expectedVersion": 4
}
~~~

### GET /api/staff/requests/{requestId}/attachments/{attachmentId}

**Access:** STAFF  
**Purpose:** Review supporting file

The attachment must belong to the request in the path.

### GET /api/staff/requests/{requestId}/issued-document

**Access:** STAFF  
**Purpose:** Verify uploaded PDF

Staff verification does not complete the request and does not increment student download count.

## 10. Notification endpoints

### GET /api/notifications

**Access:** Any authenticated role

Query:

- read: true or false;
- type: NotificationType;
- page, size;
- sort fixed to createdAt desc for simplicity.

Response: PageResponse<NotificationResponse>

### GET /api/notifications/unread-count

Response:

~~~json
{
  "count": 4
}
~~~

### POST /api/notifications/{notificationId}/read

Marks an owned notification read.

Response 200: NotificationResponse

An already-read notification returns the same state.

### POST /api/notifications/read-all

Response: 204 No Content

Only the current user's unread notifications are changed.

## 11. Administrator user endpoints

### GET /api/admin/users

**Access:** ADMIN

Query:

- q: name or email;
- role;
- status;
- sort: createdAt, fullName, email, role, status;
- direction;
- page;
- size.

Response: PageResponse<UserSummary>

### POST /api/admin/users

**Access:** ADMIN

Request:

~~~json
{
  "fullName": "Demo Staff",
  "email": "staff.demo@unidoc.test",
  "role": "STAFF",
  "password": "Demo@123"
}
~~~

Role may be STAFF or ADMIN. Student accounts use self-registration.

Response 201: UserSummary

### PATCH /api/admin/users/{userId}/status

Request:

~~~json
{
  "status": "INACTIVE"
}
~~~

Rules:

- increments authVersion when status changes;
- administrator cannot deactivate their own currently authenticated account in the MVP;
- setting the current status again is idempotent.

### POST /api/admin/users/{userId}/reset-password

Request:

~~~json
{
  "newPassword": "NewDemo@123",
  "confirmPassword": "NewDemo@123"
}
~~~

Rules:

- sets a BCrypt hash;
- increments authVersion;
- does not email the password;
- returns 204;
- no forced password change is created.

## 12. Administrator document-type endpoints

### GET /api/admin/document-types

**Access:** ADMIN

Returns paginated active and inactive types.

Filters:

- q: code/name;
- active;
- page, size;
- sort: name, code, createdAt, active.

### POST /api/admin/document-types

Request:

~~~json
{
  "code": "ACADEMIC_TRANSCRIPT",
  "name": "Academic Transcript",
  "description": "Official record of academic results.",
  "requirements": "Provide the requested supporting evidence.",
  "supportingDocumentsRequired": false,
  "electronicAvailable": true,
  "physicalAvailable": true,
  "collectionLocation": "University Administration Office",
  "collectionInstructions": "Bring student identification.",
  "active": true
}
~~~

Response 201: AdminDocumentTypeResponse

### GET /api/admin/document-types/{documentTypeId}

Returns an active or inactive type.

### PUT /api/admin/document-types/{documentTypeId}

Replaces editable catalogue fields.

Response 200.

### PATCH /api/admin/document-types/{documentTypeId}/status

Request:

~~~json
{
  "active": false
}
~~~

No DELETE endpoint is provided.

## 13. Administrator monitoring and reports

### GET /api/admin/requests

**Access:** ADMIN  
**Behavior:** Same filters and pagination as staff list, read-only.

### GET /api/admin/requests/{requestId}

**Access:** ADMIN  
**Behavior:** Read-only request detail.

The response may omit direct file download URLs. Monitoring does not automatically grant document access.

### GET /api/admin/dashboard

Response:

~~~json
{
  "totalRequests": 120,
  "pendingRequests": 14,
  "approvedRequests": 8,
  "processingRequests": 6,
  "rejectedRequests": 9,
  "readyRequests": 11,
  "completedRequests": 72,
  "byDeliveryMethod": {
    "ELECTRONIC": 74,
    "PHYSICAL": 46
  },
  "byDocumentType": [
    {
      "documentTypeId": 2,
      "documentTypeName": "Academic Transcript",
      "count": 42
    }
  ],
  "recentRequests": []
}
~~~

### GET /api/admin/reports/requests

Returns paginated RequestReportRow.

Filters:

- submittedFrom;
- submittedTo;
- status;
- documentTypeId;
- deliveryMethod;
- page;
- size;
- sort;
- direction.

### GET /api/admin/reports/requests.csv

Uses the same filters but no page/size.

Response headers:

~~~text
Content-Type: text/csv; charset=UTF-8
Content-Disposition: attachment; filename="unidoc-request-report-2026-10-17.csv"
Cache-Control: no-store
~~~

## 14. RequestDetailResponse contract

The same conceptual model is used for student, staff, and admin detail, but each role-specific DTO may omit fields not needed by that role.

~~~json
{
  "id": 123,
  "requestNumber": "UDR-000123",
  "student": {
    "id": 3,
    "fullName": "Demo Student",
    "email": "student.demo@unidoc.test",
    "registrationNumber": "PS3000"
  },
  "documentTypeId": 2,
  "documentTypeName": "Academic Transcript",
  "purpose": "Required for a scholarship application.",
  "requiredDate": "2026-10-17",
  "deliveryMethod": "ELECTRONIC",
  "status": "READY",
  "additionalInformationMessage": null,
  "rejectionReason": null,
  "collectionLocation": null,
  "collectionInstructions": null,
  "readyAt": "2026-10-12T08:30:00Z",
  "completedAt": null,
  "collectionDate": null,
  "collectionNote": null,
  "attachments": [
    {
      "id": 88,
      "kind": "INITIAL_SUPPORT",
      "originalFilename": "identity-card.pdf",
      "contentType": "application/pdf",
      "sizeBytes": 184022,
      "createdAt": "2026-10-09T08:30:00Z"
    }
  ],
  "issuedDocument": {
    "originalFilename": "academic-transcript.pdf",
    "sizeBytes": 428201,
    "downloadCount": 0,
    "firstDownloadedAt": null,
    "createdAt": "2026-10-12T08:30:00Z"
  },
  "history": [
    {
      "id": 1,
      "previousStatus": null,
      "newStatus": "SUBMITTED",
      "changedBy": {
        "id": 3,
        "fullName": "Demo Student",
        "role": "STUDENT"
      },
      "note": "Request submitted.",
      "createdAt": "2026-10-09T08:30:00Z"
    }
  ],
  "availableActions": [
    "DOWNLOAD_ISSUED_DOCUMENT"
  ],
  "version": 4,
  "createdAt": "2026-10-09T08:30:00Z",
  "updatedAt": "2026-10-12T08:30:00Z"
}
~~~

For a student response, staff messages and student responses appear as history notes. The current additionalInformationMessage is present only while the request is waiting for the student.

## 15. HTTP status mapping

| Status | Use |
| --- | --- |
| 200 | Successful read/update/action |
| 201 | New user, document type, or request |
| 204 | Successful action with no body |
| 400 | Validation, malformed JSON, invalid parameter, invalid file |
| 401 | Missing/invalid/expired/revoked authentication |
| 403 | Authenticated but wrong role or inactive account |
| 404 | Resource absent or hidden due to ownership |
| 409 | Duplicate, invalid transition, stale version, state conflict |
| 413 | Optional mapping for request too large; application file rules normally return 400 |
| 500 | Unexpected server or storage error |
| 503 | Database unavailable during health/startup checks if implemented |

## 16. Stable error-code catalogue

Authentication/account:

- AUTH_INVALID_CREDENTIALS
- AUTHENTICATION_REQUIRED
- INVALID_TOKEN
- TOKEN_EXPIRED
- SESSION_REVOKED
- ACCOUNT_INACTIVE
- ACCESS_DENIED
- EMAIL_ALREADY_EXISTS
- REGISTRATION_NUMBER_ALREADY_EXISTS
- SELF_DEACTIVATION_NOT_ALLOWED

Validation/transport:

- VALIDATION_ERROR
- MALFORMED_REQUEST
- INVALID_PARAMETER
- INVALID_REQUEST

Catalogue/request:

- DOCUMENT_TYPE_NOT_FOUND
- DOCUMENT_TYPE_INACTIVE
- DOCUMENT_TYPE_CODE_EXISTS
- DOCUMENT_TYPE_NAME_EXISTS
- PROFILE_INCOMPLETE
- REQUEST_NOT_FOUND
- INVALID_REQUEST_TRANSITION
- DELIVERY_METHOD_MISMATCH
- REQUEST_VERSION_CONFLICT

Files:

- SUPPORTING_DOCUMENT_REQUIRED
- FILE_COUNT_EXCEEDED
- FILE_EMPTY
- FILE_TOO_LARGE
- UNSUPPORTED_FILE_TYPE
- FILE_STORAGE_ERROR
- ATTACHMENT_NOT_FOUND
- ISSUED_DOCUMENT_NOT_FOUND
- ISSUED_DOCUMENT_ALREADY_EXISTS
- DOCUMENT_NOT_READY

General:

- RESOURCE_NOT_FOUND
- CONFLICT
- INTERNAL_ERROR
- SERVICE_UNAVAILABLE

## 17. Security headers for downloads

File responses should include:

~~~text
Content-Disposition: attachment; filename="safe-name.pdf"
X-Content-Type-Options: nosniff
Cache-Control: private, no-store
Pragma: no-cache
~~~

The filename value must use Spring ContentDisposition builder or equivalent safe encoding. Raw user-supplied names are not concatenated into headers.

## 18. API implementation conventions

- Use @Valid on request DTOs.
- Use @AuthenticationPrincipal Jwt for current user identity.
- Never accept current user ID from a request body.
- Controllers map HTTP only; services enforce rules.
- Use ResponseEntity when status or download headers matter.
- Use Page and Pageable at repository level.
- Allow-list sort fields before creating Sort.
- Use one GlobalExceptionHandler.
- Use @Transactional on state-changing service methods.
- Publish email events only for after-commit listeners.
- Map entities to DTOs explicitly.
- Do not serialize bidirectional JPA relationships.
- Do not return relative_path, stored_filename, password_hash, auth_version, or internal configuration.

## 19. API completion checklist

- every requirement has an endpoint or explicit UI-only mechanism;
- endpoint role matches the capability matrix;
- ownership checks exist in query/service;
- workflow endpoints match the transition contract;
- examples match DTO field names;
- every list is paginated except bounded active catalogue and small aggregate lists;
- multipart part names are consistent;
- errors use stable codes;
- file responses set safe headers;
- CSV uses identical filters to the screen;
- Postman collection can demonstrate both delivery paths.
