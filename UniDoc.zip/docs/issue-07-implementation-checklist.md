# Issue 7 — Administrator Account Management: Implementation Checklist

**Scope:** `docs/12-implementation-plan.md` sections 7.1–7.10. Backend Spring Boot 4.1.1 / Java 21; frontend React/TypeScript/Vite.

## Implemented

- [x] Admin-only `GET /api/admin/users` with database-side name/email free-text search, optional exact role/status filters, allowed sorts, direction, zero-based page/size and `PageResponse<UserSummary>`.
- [x] Input allow-list/limits (100-character query, page ≥ 0, 1–100 size, approved enum values and sortable properties) and LIKE wildcard escaping.
- [x] `POST /api/admin/users` with STAFF/ADMIN-only validation, existing password policy, normalized email, BCrypt 12 via shared encoder, ACTIVE default, authVersion 0, HTTP 201 and safe user summary.
- [x] `PATCH /api/admin/users/{id}/status` with self-deactivation rejection, idempotent unchanged status, and JWT revocation on actual change.
- [x] `POST /api/admin/users/{id}/reset-password` with confirmation, BCrypt hashing, unconditional authVersion increment, HTTP 204, and no activation side effect.
- [x] Database row lock for competing account mutations so authVersion increments are not lost.
- [x] Security guards at `/api/admin/**` and service layer, with standard 401/403/404/409/validation error responses and request correlation.
- [x] Typed frontend account API module; responsive `/admin/users` table/cards, server-backed search/filters/sort/paging, loading/empty/error/retry states.
- [x] Accessible native confirmation dialogs for creation, activation/deactivation and password reset, visible field errors, validation focus, busy states and session-revocation warnings.
- [x] Frontend safely clears credentials on successful close, never stores them in sessionStorage/URLs/logs; self-password-reset signs out. Uncertain network results trigger list refresh plus a targeted account recheck.
- [x] Added `UserServiceTests` and `AdminUserHttpTests` for normal/negative operations, role restrictions, no sensitive response fields and JWT revocation.
- [x] All eleven approved architecture/requirements/data/API/security/storage/error/deployment/testing/ADR documents preserved unchanged. No changes to schema/approved dependencies.

## Checks completed here

- Java 21 compilation of **all backend main Java sources** using the exact production Spring Boot JAR dependencies included in the uploaded code: **PASS**.
- Strict TypeScript `tsc -b` against the supplied dependency versions: **PASS**.
- Standalone offline Bean Validation and account-service behavior harness (including BCrypt, role restriction, status/reset idempotence/versioning and query validation): **24 checks PASS**.
- Full `mvnw.cmd clean test` / `clean package`: **not executable in this Linux sandbox** (Maven/test dependencies are unavailable locally and external package registries cannot be reached).
- Frontend `npm run lint` / Vite production `npm run build`: **not executable here** (uploaded `node_modules` contains Windows-specific native `oxlint`/`rolldown` binaries, without the Linux bindings; registry access is unavailable). Source TypeScript compilation passes.
- Live MySQL, browser, responsiveness and active-session rejection: **require manual execution on the Windows workstation**.

## Windows verification commands

Run from `C:\ASV\Projects\UniDoc` after loading `.env` as described in README:

```powershell
.\backend\mvnw.cmd -f backend\pom.xml clean test
.\backend\mvnw.cmd -f backend\pom.xml clean package
npm --prefix frontend ci
npm --prefix frontend run lint
npm --prefix frontend run build
```

Follow the `README.md` Issue 7 manual acceptance scenario. In particular, verify a newly created staff member's old token is rejected immediately after deactivation and **still** rejected after reactivation, and after a password reset. No account DELETE endpoint, student creation via admin, role update, email delivery of passwords, or forced password change was added.
